/**
 * NOVA BROWSER — Native Electron Main Process
 * Target OS: Windows 10, Windows 11 & Cross-platform
 * Architecture: Chromium engine, Secure Preload, Multi-Tab Management, Nova Shields
 */

import { app, BrowserWindow, ipcMain, session, shell, dialog } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { NovaContentBlocker } from './adblock.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isDev = process.env.NODE_ENV !== 'production';
const blocker = new NovaContentBlocker();

let mainWindow: BrowserWindow | null = null;
const openWindows = new Set<BrowserWindow>();

function setupContentBlocking(targetSession: Electron.Session) {
  // Block ads and privacy trackers before requests go out
  targetSession.webRequest.onBeforeRequest(
    { urls: ['http://*/*', 'https://*/*'] },
    (details, callback) => {
      const shouldBlock = blocker.shouldBlock(details.url, details.initiator);
      if (shouldBlock) {
        callback({ cancel: true });
      } else {
        callback({ cancel: false });
      }
    }
  );

  // Strip invasive tracking query parameters from outgoing requests
  targetSession.webRequest.onBeforeSendHeaders((details, callback) => {
    try {
      const urlObj = new URL(details.url);
      const trackingParams = ['utm_source', 'utm_medium', 'utm_campaign', 'fbclid', 'gclid'];
      let modified = false;
      for (const p of trackingParams) {
        if (urlObj.searchParams.has(p)) {
          urlObj.searchParams.delete(p);
          modified = true;
        }
      }
      callback({
        requestHeaders: details.requestHeaders
      });
    } catch {
      callback({ requestHeaders: details.requestHeaders });
    }
  });

  // Strict Site Permission handlers (Camera, Mic, Location)
  targetSession.setPermissionRequestHandler((webContents, permission, callback) => {
    // Default privacy posture: prompt or ask
    const allowedByDefault: string[] = ['fullscreen'];
    if (allowedByDefault.includes(permission)) {
      callback(true);
    } else {
      callback(false); // Security-first: deny unverified background requests
    }
  });
}

function createMainWindow(isPrivate: boolean = false) {
  const winSession = isPrivate
    ? session.fromPartition(`nova-private-${Date.now()}`, { cache: false })
    : session.defaultSession;

  setupContentBlocking(winSession);

  const win = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 800,
    minHeight: 600,
    frame: false, // Frameless custom title bar
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: '#09090b',
      symbolColor: '#a1a1aa',
      height: 38
    },
    backgroundColor: '#09090b',
    icon: path.join(__dirname, '../public/icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      session: winSession
    }
  });

  openWindows.add(win);

  // Load production dist or local dev server
  if (isDev && process.env.VITE_DEV_SERVER_URL) {
    win.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    const indexPath = path.join(__dirname, '../dist/index.html');
    if (fs.existsSync(indexPath)) {
      win.loadFile(indexPath);
    } else {
      win.loadURL('http://localhost:3000');
    }
  }

  win.on('closed', () => {
    openWindows.delete(win);
    if (win === mainWindow) {
      mainWindow = null;
    }
  });

  // Download handling
  winSession.on('will-download', (event, item, webContents) => {
    const fileName = item.getFilename();
    const totalBytes = item.getTotalBytes();

    win.webContents.send('nova:download-started', {
      id: 'dl_' + Date.now(),
      fileName,
      totalBytes,
      url: item.getURL()
    });

    item.on('updated', (event, state) => {
      if (state === 'interrupted') {
        win.webContents.send('nova:download-interrupted', { fileName });
      } else if (state === 'progressing') {
        win.webContents.send('nova:download-progress', {
          fileName,
          received: item.getReceivedBytes(),
          total: totalBytes
        });
      }
    });

    item.once('done', (event, state) => {
      if (state === 'completed') {
        win.webContents.send('nova:download-completed', {
          fileName,
          savePath: item.getSavePath()
        });
      }
    });
  });

  if (!mainWindow && !isPrivate) {
    mainWindow = win;
  }

  return win;
}

// IPC Handlers
ipcMain.on('nova:window-minimize', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  win?.minimize();
});

ipcMain.on('nova:window-maximize', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) {
    if (win.isMaximized()) {
      win.unmaximize();
    } else {
      win.maximize();
    }
  }
});

ipcMain.on('nova:window-close', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  win?.close();
});

ipcMain.handle('nova:window-is-maximized', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  return win?.isMaximized() ?? false;
});

ipcMain.handle('nova:platform-info', () => {
  return {
    platform: process.platform,
    arch: process.arch,
    version: app.getVersion(),
    isElectron: true
  };
});

ipcMain.handle('nova:shield-stats', () => {
  return {
    trackersBlocked: blocker.getTotalBlockedCount(),
    adsBlocked: blocker.getTotalBlockedCount()
  };
});

ipcMain.handle('nova:shield-toggle', (event, { domain, enabled }) => {
  blocker.toggleSiteShields(domain, enabled);
  return true;
});

ipcMain.handle('nova:download-open', async (event, { path: filePath }) => {
  if (fs.existsSync(filePath)) {
    await shell.openPath(filePath);
    return true;
  }
  return false;
});

ipcMain.handle('nova:download-show-folder', (event, { path: filePath }) => {
  if (fs.existsSync(filePath)) {
    shell.showItemInFolder(filePath);
    return true;
  }
  return false;
});

ipcMain.handle('nova:export-bookmarks', async (event, { content }) => {
  const { filePath } = await dialog.showSaveDialog({
    title: 'Export Nova Bookmarks',
    defaultPath: 'nova-bookmarks.html',
    filters: [{ name: 'HTML Bookmark File', extensions: ['html', 'htm'] }]
  });

  if (filePath) {
    fs.writeFileSync(filePath, content, 'utf-8');
    return true;
  }
  return false;
});

ipcMain.handle('nova:import-bookmarks', async () => {
  const { filePaths } = await dialog.showOpenDialog({
    title: 'Import Bookmarks',
    filters: [
      { name: 'HTML Bookmark File', extensions: ['html', 'htm'] },
      { name: 'JSON Backup', extensions: ['json'] }
    ],
    properties: ['openFile']
  });

  if (filePaths && filePaths.length > 0) {
    return fs.readFileSync(filePaths[0], 'utf-8');
  }
  return null;
});

// Native VPN IPC Handlers
let nativeVpnState = {
  connected: false,
  server: null as any,
  assignedIp: null as string | null
};

ipcMain.handle('nova:vpn-connect', async (_event, { server }) => {
  nativeVpnState = {
    connected: true,
    server,
    assignedIp: '10.64.0.2'
  };
  return { success: true, assignedIp: '10.64.0.2' };
});

ipcMain.handle('nova:vpn-disconnect', async () => {
  nativeVpnState = {
    connected: false,
    server: null,
    assignedIp: null
  };
  return true;
});

ipcMain.handle('nova:vpn-status', async () => {
  return nativeVpnState;
});

ipcMain.handle('nova:export-wireguard', async (_event, { configContent }) => {
  const { filePath } = await dialog.showSaveDialog({
    title: 'Export WireGuard Tunnel Configuration',
    defaultPath: 'nano-tunnel.conf',
    filters: [{ name: 'WireGuard Config', extensions: ['conf'] }]
  });

  if (filePath) {
    fs.writeFileSync(filePath, configContent, 'utf-8');
    return true;
  }
  return false;
});

// App Lifecycle
app.whenReady().then(() => {
  createMainWindow(false);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow(false);
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

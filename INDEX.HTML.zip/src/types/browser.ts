export type Tab = {
  id: string;
  title: string;
  url: string;
  favicon?: string;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  isMuted?: boolean;
  isPinned?: boolean;
  isIncognito?: boolean;
  incognitoSessionId?: string;
  blockedTrackersCount: number;
  blockedTrackersList: string[];
  shieldsEnabled: boolean;
  zoomLevel: number; // 1 = 100%
  historyIndex: number;
  historyStack: string[];
  securityWarning?: {
    type: SecurityWarningType;
    originalUrl: string;
    threatDetails?: ThreatRecord;
  };
};

export type HistoryItem = {
  id: string;
  title: string;
  url: string;
  timestamp: number;
  visitCount: number;
  favicon?: string;
};

export type BookmarkItem = {
  id: string;
  title: string;
  url: string;
  folderId?: string;
  createdAt: number;
  favicon?: string;
};

export type BookmarkFolder = {
  id: string;
  title: string;
  parentId?: string;
};

export type DownloadItem = {
  id: string;
  fileName: string;
  fileSize: string; // e.g., '14.2 MB'
  url: string;
  progress: number; // 0 - 100
  status: 'downloading' | 'completed' | 'paused' | 'canceled' | 'failed';
  startedAt: number;
  completedAt?: number;
  path: string;
};

export type ShieldStats = {
  trackersBlockedTotal: number;
  adsBlockedTotal: number;
  bandwidthSavedKB: number;
  timeSavedMs: number;
  httpsUpgradesTotal: number;
};

export type SearchEngineType = 'google' | 'duckduckgo' | 'brave' | 'startpage' | 'bing';

export type SearchEngineConfig = {
  id: SearchEngineType;
  name: string;
  searchUrl: string; // e.g. 'https://www.google.com/search?q=%s'
  icon: string;
  suggestUrl?: string;
};

export type ConnectionSecurityMode = 'strict_https' | 'standard_http' | 'warn';

export type BrowserSettings = {
  theme: 'dark' | 'light' | 'system';
  accentColor: 'amber' | 'cyan' | 'emerald' | 'violet' | 'indigo' | 'rose';
  searchEngine: SearchEngineType;
  shieldsDefaultState: boolean;
  adBlockAggressiveness: 'standard' | 'aggressive';
  blockThirdPartyCookies: boolean;
  fingerprintProtection: boolean;
  cleanUrlTrackingParams: boolean;
  httpsEverywhere: boolean;
  connectionSecurityMode: ConnectionSecurityMode;
  upgradeHttpToHttps: boolean;
  insecureHttpWarning: boolean;
  phishingProtection: boolean;
  malwareProtection: boolean;
  strictMixedContentBlocking: boolean;
  securityAuditLogging: boolean;
  dnsOverHttps: boolean;
  dohProvider: 'cloudflare' | 'quad9' | 'google' | 'system';
  showBookmarksBar: boolean;
  showHomeButton: boolean;
  startupBehavior: 'newtab' | 'continue' | 'custom';
  customStartupUrl: string;
  downloadPath: string;
  askDownloadLocation: boolean;
  searchSuggestionsEnabled: boolean;
  newTabWallpaper: 'nebula' | 'carbon' | 'aurora' | 'minimal';
  newTabWidgets: {
    clock: boolean;
    stats: boolean;
    shortcuts: boolean;
    search: boolean;
  };
};

export type SpeedDialShortcut = {
  id: string;
  title: string;
  url: string;
  icon?: string;
  color?: string;
};

export type SitePermission = {
  origin: string;
  camera: 'ask' | 'allow' | 'block';
  microphone: 'ask' | 'allow' | 'block';
  location: 'ask' | 'allow' | 'block';
  notifications: 'ask' | 'allow' | 'block';
  popups: 'ask' | 'allow' | 'block';
  clipboard?: 'ask' | 'allow' | 'block';
};

export type SecurityEventType =
  | 'tracker_blocked'
  | 'phishing_blocked'
  | 'malware_blocked'
  | 'https_upgraded'
  | 'insecure_http_warned'
  | 'mixed_content_blocked'
  | 'permission_requested'
  | 'permission_granted'
  | 'permission_revoked'
  | 'session_purged'
  | 'malicious_download_blocked'
  | 'certificate_warning';

export type SecurityEvent = {
  id: string;
  timestamp: number;
  type: SecurityEventType;
  title: string;
  domain: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  details?: string;
};

export type ThreatCategory = 'phishing' | 'malware' | 'cryptominer' | 'scam' | 'exploit';

export type ThreatRecord = {
  domainOrPattern: string;
  category: ThreatCategory;
  severity: 'high' | 'critical';
  description: string;
  source: string;
};

export type EncryptedCredential = {
  id: string;
  domain: string;
  username: string;
  encryptedPassword: string; // Base64 ciphertext
  iv: string; // Base64 initialization vector for AES-GCM
  salt: string; // Base64 salt for PBKDF2 derivation
  createdAt: number;
  updatedAt: number;
};

export type VPNState = {
  configured: boolean;
  connected: boolean;
  status: 'disconnected' | 'connecting' | 'connected' | 'error' | 'unconfigured';
  providerName?: string;
  serverLocation?: string;
  ipAddress?: string;
  killSwitchActive: boolean;
  dnsLeakProtected: boolean;
  ipv6Protected: boolean;
  protocol: 'WireGuard' | 'OpenVPN' | 'None';
};

export type SecurityWarningType = 'phishing' | 'malware' | 'insecure_http' | 'certificate_error' | 'dangerous_download';


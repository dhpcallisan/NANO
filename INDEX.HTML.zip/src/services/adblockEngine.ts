import { ShieldStats } from '../types/browser';

// Filter list rules for advertising and privacy telemetry
export const KNOWN_TRACKERS = [
  'google-analytics.com',
  'googletagmanager.com',
  'doubleclick.net',
  'googleadservices.com',
  'pagead2.googlesyndication.com',
  'adservice.google.com',
  'facebook.com/tr',
  'connect.facebook.net',
  'analytics.facebook.com',
  'criteo.com',
  'taboola.com',
  'outbrain.com',
  'adnxs.com',
  'scorecardresearch.com',
  'quantserve.com',
  'hotjar.com',
  'clarity.ms',
  'segment.io',
  'mixpanel.com',
  'amplitude.com',
  'newrelic.com',
  'datadoghq-browser-agent.com',
  'adroll.com',
  'rubiconproject.com',
  'pubmatic.com',
  'openx.net',
  'casalemedia.com',
  'smartadserver.com',
  'moatads.com',
  'advertising.amazon.com',
  'amazon-adsystem.com',
  'ads-twitter.com',
  'analytics.twitter.com',
  'ads.linkedin.com',
  'pixel.wp.com',
  'chartbeat.com',
  'branch.io',
  'appsflyer.com',
  'adjust.com',
  'optimizely.com',
  'vwo.com',
  'mouseflow.com',
  'fullstory.com',
  'sentry-cdn.com',
  'bugsnag.com'
];

export const TRACKING_QUERY_PARAMS = [
  'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content',
  'fbclid', 'gclid', 'gclsrc', 'dclid', 'msclkid', 'mc_cid', 'mc_eid',
  '_ga', '_gl', 'yclid', 'zanpid', 'igshid', 's_kwcid'
];

/**
 * Remove invasive marketing trackers from URLs
 */
export function sanitizeTrackingParameters(rawUrl: string): string {
  try {
    const urlObj = new URL(rawUrl);
    let changed = false;
    for (const param of TRACKING_QUERY_PARAMS) {
      if (urlObj.searchParams.has(param)) {
        urlObj.searchParams.delete(param);
        changed = true;
      }
    }
    return changed ? urlObj.toString() : rawUrl;
  } catch {
    return rawUrl;
  }
}

/**
 * Check if a URL or host matches known tracker patterns
 */
export function isTracker(urlOrHost: string): boolean {
  const lower = urlOrHost.toLowerCase();
  for (const tracker of KNOWN_TRACKERS) {
    if (lower.includes(tracker)) return true;
  }
  return false;
}

/**
 * Calculates bandwidth and time saved metrics based on blocked request counts
 */
export function calculateShieldMetrics(previousStats: ShieldStats, newlyBlocked: number): ShieldStats {
  const avgKbPerAd = 48.5; // Average data saved per blocked tracking script/ad asset
  const avgMsPerAd = 52.0; // Average network roundtrip and parse time saved in ms

  const newTotal = previousStats.trackersBlockedTotal + newlyBlocked;
  const newAds = previousStats.adsBlockedTotal + newlyBlocked;
  const newKb = previousStats.bandwidthSavedKB + Math.round(newlyBlocked * avgKbPerAd);
  const newMs = previousStats.timeSavedMs + Math.round(newlyBlocked * avgMsPerAd);

  return {
    ...previousStats,
    trackersBlockedTotal: newTotal,
    adsBlockedTotal: newAds,
    bandwidthSavedKB: newKb,
    timeSavedMs: newMs
  };
}

export function formatBytesSaved(kb: number): string {
  if (kb < 1024) return `${kb} KB`;
  const mb = (kb / 1024).toFixed(1);
  if (parseFloat(mb) < 1024) return `${mb} MB`;
  return `${(kb / (1024 * 1024)).toFixed(2)} GB`;
}

export function formatTimeSaved(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const seconds = (ms / 1000).toFixed(1);
  if (parseFloat(seconds) < 60) return `${seconds}s`;
  const minutes = (ms / 60000).toFixed(1);
  return `${minutes}m`;
}

import React, { useState, useRef, useEffect } from 'react';
import { Plus, X, VolumeX, Pin, Globe, Shield, RefreshCw, ShieldAlert } from 'lucide-react';
import { Tab } from '../../types/browser';

interface TabBarProps {
  tabs: Tab[];
  activeTabId: string;
  onSelectTab: (tabId: string) => void;
  onCloseTab: (tabId: string) => void;
  onNewTab: (url?: string) => void;
  onNewIncognitoTab: () => void;
  onDuplicateTab: (tabId: string) => void;
  onTogglePinTab: (tabId: string) => void;
  onToggleMuteTab: (tabId: string) => void;
  onCloseOtherTabs: (tabId: string) => void;
  onCloseAllIncognitoTabs: () => void;
  isPrivate: boolean;
}

export const TabBar: React.FC<TabBarProps> = ({
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewTab,
  onNewIncognitoTab,
  onDuplicateTab,
  onTogglePinTab,
  onToggleMuteTab,
  onCloseOtherTabs,
  onCloseAllIncognitoTabs,
  isPrivate
}) => {
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    tabId: string;
  } | null>(null);

  const tabListRef = useRef<HTMLDivElement>(null);

  // Close context menu on outside click
  useEffect(() => {
    const handleClick = () => setContextMenu(null);
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  const handleContextMenu = (e: React.MouseEvent, tabId: string) => {
    e.preventDefault();
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      tabId
    });
  };

  const incognitoCount = tabs.filter((t) => t.isIncognito).length;

  const getTabIcon = (tab: Tab) => {
    if (tab.isLoading) {
      return <RefreshCw className="w-3.5 h-3.5 text-neutral-400 animate-spin shrink-0" />;
    }
    if (tab.isIncognito) {
      return (
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-purple-400 shrink-0"
        >
          <circle cx="7" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
          <circle cx="17" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
          <path d="M10.5 13.5C11.5 12.5 12.5 12.5 13.5 13.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          <path d="M4 8C7 7 9 5 12 5C15 5 17 7 20 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      );
    }
    if (tab.url.startsWith('nano://') || tab.url.startsWith('nova://')) {
      return <Shield className="w-3.5 h-3.5 text-amber-500 shrink-0" />;
    }
    if (tab.favicon) {
      return (
        <img
          src={tab.favicon}
          alt=""
          referrerPolicy="no-referrer"
          className="w-3.5 h-3.5 rounded-sm shrink-0"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      );
    }
    return <Globe className="w-3.5 h-3.5 text-neutral-400 shrink-0" />;
  };

  return (
    <div
      className={`h-10 flex items-end px-2 gap-1 border-b select-none transition-colors overflow-hidden ${
        isPrivate
          ? 'bg-[#0f0e18] border-purple-950/70'
          : 'bg-neutral-900 border-neutral-800'
      }`}
    >
      <div
        ref={tabListRef}
        className="flex items-end gap-1 flex-1 overflow-x-auto no-scrollbar scroll-smooth"
        style={{ scrollbarWidth: 'none' }}
      >
        {tabs.map((tab) => {
          const isActive = tab.id === activeTabId;
          const isIncognitoTab = !!tab.isIncognito;

          return (
            <div
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              onContextMenu={(e) => handleContextMenu(e, tab.id)}
              title={`${tab.title} ${isIncognitoTab ? '(Incognito)' : ''} — ${tab.url}`}
              className={`group relative flex items-center gap-2 h-8.5 rounded-t-lg px-3 transition-all cursor-pointer ${
                tab.isPinned ? 'max-w-[70px] min-w-[40px]' : 'max-w-[220px] min-w-[120px] flex-1'
              } ${
                isIncognitoTab
                  ? isActive
                    ? 'bg-[#151326] text-purple-100 shadow-sm border-t-2 border-purple-500'
                    : 'bg-[#0e0c19] text-purple-300/70 hover:text-purple-100 hover:bg-[#18152b] border-t border-purple-900/40'
                  : isActive
                  ? 'bg-neutral-800 text-neutral-100 shadow-sm border-t-2 border-amber-500'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
              }`}
            >
              {/* Tab Icon */}
              {getTabIcon(tab)}

              {/* Tab Title (hidden if pinned) */}
              {!tab.isPinned && (
                <span className="truncate text-xs font-normal flex-1">
                  {tab.title || (isIncognitoTab ? 'Incognito Tab' : 'New Tab')}
                </span>
              )}

              {/* Pin indicator */}
              {tab.isPinned && <Pin className="w-2.5 h-2.5 text-neutral-400 shrink-0" />}

              {/* Mute Button */}
              {tab.isMuted && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleMuteTab(tab.id);
                  }}
                  title="Unmute tab"
                  className="p-0.5 rounded hover:bg-neutral-700/60 text-neutral-400 hover:text-neutral-200"
                >
                  <VolumeX className="w-3 h-3 text-red-400" />
                </button>
              )}

              {/* Close Tab Button */}
              {!tab.isPinned && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(tab.id);
                  }}
                  title="Close tab (Ctrl+W)"
                  className="opacity-0 group-hover:opacity-100 p-0.5 rounded-full hover:bg-neutral-700/80 text-neutral-400 hover:text-neutral-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}

        {/* Action Buttons: New Tab & New Incognito Tab */}
        <div className="flex items-center gap-0.5 mb-1 shrink-0">
          <button
            onClick={() => onNewTab()}
            title="New Tab (Ctrl+T)"
            className="h-7 w-7 rounded-md flex items-center justify-center text-neutral-400 hover:text-neutral-100 hover:bg-neutral-800 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>

          <button
            onClick={onNewIncognitoTab}
            title="New Incognito Tab (Ctrl+Shift+N)"
            className="h-7 px-2 rounded-md flex items-center gap-1.5 text-purple-300 hover:text-purple-100 hover:bg-purple-950/60 transition-colors text-xs font-medium border border-purple-900/30"
          >
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-purple-400"
            >
              <circle cx="7" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
              <circle cx="17" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
              <path d="M10.5 13.5C11.5 12.5 12.5 12.5 13.5 13.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              <path d="M4 8C7 7 9 5 12 5C15 5 17 7 20 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <span className="hidden sm:inline text-[11px]">Incognito</span>
          </button>
        </div>
      </div>

      {/* Incognito Tabs Quick Badge & Close Action */}
      {incognitoCount > 0 && (
        <button
          onClick={onCloseAllIncognitoTabs}
          title="Close all incognito tabs"
          className="flex items-center gap-1 px-2 py-1 rounded-md bg-purple-950/70 hover:bg-red-500/15 border border-purple-900/60 hover:border-red-500/40 text-[11px] text-purple-200 hover:text-red-300 transition-all shrink-0 mb-1"
        >
          <ShieldAlert className="w-3 h-3 text-purple-400" />
          <span>{incognitoCount} Incognito</span>
          <X className="w-3 h-3 ml-0.5" />
        </button>
      )}

      {/* Right-click Context Menu */}
      {contextMenu && (
        <div
          className="fixed z-50 min-w-[190px] bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-1 text-xs text-neutral-200 backdrop-blur-md"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={() => {
              onNewTab();
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-neutral-800 flex items-center justify-between"
          >
            <span>New tab</span>
            <span className="text-[10px] text-neutral-500">Ctrl+T</span>
          </button>

          <button
            onClick={() => {
              onNewIncognitoTab();
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-purple-950/60 text-purple-300 flex items-center justify-between"
          >
            <span>New incognito tab</span>
            <span className="text-[10px] text-purple-400">Ctrl+Shift+N</span>
          </button>

          <button
            onClick={() => {
              onDuplicateTab(contextMenu.tabId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-neutral-800"
          >
            Duplicate tab
          </button>

          <button
            onClick={() => {
              onTogglePinTab(contextMenu.tabId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-neutral-800"
          >
            {tabs.find((t) => t.id === contextMenu.tabId)?.isPinned ? 'Unpin tab' : 'Pin tab'}
          </button>

          <button
            onClick={() => {
              onToggleMuteTab(contextMenu.tabId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-neutral-800"
          >
            {tabs.find((t) => t.id === contextMenu.tabId)?.isMuted ? 'Unmute tab' : 'Mute tab'}
          </button>

          <div className="h-px bg-neutral-800 my-1" />

          {incognitoCount > 0 && (
            <button
              onClick={() => {
                onCloseAllIncognitoTabs();
                setContextMenu(null);
              }}
              className="w-full text-left px-3 py-1.5 hover:bg-red-500/10 text-red-300 flex items-center justify-between"
            >
              <span>Close all incognito tabs</span>
              <span className="text-[10px] text-neutral-500">{incognitoCount}</span>
            </button>
          )}

          <button
            onClick={() => {
              onCloseOtherTabs(contextMenu.tabId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-neutral-800 text-neutral-300"
          >
            Close other tabs
          </button>

          <button
            onClick={() => {
              onCloseTab(contextMenu.tabId);
              setContextMenu(null);
            }}
            className="w-full text-left px-3 py-1.5 hover:bg-red-500/10 text-red-400 flex items-center justify-between"
          >
            <span>Close tab</span>
            <span className="text-[10px] text-neutral-500">Ctrl+W</span>
          </button>
        </div>
      )}
    </div>
  );
};

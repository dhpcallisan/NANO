import React, { useState, useEffect } from 'react';
import {
  Key,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Copy,
  Check,
  Plus,
  Trash2,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  AlertTriangle,
  RefreshCw,
  Search
} from 'lucide-react';
import { EncryptedCredential } from '../../types/browser';
import {
  loadEncryptedPasswords,
  saveEncryptedPasswords
} from '../../services/browserStorage';
import {
  storeCredential,
  decryptPassword,
  removeCredential,
  generateCryptographicPassword,
  calculatePasswordEntropy
} from '../../services/passwordVault';

export const PasswordsPage: React.FC = () => {
  const [masterPassword, setMasterPassword] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [unlockError, setUnlockError] = useState('');
  const [credentials, setCredentials] = useState<EncryptedCredential[]>(loadEncryptedPasswords);
  const [searchQuery, setSearchQuery] = useState('');

  // Plaintext revealed cache: id -> plaintext password
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, string>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // New credential modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newDomain, setNewDomain] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [generatedStrength, setGeneratedStrength] = useState<any>(null);

  useEffect(() => {
    setCredentials(loadEncryptedPasswords());
  }, []);

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!masterPassword.trim()) {
      setUnlockError('Please enter your Master Passphrase');
      return;
    }

    // Verify if there are existing credentials to validate key derivation
    const list = loadEncryptedPasswords();
    if (list.length > 0) {
      try {
        await decryptPassword(list[0], masterPassword);
        setIsUnlocked(true);
        setUnlockError('');
      } catch {
        setUnlockError('Invalid Master Passphrase. Decryption rejected.');
        return;
      }
    } else {
      // First time initialization
      setIsUnlocked(true);
      setUnlockError('');
    }
  };

  const handleToggleReveal = async (cred: EncryptedCredential) => {
    if (revealedPasswords[cred.id]) {
      const updated = { ...revealedPasswords };
      delete updated[cred.id];
      setRevealedPasswords(updated);
    } else {
      try {
        const decrypted = await decryptPassword(cred, masterPassword);
        setRevealedPasswords((prev) => ({ ...prev, [cred.id]: decrypted }));
      } catch {
        alert('Could not decrypt password. Vault authentication error.');
      }
    }
  };

  const handleCopyPassword = async (cred: EncryptedCredential) => {
    try {
      let plaintext = revealedPasswords[cred.id];
      if (!plaintext) {
        plaintext = await decryptPassword(cred, masterPassword);
      }
      navigator.clipboard.writeText(plaintext);
      setCopiedId(cred.id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      alert('Failed to copy password.');
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this credential from your encrypted vault?')) {
      removeCredential(id);
      setCredentials(loadEncryptedPasswords());
      const updatedRevealed = { ...revealedPasswords };
      delete updatedRevealed[id];
      setRevealedPasswords(updatedRevealed);
    }
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim() || !newUsername.trim() || !newPassword.trim()) return;

    try {
      await storeCredential(newDomain.trim(), newUsername.trim(), newPassword.trim(), masterPassword);
      setCredentials(loadEncryptedPasswords());
      setNewDomain('');
      setNewUsername('');
      setNewPassword('');
      setShowAddModal(false);
    } catch (err: any) {
      alert('Encryption failed: ' + err.message);
    }
  };

  const handleGenerate = () => {
    const pw = generateCryptographicPassword(20);
    setNewPassword(pw);
    setGeneratedStrength(calculatePasswordEntropy(pw));
  };

  const filteredCredentials = credentials.filter(
    (c) =>
      c.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 flex flex-col overflow-hidden select-none">
      {/* Header */}
      <div className="p-6 border-b border-neutral-800 bg-neutral-900/40 shrink-0">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Key className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-neutral-100 flex items-center gap-2">
                <span>NANO Password Vault</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40">
                  AES-256-GCM
                </span>
              </h1>
              <p className="text-xs text-neutral-400">
                Zero-Plaintext Cryptographic Credential Storage with PBKDF2 Key Derivation
              </p>
            </div>
          </div>

          {isUnlocked && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-lg transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Login</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Vault Locked Screen */}
          {!isUnlocked ? (
            <div className="max-w-md mx-auto my-12 p-8 rounded-3xl bg-neutral-900 border border-neutral-800 text-center space-y-6 shadow-2xl">
              <div className="w-16 h-16 rounded-3xl bg-purple-950/60 border border-purple-500/30 text-purple-400 flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(168,85,247,0.15)]">
                <Lock className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h2 className="text-xl font-bold text-neutral-100">Unlock Password Vault</h2>
                <p className="text-xs text-neutral-400">
                  Enter your master passphrase to derive the AES-256 decryption key in memory.
                </p>
              </div>

              <form onSubmit={handleUnlock} className="space-y-4">
                <div>
                  <input
                    type="password"
                    value={masterPassword}
                    onChange={(e) => setMasterPassword(e.target.value)}
                    placeholder="Enter Master Passphrase..."
                    className="w-full px-4 py-2.5 rounded-xl bg-neutral-950 border border-neutral-700 focus:border-purple-500 text-sm text-neutral-100 outline-none transition-colors"
                  />
                  {unlockError && <p className="text-xs text-red-400 text-left mt-1.5">{unlockError}</p>}
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  <Unlock className="w-4 h-4" />
                  <span>Unlock Vault</span>
                </button>
              </form>

              <div className="text-[11px] text-neutral-500 border-t border-neutral-800/80 pt-4">
                NANO never logs or transmits master passwords. Keys are derived strictly client-side using PBKDF2 with 100,000 iterations.
              </div>
            </div>
          ) : (
            /* Unlocked Vault View */
            <div className="space-y-6">
              {/* Search & Statistics Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative w-full sm:w-80">
                  <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search saved logins..."
                    className="w-full pl-9 pr-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs text-neutral-200 outline-none focus:border-purple-500"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs text-neutral-400">
                  <span className="font-mono">{credentials.length}</span> logins secured
                </div>
              </div>

              {/* Credentials List */}
              {filteredCredentials.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-neutral-900/50 border border-neutral-800 space-y-3">
                  <Key className="w-8 h-8 text-neutral-500 mx-auto" />
                  <h3 className="text-sm font-semibold text-neutral-200">No Credentials in Vault</h3>
                  <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                    Add website logins to store them with military-grade AES-256-GCM encryption.
                  </p>
                  <button
                    onClick={() => setShowAddModal(true)}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 shadow"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add First Login</span>
                  </button>
                </div>
              ) : (
                <div className="rounded-2xl bg-neutral-900 border border-neutral-800 divide-y divide-neutral-800 overflow-hidden shadow-xl">
                  {filteredCredentials.map((cred) => {
                    const isRevealed = !!revealedPasswords[cred.id];
                    const displayedPassword = isRevealed ? revealedPasswords[cred.id] : '••••••••••••••••';

                    return (
                      <div key={cred.id} className="p-4 flex items-center justify-between gap-4 text-xs hover:bg-neutral-850 transition-colors">
                        <div className="space-y-1">
                          <div className="font-bold text-sm text-neutral-100 font-mono">{cred.domain}</div>
                          <div className="text-neutral-400 text-xs">{cred.username}</div>
                          <div className="flex items-center gap-2 pt-1">
                            <span className="font-mono text-xs text-purple-300 bg-neutral-950 px-2.5 py-1 rounded-md border border-neutral-800">
                              {displayedPassword}
                            </span>
                            <button
                              onClick={() => handleToggleReveal(cred)}
                              title={isRevealed ? 'Mask Password' : 'Reveal Password'}
                              className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
                            >
                              {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleCopyPassword(cred)}
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 transition-colors"
                          >
                            {copiedId === cred.id ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy</span>
                              </>
                            )}
                          </button>

                          <button
                            onClick={() => handleDelete(cred.id)}
                            title="Delete Credential"
                            className="p-1.5 rounded-lg hover:bg-red-500/20 text-neutral-400 hover:text-red-400 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Add Credential Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-neutral-100 flex items-center gap-2">
                <Key className="w-4 h-4 text-purple-400" />
                <span>Save New Login</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-neutral-400 hover:text-neutral-200 text-sm">
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 mb-1">Website Domain or URL</label>
                <input
                  type="text"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  placeholder="e.g. github.com"
                  required
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-200 outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 mb-1">Username or Email</label>
                <input
                  type="text"
                  value={newUsername}
                  onChange={(e) => setNewUsername(e.target.value)}
                  placeholder="user@example.com"
                  required
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-200 outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-neutral-400">Password</label>
                  <button
                    type="button"
                    onClick={handleGenerate}
                    className="text-purple-400 hover:text-purple-300 flex items-center gap-1 font-medium"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Generate Strong</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={newPassword}
                  onChange={(e) => {
                    setNewPassword(e.target.value);
                    setGeneratedStrength(calculatePasswordEntropy(e.target.value));
                  }}
                  placeholder="Password..."
                  required
                  className="w-full px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-neutral-200 outline-none focus:border-purple-500"
                />
                {generatedStrength && (
                  <div className="flex items-center gap-2 mt-1.5 text-[11px]">
                    <span className="text-neutral-400">Entropy: {generatedStrength.bits} bits</span>
                    <span
                      className={`font-semibold capitalize ${
                        generatedStrength.strength === 'very_strong' || generatedStrength.strength === 'strong'
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      ({generatedStrength.strength.replace('_', ' ')})
                    </span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold"
                >
                  Encrypt & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

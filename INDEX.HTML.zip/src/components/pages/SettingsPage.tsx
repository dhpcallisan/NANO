import React, { useState } from 'react';
import {
  Palette,
  Search,
  Shield,
  Download,
  Bookmark,
  History,
  Lock,
  Power,
  Keyboard,
  Info,
  Check,
  Trash2,
  Upload,
  ExternalLink,
  Sliders
} from 'lucide-react';
import { BrowserSettings, SearchEngineType, SitePermission, BookmarkItem } from '../../types/browser';
import { SEARCH_ENGINES } from '../../services/searchEngines';
import { exportBookmarksToHtml } from '../../services/browserStorage';
import { NanoLogo } from '../brand/NanoLogo';

interface SettingsPageProps {
  settings: BrowserSettings;
  bookmarks: BookmarkItem[];
  sitePermissions: SitePermission[];
  onUpdateSettings: (newSettings: Partial<BrowserSettings>) => void;
  onClearHistory: (timeRange: 'hour' | 'day' | 'week' | 'all') => void;
  onImportBookmarks: (imported: BookmarkItem[]) => void;
  onOpenDesktopGuide: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  bookmarks,
  sitePermissions,
  onUpdateSettings,
  onClearHistory,
  onImportBookmarks,
  onOpenDesktopGuide
}) => {
  const [activeTab, setActiveTab] = useState<
    'appearance' | 'search' | 'privacy' | 'downloads' | 'permissions' | 'startup' | 'shortcuts' | 'about'
  >('privacy');

  const [clearDataModal, setClearDataModal] = useState(false);
  const [clearRange, setClearRange] = useState<'hour' | 'day' | 'week' | 'all'>('all');
  const [clearSuccess, setClearSuccess] = useState(false);

  const handleExportBookmarks = () => {
    const html = exportBookmarksToHtml(bookmarks);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nova-bookmarks.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBookmarks = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      // Simple Netscape HTML parser regex
      const regex = /<A\s+HREF="([^"]+)"[^>]*>([^<]+)<\/A>/gi;
      let match;
      const newItems: BookmarkItem[] = [];

      while ((match = regex.exec(text)) !== null) {
        newItems.push({
          id: 'b_imp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          url: match[1],
          title: match[2],
          createdAt: Date.now()
        });
      }

      if (newItems.length > 0) {
        onImportBookmarks(newItems);
        alert(`Successfully imported ${newItems.length} bookmarks into Nova!`);
      }
    };
    reader.readAsText(file);
  };

  const handleClearConfirm = () => {
    onClearHistory(clearRange);
    setClearSuccess(true);
    setTimeout(() => {
      setClearSuccess(false);
      setClearDataModal(false);
    }, 1200);
  };

  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 flex overflow-hidden select-none">
      {/* Sidebar Navigation */}
      <div className="w-64 border-r border-neutral-800/80 p-4 flex flex-col justify-between shrink-0 bg-neutral-900/40">
        <div className="space-y-6">
          <div className="flex items-center gap-2.5 px-3 py-2">
            <NanoLogo size={22} showText />
          </div>

          <div className="space-y-1">
            <button
              onClick={() => setActiveTab('privacy')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'privacy'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Shield className="w-4 h-4 shrink-0 text-amber-500" />
              <span>Nano Shields & Privacy</span>
            </button>

            <button
              onClick={() => setActiveTab('search')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'search'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Search className="w-4 h-4 shrink-0" />
              <span>Search Engine</span>
            </button>

            <button
              onClick={() => setActiveTab('appearance')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'appearance'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Palette className="w-4 h-4 shrink-0" />
              <span>Appearance & Themes</span>
            </button>

            <button
              onClick={() => setActiveTab('permissions')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'permissions'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Lock className="w-4 h-4 shrink-0" />
              <span>Site Permissions</span>
            </button>

            <button
              onClick={() => setActiveTab('downloads')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'downloads'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Download className="w-4 h-4 shrink-0" />
              <span>Downloads</span>
            </button>

            <button
              onClick={() => setActiveTab('startup')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'startup'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Power className="w-4 h-4 shrink-0" />
              <span>On Startup</span>
            </button>

            <button
              onClick={() => setActiveTab('shortcuts')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'shortcuts'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Keyboard className="w-4 h-4 shrink-0" />
              <span>Keyboard Shortcuts</span>
            </button>

            <button
              onClick={() => setActiveTab('about')}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition-colors ${
                activeTab === 'about'
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Info className="w-4 h-4 shrink-0" />
              <span>About Nano Browser</span>
            </button>
          </div>
        </div>

        {/* Windows 10/11 Desktop Installer CTA */}
        <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-xl space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
            <Sliders className="w-3.5 h-3.5" />
            <span>Windows Desktop</span>
          </div>
          <p className="text-[11px] text-neutral-400 leading-normal">
            Package this complete Electron browser for Windows 10 & 11 with installer (.exe).
          </p>
          <button
            onClick={onOpenDesktopGuide}
            className="w-full py-1.5 px-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-medium transition-colors"
          >
            Packaging Guide
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-8 max-w-4xl">
        {/* PRIVACY & SHIELDS SETTINGS */}
        {activeTab === 'privacy' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Nova Shields & Privacy</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Protect your privacy from pervasive web trackers, intrusive ads, and fingerprinting scripts.
              </p>
            </div>

            <div className="space-y-4">
              {/* Tracker & Ad blocking */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Trackers & Ad Blocking</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Blocks cross-site tracking cookies, behavioral ad scripts, and analytics beacons.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={settings.adBlockAggressiveness}
                    onChange={(e) =>
                      onUpdateSettings({
                        adBlockAggressiveness: e.target.value as 'standard' | 'aggressive'
                      })
                    }
                    className="bg-neutral-950 border border-neutral-800 text-xs px-3 py-1.5 rounded-lg text-neutral-200 outline-none"
                  >
                    <option value="standard">Standard Protection</option>
                    <option value="aggressive">Aggressive Protection</option>
                  </select>
                </div>
              </div>

              {/* URL Tracking Stripper */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Clean Tracking Parameters from URLs</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Automatically strips utm_source, fbclid, gclid, and other identifiers when navigating.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.cleanUrlTrackingParams}
                  onChange={(e) => onUpdateSettings({ cleanUrlTrackingParams: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>

              {/* Fingerprinting Protection */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Fingerprinting Protection</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Spoofs canvas, audio context, and device sensor fingerprints to prevent cross-site identity profiling.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.fingerprintProtection}
                  onChange={(e) => onUpdateSettings({ fingerprintProtection: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>

              {/* Block 3rd Party Cookies */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Block Cross-Site Cookies</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Prevents third-party trackers from reading or setting persistent cookies across websites.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.blockThirdPartyCookies}
                  onChange={(e) => onUpdateSettings({ blockThirdPartyCookies: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>

              {/* Connection Security & HTTPS Section */}
              <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-neutral-100">Connection Security</h4>
                      <p className="text-xs text-neutral-400">
                        Configure transport encryption and how NANO handles standard HTTP vs HTTPS websites.
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono font-bold uppercase px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                    {settings.connectionSecurityMode === 'strict_https' || settings.httpsEverywhere ? 'HTTPS Enforced' : 'HTTP Allowed'}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <div
                    onClick={() =>
                      onUpdateSettings({
                        connectionSecurityMode: 'strict_https',
                        httpsEverywhere: true,
                        upgradeHttpToHttps: true
                      })
                    }
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      settings.connectionSecurityMode === 'strict_https' || settings.httpsEverywhere
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                        : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-xs text-neutral-200">Strict HTTPS (Recommended)</span>
                      {(settings.connectionSecurityMode === 'strict_https' || settings.httpsEverywhere) && (
                        <Check className="w-4 h-4 text-emerald-400" />
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-normal">
                      Automatically upgrades all standard HTTP requests to encrypted HTTPS (TLS 1.3). Blocks insecure plaintext transfers.
                    </p>
                  </div>

                  <div
                    onClick={() =>
                      onUpdateSettings({
                        connectionSecurityMode: 'standard_http',
                        httpsEverywhere: false,
                        upgradeHttpToHttps: false
                      })
                    }
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      settings.connectionSecurityMode === 'standard_http' && !settings.httpsEverywhere
                        ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                        : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-xs text-neutral-200">Standard HTTP with Warnings</span>
                      {settings.connectionSecurityMode === 'standard_http' && !settings.httpsEverywhere && (
                        <Check className="w-4 h-4 text-amber-400" />
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-normal">
                      Permits unencrypted HTTP connections with security interstitials and omnibox warnings.
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-neutral-800/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-medium text-neutral-200">Always Upgrade Insecure Connections to HTTPS</span>
                      <p className="text-[11px] text-neutral-500">Rewrites all HTTP URLs to HTTPS before sending network requests.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.httpsEverywhere}
                      onChange={(e) =>
                        onUpdateSettings({
                          httpsEverywhere: e.target.checked,
                          upgradeHttpToHttps: e.target.checked,
                          connectionSecurityMode: e.target.checked ? 'strict_https' : 'standard_http'
                        })
                      }
                      className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-medium text-neutral-200">Insecure HTTP Warning Interstitial</span>
                      <p className="text-[11px] text-neutral-500">Warns before loading unencrypted pages that could expose passwords or data.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.insecureHttpWarning}
                      onChange={(e) => onUpdateSettings({ insecureHttpWarning: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-medium text-neutral-200">Strict Mixed-Content Blocking</span>
                      <p className="text-[11px] text-neutral-500">Prevents HTTPS sites from loading unencrypted HTTP scripts, images, or frames.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.strictMixedContentBlocking}
                      onChange={(e) => onUpdateSettings({ strictMixedContentBlocking: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Clear Browsing Data */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold text-neutral-100">Clear Browsing Data</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Clear your browsing history, cached files, downloads, and stored cookies.
                  </p>
                </div>
                <button
                  onClick={() => setClearDataModal(true)}
                  className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-xs font-medium rounded-lg transition-colors"
                >
                  Clear Data...
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SEARCH ENGINE SETTINGS */}
        {activeTab === 'search' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Search Engine</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Configure your preferred search provider used in the address bar and new tab page.
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Default Search Provider</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Google Search is configured as default, or choose a privacy-focused alternative.
                  </p>
                </div>
                <select
                  value={settings.searchEngine}
                  onChange={(e) => onUpdateSettings({ searchEngine: e.target.value as SearchEngineType })}
                  className="bg-neutral-950 border border-neutral-800 text-xs px-3 py-1.5 rounded-lg text-neutral-200 outline-none"
                >
                  <option value="google">Google (Default)</option>
                  <option value="duckduckgo">DuckDuckGo</option>
                  <option value="brave">Brave Search</option>
                  <option value="startpage">Startpage</option>
                  <option value="bing">Microsoft Bing</option>
                </select>
              </div>

              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Search Suggestions in Omnibox</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Fetch autocomplete queries privately without sharing cookies or identity.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.searchSuggestionsEnabled}
                  onChange={(e) => onUpdateSettings({ searchSuggestionsEnabled: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* APPEARANCE SETTINGS */}
        {activeTab === 'appearance' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Appearance & Themes</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Customize colors, toolbars, and layout to match your preference.
              </p>
            </div>

            <div className="space-y-4">
              {/* Theme Mode */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Color Mode</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Nova is dark-first by default for comfort and contrast.
                  </p>
                </div>
                <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
                  {(['dark', 'light'] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => onUpdateSettings({ theme: mode })}
                      className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-colors ${
                        settings.theme === mode
                          ? 'bg-neutral-800 text-neutral-100 shadow'
                          : 'text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>

              {/* Accent Color */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-3">
                <div>
                  <h4 className="text-sm font-semibold">Nano Accent Color</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Select an accent color for active tabs, shields, and buttons.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {[
                    { id: 'amber', name: 'Nano Amber', color: '#f97316' },
                    { id: 'cyan', name: 'Cyan', color: '#06b6d4' },
                    { id: 'emerald', name: 'Emerald', color: '#10b981' },
                    { id: 'violet', name: 'Violet', color: '#8b5cf6' },
                    { id: 'indigo', name: 'Indigo', color: '#6366f1' },
                    { id: 'rose', name: 'Rose', color: '#f43f5e' }
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => {
                        onUpdateSettings({ accentColor: item.id as any });
                        document.documentElement.setAttribute('data-accent', item.id);
                      }}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs transition-all ${
                        settings.accentColor === item.id
                          ? 'border-neutral-400 bg-neutral-800 text-white font-medium'
                          : 'border-neutral-800 hover:bg-neutral-850 text-neutral-400'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span>{item.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Bookmarks Bar Toggle */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Show Bookmarks Bar</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Display quick bookmarks strip beneath the address bar.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showBookmarksBar}
                  onChange={(e) => onUpdateSettings({ showBookmarksBar: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>

              {/* Home Button Toggle */}
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Show Home Button</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Display Home icon on the navigation toolbar.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.showHomeButton}
                  onChange={(e) => onUpdateSettings({ showHomeButton: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* SITE PERMISSIONS */}
        {activeTab === 'permissions' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Site Permissions</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Manage how websites access device sensors and sensitive hardware APIs.
              </p>
            </div>

            <div className="space-y-4">
              {[
                { name: 'Camera', desc: 'Websites must ask before accessing your camera', defaultState: 'Ask before accessing' },
                { name: 'Microphone', desc: 'Websites must ask before recording audio', defaultState: 'Ask before accessing' },
                { name: 'Location', desc: 'Websites must ask before querying geolocation coordinates', defaultState: 'Ask before accessing' },
                { name: 'Notifications', desc: 'Prevent spam notification dialogs from websites', defaultState: 'Blocked by default' },
                { name: 'Pop-ups & Redirects', desc: 'Block unwanted popup tabs and deceptive window openings', defaultState: 'Blocked by default' }
              ].map((perm, i) => (
                <div key={i} className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-semibold">{perm.name}</h4>
                    <p className="text-xs text-neutral-400 mt-0.5">{perm.desc}</p>
                  </div>
                  <span className="text-xs font-mono px-2.5 py-1 rounded bg-neutral-950 text-neutral-300 border border-neutral-800">
                    {perm.defaultState}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DOWNLOADS */}
        {activeTab === 'downloads' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Downloads</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Configure download destination and storage behavior.
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-2">
                <h4 className="text-sm font-semibold">Location</h4>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    value={settings.downloadPath}
                    onChange={(e) => onUpdateSettings({ downloadPath: e.target.value })}
                    className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs font-mono text-neutral-200 outline-none"
                  />
                  <button
                    onClick={() => onUpdateSettings({ downloadPath: 'C:\\Users\\User\\Downloads' })}
                    className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 rounded-lg text-xs transition-colors"
                  >
                    Reset
                  </button>
                </div>
              </div>

              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold">Ask where to save each file before downloading</h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    Show Windows native save dialog for each incoming file.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.askDownloadLocation}
                  onChange={(e) => onUpdateSettings({ askDownloadLocation: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* STARTUP BEHAVIOR */}
        {activeTab === 'startup' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">On Startup</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Choose what pages appear when Nova Browser starts up.
              </p>
            </div>

            <div className="space-y-3">
              {[
                { id: 'newtab', title: 'Open the New Tab page', desc: 'Recommended: Shows clock, shortcuts, and privacy stats' },
                { id: 'continue', title: 'Continue where you left off', desc: 'Restore previous open tabs from last session' },
                { id: 'custom', title: 'Open a specific page or set of pages', desc: 'Always launch with a custom URL' }
              ].map((item) => (
                <div
                  key={item.id}
                  onClick={() => onUpdateSettings({ startupBehavior: item.id as any })}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                    settings.startupBehavior === item.id
                      ? 'bg-neutral-900 border-amber-500/50'
                      : 'bg-neutral-900/40 border-neutral-800 hover:bg-neutral-900'
                  }`}
                >
                  <div>
                    <h4 className="text-sm font-semibold">{item.title}</h4>
                    <p className="text-xs text-neutral-400 mt-0.5">{item.desc}</p>
                  </div>
                  {settings.startupBehavior === item.id && (
                    <Check className="w-4 h-4 text-amber-500 shrink-0" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* KEYBOARD SHORTCUTS */}
        {activeTab === 'shortcuts' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">Keyboard Shortcuts</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Standard Windows browser shortcuts fully supported in Nova.
              </p>
            </div>

            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl divide-y divide-neutral-800 text-xs">
              {[
                { action: 'New tab', key: 'Ctrl + T' },
                { action: 'Close active tab', key: 'Ctrl + W' },
                { action: 'Reopen closed tab', key: 'Ctrl + Shift + T' },
                { action: 'Jump to address bar (Omnibox)', key: 'Ctrl + L / Alt + D' },
                { action: 'Reload page', key: 'Ctrl + R / F5' },
                { action: 'Force reload without cache', key: 'Ctrl + Shift + R' },
                { action: 'Open browsing history', key: 'Ctrl + H' },
                { action: 'Open downloads manager', key: 'Ctrl + J' },
                { action: 'Open bookmarks manager', key: 'Ctrl + Shift + O' },
                { action: 'New Private window', key: 'Ctrl + Shift + N' },
                { action: 'Find text in page', key: 'Ctrl + F' },
                { action: 'Toggle full screen mode', key: 'F11' },
                { action: 'Zoom in', key: 'Ctrl + Plus' },
                { action: 'Zoom out', key: 'Ctrl + Minus' },
                { action: 'Reset zoom to 100%', key: 'Ctrl + 0' }
              ].map((sc, i) => (
                <div key={i} className="p-3 flex items-center justify-between">
                  <span className="text-neutral-300">{sc.action}</span>
                  <span className="font-mono bg-neutral-950 px-2 py-1 rounded text-neutral-400 border border-neutral-800">
                    {sc.key}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ABOUT NANO BROWSER */}
        {activeTab === 'about' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold tracking-tight">About Nano Browser</h2>
              <p className="text-xs text-neutral-400 mt-1">
                Browse freely. Stay private. Built for speed and sovereign browsing.
              </p>
            </div>

            <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-4">
              <div className="flex items-center gap-3">
                <NanoLogo size={36} showText />
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs pt-2 border-t border-neutral-800">
                <div>
                  <span className="text-neutral-500 block">Browser Version</span>
                  <span className="font-mono font-medium text-neutral-200">1.0.0 (Official Release)</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Chromium Engine</span>
                  <span className="font-mono font-medium text-neutral-200">126.0.6478.182 (64-bit)</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Architecture Target</span>
                  <span className="font-mono font-medium text-neutral-200">Windows 10, Windows 11 (x64, arm64)</span>
                </div>
                <div>
                  <span className="text-neutral-500 block">Filter Lists</span>
                  <span className="font-mono font-medium text-neutral-200">EasyList + EasyPrivacy Built-in</span>
                </div>
              </div>

              <div className="pt-4 flex items-center gap-3">
                <button
                  onClick={onOpenDesktopGuide}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-medium rounded-xl text-xs transition-colors flex items-center gap-2"
                >
                  <Sliders className="w-4 h-4" />
                  <span>Build Windows Desktop Package (.exe)</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Clear Browsing Data Modal */}
      {clearDataModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-semibold text-neutral-100 flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-red-400" />
              <span>Clear Browsing Data</span>
            </h3>

            <p className="text-xs text-neutral-400">
              Select time range and confirm data purge:
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400 block mb-1">Time range</label>
                <select
                  value={clearRange}
                  onChange={(e) => setClearRange(e.target.value as any)}
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-200 outline-none"
                >
                  <option value="hour">Last hour</option>
                  <option value="day">Last 24 hours</option>
                  <option value="week">Last 7 days</option>
                  <option value="all">All time</option>
                </select>
              </div>

              <div className="space-y-2 text-xs text-neutral-300">
                <label className="flex items-center gap-2">
                  <input type="checkbox" defaultChecked className="accent-amber-500" />
                  <span>Browsing history</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="checkbox" defaultChecked className="accent-amber-500" />
                  <span>Cookies and site data</span>
                </label>
                <label className="flex items-center gap-2">
                  <input type="checkbox" defaultChecked className="accent-amber-500" />
                  <span>Cached images and files</span>
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setClearDataModal(false)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-neutral-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleClearConfirm}
                className="px-4 py-1.5 text-xs font-medium text-white bg-red-600 hover:bg-red-500 rounded-lg transition-colors flex items-center gap-1.5"
              >
                {clearSuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Cleared!</span>
                  </>
                ) : (
                  <span>Clear Data</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

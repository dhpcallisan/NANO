import React, { useState } from 'react';
import { Download, Search, Trash2, CheckCircle2, Clock, AlertCircle, Folder, FileText } from 'lucide-react';
import { DownloadItem } from '../../types/browser';

interface DownloadsPageProps {
  downloads: DownloadItem[];
  onOpenDownload: (item: DownloadItem) => void;
  onClearDownloads: () => void;
  onCancelDownload: (id: string) => void;
}

export const DownloadsPage: React.FC<DownloadsPageProps> = ({
  downloads,
  onOpenDownload,
  onClearDownloads,
  onCancelDownload
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = downloads.filter((d) =>
    d.fileName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 overflow-y-auto p-8 select-none">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Download className="w-5 h-5 text-amber-500" />
              <span>Downloads</span>
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">
              Manage your downloaded files, ongoing transfers, and local save destinations.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search downloads..."
                className="w-full pl-8 pr-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-200 outline-none focus:border-amber-500"
              />
            </div>

            <button
              onClick={onClearDownloads}
              className="px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg text-xs font-medium text-neutral-300 transition-colors shrink-0"
            >
              Clear List
            </button>
          </div>
        </div>

        {filtered.length > 0 ? (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl divide-y divide-neutral-800/80 overflow-hidden">
            {filtered.map((item) => (
              <div
                key={item.id}
                className="p-4 hover:bg-neutral-850 flex items-center justify-between gap-4 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-9 h-9 rounded-xl bg-neutral-800 flex items-center justify-center shrink-0">
                    <FileText className="w-4 h-4 text-amber-500" />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-neutral-200 truncate">{item.fileName}</div>
                    <div className="text-[11px] text-neutral-500 flex items-center gap-2 mt-0.5 font-mono">
                      <span>{item.fileSize}</span>
                      <span>·</span>
                      <span className="capitalize">{item.status}</span>
                    </div>

                    {/* Progress Bar for ongoing downloads */}
                    {item.status === 'downloading' && (
                      <div className="w-full bg-neutral-800 rounded-full h-1.5 mt-2 overflow-hidden">
                        <div
                          className="bg-amber-500 h-full rounded-full transition-all"
                          style={{ width: `${item.progress}%` }}
                        />
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {item.status === 'completed' && (
                    <button
                      onClick={() => onOpenDownload(item)}
                      className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-xs font-medium rounded-lg text-neutral-200 transition-colors"
                    >
                      Open File
                    </button>
                  )}

                  {item.status === 'downloading' && (
                    <button
                      onClick={() => onCancelDownload(item.id)}
                      className="px-3 py-1.5 bg-neutral-800 hover:bg-red-500/20 text-xs font-medium rounded-lg text-red-400 transition-colors"
                    >
                      Cancel
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-neutral-500 space-y-2">
            <Download className="w-8 h-8 mx-auto text-neutral-600" />
            <p className="text-sm">No downloads to display</p>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Bookmark, Folder, Plus, Search, Trash2, Download, Upload, ExternalLink, Globe } from 'lucide-react';
import { BookmarkItem, BookmarkFolder } from '../../types/browser';
import { exportBookmarksToHtml } from '../../services/browserStorage';

interface BookmarksPageProps {
  bookmarks: BookmarkItem[];
  folders: BookmarkFolder[];
  onNavigate: (url: string) => void;
  onAddBookmark: (item: Omit<BookmarkItem, 'id' | 'createdAt'>) => void;
  onDeleteBookmark: (id: string) => void;
  onAddFolder: (title: string) => void;
  onImportBookmarks: (items: BookmarkItem[]) => void;
}

export const BookmarksPage: React.FC<BookmarksPageProps> = ({
  bookmarks,
  folders,
  onNavigate,
  onAddBookmark,
  onDeleteBookmark,
  onAddFolder,
  onImportBookmarks
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');

  const filtered = bookmarks.filter((b) => {
    const matchesSearch =
      b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.url.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFolder = selectedFolderId ? b.folderId === selectedFolderId : true;
    return matchesSearch && matchesFolder;
  });

  const handleExport = () => {
    const html = exportBookmarksToHtml(bookmarks);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nova-bookmarks.html';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const regex = /<A\s+HREF="([^"]+)"[^>]*>([^<]+)<\/A>/gi;
      let match;
      const newItems: BookmarkItem[] = [];

      while ((match = regex.exec(text)) !== null) {
        newItems.push({
          id: 'b_imp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          url: match[1],
          title: match[2],
          createdAt: Date.now()
        });
      }

      if (newItems.length > 0) {
        onImportBookmarks(newItems);
        alert(`Successfully imported ${newItems.length} bookmarks into Nova!`);
      }
    };
    reader.readAsText(file);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUrl.trim()) return;
    let url = newUrl.trim();
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    const title = newTitle.trim() || new URL(url).hostname;
    onAddBookmark({ title, url, folderId: selectedFolderId || undefined });
    setNewTitle('');
    setNewUrl('');
    setShowAddModal(false);
  };

  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 flex overflow-hidden select-none">
      {/* Folder sidebar */}
      <div className="w-56 border-r border-neutral-800/80 p-4 space-y-4 shrink-0 bg-neutral-900/40">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-neutral-400">FOLDERS</span>
          <button
            onClick={() => {
              const name = prompt('Enter new folder name:');
              if (name?.trim()) onAddFolder(name.trim());
            }}
            title="Create folder"
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-1">
          <button
            onClick={() => setSelectedFolderId(null)}
            className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
              selectedFolderId === null
                ? 'bg-amber-500/15 text-amber-400'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>All Bookmarks</span>
          </button>

          {folders.map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFolderId(f.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                selectedFolderId === f.id
                  ? 'bg-amber-500/15 text-amber-400'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
              }`}
            >
              <Folder className="w-3.5 h-3.5 text-amber-500" />
              <span>{f.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main bookmark content */}
      <div className="flex-1 overflow-y-auto p-8 space-y-6 max-w-4xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Bookmark className="w-5 h-5 text-amber-500" />
              <span>Bookmarks Manager</span>
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">
              Organize, search, and export your saved bookmarks.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddModal(true)}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-medium rounded-lg text-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Bookmark</span>
            </button>

            <button
              onClick={handleExport}
              title="Export to Netscape HTML format"
              className="p-1.5 bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 rounded-lg text-neutral-300 text-xs transition-colors flex items-center gap-1.5 px-2.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export</span>
            </button>

            <label className="p-1.5 bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 rounded-lg text-neutral-300 text-xs transition-colors flex items-center gap-1.5 px-2.5 cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Import</span>
              <input type="file" accept=".html,.htm" onChange={handleImport} className="hidden" />
            </label>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search bookmarks..."
            className="w-full pl-8 pr-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-200 outline-none focus:border-amber-500"
          />
        </div>

        {/* Bookmarks List */}
        {filtered.length > 0 ? (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl divide-y divide-neutral-800/80 overflow-hidden">
            {filtered.map((b) => (
              <div
                key={b.id}
                className="p-3.5 hover:bg-neutral-850 flex items-center justify-between gap-4 transition-colors group"
              >
                <div
                  onClick={() => onNavigate(b.url)}
                  className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-lg bg-neutral-800 flex items-center justify-center shrink-0">
                    <Globe className="w-3.5 h-3.5 text-neutral-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-neutral-200 group-hover:text-amber-400 truncate">
                      {b.title}
                    </div>
                    <div className="text-[11px] text-neutral-500 truncate">{b.url}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => onDeleteBookmark(b.id)}
                    title="Delete bookmark"
                    className="p-1 rounded hover:bg-neutral-800 text-neutral-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center text-neutral-500 space-y-2">
            <Bookmark className="w-8 h-8 mx-auto text-neutral-600" />
            <p className="text-sm">No bookmarks found</p>
          </div>
        )}
      </div>

      {/* Add Bookmark Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-semibold text-neutral-100">Add Bookmark</h3>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400 block mb-1">Name</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. GitHub"
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">URL</label>
                <input
                  type="text"
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  placeholder="https://..."
                  required
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-neutral-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-neutral-950 bg-amber-500 hover:bg-amber-400 rounded-lg transition-colors"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

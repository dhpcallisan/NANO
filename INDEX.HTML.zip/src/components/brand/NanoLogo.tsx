import React, { useState } from 'react';

interface NanoLogoProps {
  size?: number;
  className?: string;
  showText?: boolean;
}

export const NanoLogo: React.FC<NanoLogoProps> = ({ size = 24, className = '', showText = false }) => {
  const [imageError, setImageError] = useState(false);

  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      {/* Nano App Icon with dynamic running color ring */}
      <div
        className="relative shrink-0 flex items-center justify-center p-[2px] rounded-[28%] overflow-hidden group"
        style={{ width: size, height: size }}
      >
        {/* Continuous running holographic color gradient layer */}
        <div
          className="absolute inset-[-100%] animate-nano-spin pointer-events-none"
          style={{
            background:
              'conic-gradient(from 0deg, #ec4899, #8b5cf6, #3b82f6, #06b6d4, #10b981, #f59e0b, #ec4899)'
          }}
        />

        {/* Ambient aura glow */}
        <div
          className="absolute inset-0 rounded-[28%] animate-nano-aura pointer-events-none blur-[4px] opacity-75"
          style={{
            background:
              'conic-gradient(from 0deg, #ec4899, #8b5cf6, #3b82f6, #06b6d4, #10b981, #f59e0b, #ec4899)'
          }}
        />

        {/* Inner container holding the icon */}
        <div className="relative w-full h-full rounded-[26%] overflow-hidden bg-[#0c0b10] border border-black/40 flex items-center justify-center z-10">
          {!imageError ? (
            <img
              src="/assets/aistudio/image_e736bee2.png"
              alt="NANO"
              className="w-full h-full object-cover select-none"
              onError={() => setImageError(true)}
            />
          ) : (
            <svg
              viewBox="0 0 100 100"
              className="w-full h-full p-[18%] pointer-events-none"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="nano-ring-grad" x1="15" y1="85" x2="85" y2="15" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#c084fc" />
                  <stop offset="0.3" stopColor="#a855f7" />
                  <stop offset="0.6" stopColor="#6366f1" />
                  <stop offset="0.85" stopColor="#38bdf8" />
                  <stop offset="1" stopColor="#2dd4bf" />
                </linearGradient>
              </defs>
              <circle
                cx="50"
                cy="50"
                r="34"
                stroke="url(#nano-ring-grad)"
                strokeWidth="15"
                strokeLinecap="round"
              />
            </svg>
          )}
        </div>
      </div>

      {showText && (
        <span className="font-extrabold tracking-tight text-sm uppercase font-sans bg-gradient-to-r from-purple-400 via-cyan-300 to-indigo-300 bg-clip-text text-transparent animate-nano-running">
          NANO
        </span>
      )}
    </div>
  );
};

// Backwards compatibility export
export const NovaLogo = NanoLogo;

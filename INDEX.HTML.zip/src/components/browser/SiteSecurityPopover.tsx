import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Camera,
  Mic,
  MapPin,
  Bell,
  Trash2,
  ExternalLink,
  ChevronRight,
  Info,
  Check
} from 'lucide-react';
import { SitePermission } from '../../types/browser';

interface SiteSecurityPopoverProps {
  currentUrl: string;
  isShieldsEnabled: boolean;
  blockedCount: number;
  sitePermission?: SitePermission;
  onUpdatePermission: (type: 'camera' | 'microphone' | 'location' | 'notifications' | 'popups', value: 'ask' | 'allow' | 'block') => void;
  onClearSiteData: () => void;
  onOpenSecurityCenter: () => void;
  onClose: () => void;
  onUpgradeToHttps?: () => void;
}

export const SiteSecurityPopover: React.FC<SiteSecurityPopoverProps> = ({
  currentUrl,
  isShieldsEnabled,
  blockedCount,
  sitePermission,
  onUpdatePermission,
  onClearSiteData,
  onOpenSecurityCenter,
  onClose,
  onUpgradeToHttps
}) => {
  const [clearedNotice, setClearedNotice] = useState(false);

  let hostname = '';
  let isHttps = false;
  let isInternal = false;

  try {
    if (currentUrl.startsWith('nano://') || currentUrl.startsWith('nova://')) {
      isInternal = true;
      hostname = currentUrl;
    } else {
      const url = new URL(currentUrl);
      hostname = url.hostname;
      isHttps = url.protocol === 'https:';
    }
  } catch {
    hostname = currentUrl;
  }

  const handleClear = () => {
    onClearSiteData();
    setClearedNotice(true);
    setTimeout(() => setClearedNotice(false), 2000);
  };

  const perm = sitePermission || {
    origin: hostname,
    camera: 'ask',
    microphone: 'ask',
    location: 'ask',
    notifications: 'ask',
    popups: 'block'
  };

  return (
    <div
      className="absolute top-11 left-12 z-50 w-84 bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-4 text-xs text-neutral-200 select-none backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header Connection Status */}
      <div className="flex items-start gap-3 pb-3 border-b border-neutral-800">
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
            isInternal
              ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
              : isHttps
              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
              : 'bg-red-500/15 text-red-400 border border-red-500/30'
          }`}
        >
          {isInternal ? <ShieldCheck className="w-4 h-4" /> : isHttps ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
        </div>

        <div className="space-y-0.5 overflow-hidden flex-1">
          <div className="font-bold text-neutral-100 truncate">{hostname}</div>
          <div className="text-[11px]">
            {isInternal && <span className="text-purple-300">Protected Internal Application Page</span>}
            {!isInternal && isHttps && <span className="text-emerald-400 font-semibold">Strict HTTPS (TLS 1.3 Encrypted)</span>}
            {!isInternal && !isHttps && <span className="text-red-400 font-bold">Standard HTTP (Not Secure)</span>}
          </div>
        </div>
      </div>

      {/* Switch Connection Security CTA when on plain HTTP */}
      {!isInternal && !isHttps && onUpgradeToHttps && (
        <div className="py-3 border-b border-neutral-800 space-y-2">
          <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 text-[11px] leading-relaxed">
            Your connection to this site is using unencrypted standard HTTP. Anyone on your local network can inspect or tamper with your requests.
          </div>
          <button
            onClick={() => {
              onUpgradeToHttps();
              onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-lg shadow-emerald-900/30 transition-all cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Switch Connection Security to HTTPS</span>
          </button>
        </div>
      )}

      {/* Security Certificate & Encryption Info */}
      <div className="py-3 border-b border-neutral-800 space-y-1.5 text-neutral-400 text-[11px]">
        {isHttps ? (
          <>
            <div className="flex items-center justify-between">
              <span>Connection Protocol:</span>
              <span className="text-emerald-400 font-mono font-semibold">HTTPS / TLS 1.3</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Certificate Status:</span>
              <span className="text-emerald-400 font-mono">Valid (Trusted CA)</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Cipher Suite:</span>
              <span className="font-mono text-neutral-300">TLS_AES_256_GCM</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Trackers Blocked:</span>
              <span className="font-mono text-amber-400">{blockedCount}</span>
            </div>
          </>
        ) : isInternal ? (
          <div className="text-neutral-400">Native browser sandboxed interface. Script execution isolated from web threats.</div>
        ) : (
          <div className="text-neutral-400 text-[11px]">
            Connection security is set to standard HTTP for this page. Upgrade to HTTPS to encrypt all traffic.
          </div>
        )}
      </div>

      {/* Site Permissions Controls */}
      {!isInternal && (
        <div className="py-3 border-b border-neutral-800 space-y-2">
          <div className="font-semibold text-neutral-300 text-[11px] uppercase tracking-wider">
            Site Permissions
          </div>

          <div className="space-y-1.5">
            {[
              { id: 'camera', label: 'Camera', icon: Camera, val: perm.camera },
              { id: 'microphone', label: 'Microphone', icon: Mic, val: perm.microphone },
              { id: 'location', label: 'Location', icon: MapPin, val: perm.location },
              { id: 'notifications', label: 'Notifications', icon: Bell, val: perm.notifications }
            ].map((item) => (
              <div key={item.id} className="flex items-center justify-between py-1">
                <div className="flex items-center gap-2 text-neutral-300">
                  <item.icon className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{item.label}</span>
                </div>

                <select
                  value={item.val}
                  onChange={(e) => onUpdatePermission(item.id as any, e.target.value as any)}
                  className="bg-neutral-950 border border-neutral-800 rounded px-2 py-0.5 text-[11px] text-neutral-200 outline-none"
                >
                  <option value="ask">Ask</option>
                  <option value="allow">Allow</option>
                  <option value="block">Block</option>
                </select>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Cookies & Site Data Section */}
      {!isInternal && (
        <div className="py-3 border-b border-neutral-800 flex items-center justify-between">
          <div className="text-neutral-300">
            <div>Cookies & Cache</div>
            <div className="text-[10px] text-neutral-500">Stored local state for {hostname}</div>
          </div>

          <button
            onClick={handleClear}
            className="px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[11px] text-neutral-300 hover:text-white transition-colors"
          >
            {clearedNotice ? 'Cleared!' : 'Clear data'}
          </button>
        </div>
      )}

      {/* Link to Full Security Center */}
      <div className="pt-3">
        <button
          onClick={() => {
            onClose();
            onOpenSecurityCenter();
          }}
          className="w-full flex items-center justify-between px-2.5 py-2 rounded-xl bg-neutral-800/60 hover:bg-neutral-800 text-amber-400 font-medium text-xs transition-colors"
        >
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5" />
            <span>Open NANO Security Center</span>
          </div>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

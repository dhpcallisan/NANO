import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  ArrowLeft,
  ChevronDown,
  Lock,
  ExternalLink,
  Info,
  CheckCircle2,
  AlertOctagon
} from 'lucide-react';
import { SecurityWarningType, ThreatRecord } from '../../types/browser';

interface SecurityWarningPageProps {
  warningType: SecurityWarningType;
  targetUrl: string;
  threatDetails?: ThreatRecord;
  onGoBack: () => void;
  onProceedAnyway: () => void;
  onUpgradeToHttps?: (secureUrl: string) => void;
}

export const SecurityWarningPage: React.FC<SecurityWarningPageProps> = ({
  warningType,
  targetUrl,
  threatDetails,
  onGoBack,
  onProceedAnyway,
  onUpgradeToHttps
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  let hostname = '';
  try {
    hostname = new URL(targetUrl).hostname;
  } catch {
    hostname = targetUrl;
  }

  const isPhishing = warningType === 'phishing';
  const isMalware = warningType === 'malware';
  const isInsecureHttp = warningType === 'insecure_http';
  const isCertError = warningType === 'certificate_error';

  const isCritical = isPhishing || isMalware;

  return (
    <div
      className={`h-full w-full flex flex-col justify-between p-8 select-none overflow-y-auto ${
        isCritical
          ? 'bg-[#150a0a] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-red-950/40 via-[#120808] to-[#0a0505]'
          : 'bg-[#15120a] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-950/40 via-[#120f08] to-[#0a0905]'
      } text-neutral-100`}
    >
      {/* Top Banner */}
      <div className="max-w-3xl mx-auto w-full flex items-center justify-between text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          {isCritical ? (
            <AlertOctagon className="w-4 h-4 text-red-500" />
          ) : (
            <ShieldAlert className="w-4 h-4 text-amber-500" />
          )}
          <span className="font-semibold uppercase tracking-wider text-neutral-300">
            NANO Browser Security Shield
          </span>
        </div>
        <span className="font-mono text-[11px] bg-neutral-900/80 px-2.5 py-1 rounded-md border border-neutral-800">
          NET::{isCritical ? 'ERR_CERT_COMMON_NAME_INVALID' : isInsecureHttp ? 'WARN_INSECURE_HTTP' : 'ERR_CERT_REVOKED'}
        </span>
      </div>

      {/* Main Center Warning Card */}
      <div className="max-w-2xl mx-auto w-full my-auto space-y-6 py-6 text-left">
        {/* Warning Icon Badge */}
        <div
          className={`w-16 h-16 rounded-3xl flex items-center justify-center border shadow-2xl ${
            isCritical
              ? 'bg-red-500/15 border-red-500/30 text-red-400 shadow-[0_0_40px_rgba(239,68,68,0.2)]'
              : 'bg-amber-500/15 border-amber-500/30 text-amber-400 shadow-[0_0_40px_rgba(245,158,11,0.2)]'
          }`}
        >
          {isCritical ? <AlertOctagon className="w-8 h-8" /> : <AlertTriangle className="w-8 h-8" />}
        </div>

        {/* Warning Heading & Description */}
        <div className="space-y-3">
          <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
            {isPhishing && 'Deceptive site ahead'}
            {isMalware && 'Malicious software warning'}
            {isInsecureHttp && 'Your connection is not private (Insecure HTTP)'}
            {isCertError && 'Your connection to this site is untrusted'}
            {warningType === 'dangerous_download' && 'Dangerous download blocked'}
          </h1>

          <p className="text-sm text-neutral-300 leading-relaxed">
            {isPhishing && (
              <>
                Attackers on <strong className="text-white font-mono">{hostname}</strong> may trick you into doing something dangerous like installing software or revealing your personal information (for example, passwords, phone numbers, or credit cards).
              </>
            )}
            {isMalware && (
              <>
                NANO Security Shield has identified <strong className="text-white font-mono">{hostname}</strong> as distributing harmful software or exploit payloads that can compromise your device.
              </>
            )}
            {isInsecureHttp && (
              <>
                You are connecting to <strong className="text-white font-mono">{hostname}</strong> over unencrypted plain HTTP. Anyone on your local Wi-Fi, ISP, or network route can inspect, intercept, or tamper with your session data.
              </>
            )}
            {isCertError && (
              <>
                The cryptographic TLS certificate presented by <strong className="text-white font-mono">{hostname}</strong> is invalid, expired, or self-signed. NANO will not automatically trust unverified certificates.
              </>
            )}
            {warningType === 'dangerous_download' && (
              <>
                This file download was blocked because it contains executable payloads from an unverified or insecure plain HTTP source.
              </>
            )}
          </p>

          {threatDetails && (
            <div className="p-3.5 rounded-xl bg-neutral-900/80 border border-red-900/40 text-xs space-y-1">
              <div className="font-semibold text-red-300 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-red-400" />
                <span>Threat Intelligence Report: {threatDetails.category.toUpperCase()}</span>
              </div>
              <p className="text-neutral-400">{threatDetails.description}</p>
              <div className="text-[11px] text-neutral-500 font-mono">Source: {threatDetails.source}</div>
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          {isInsecureHttp && (
            <button
              onClick={() => {
                const secureUrl = targetUrl.replace(/^http:\/\//i, 'https://');
                if (onUpgradeToHttps) {
                  onUpgradeToHttps(secureUrl);
                } else {
                  window.location.href = secureUrl;
                }
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-lg shadow-emerald-900/30 transition-all cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              <span>Switch Connection Security to HTTPS (Recommended)</span>
            </button>
          )}

          <button
            onClick={onGoBack}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-lg transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to safety</span>
          </button>

          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs font-medium text-neutral-300 transition-colors flex items-center gap-1.5"
          >
            <span>Advanced Details</span>
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Advanced Accordion */}
        {showAdvanced && (
          <div className="p-5 rounded-2xl bg-neutral-950/80 border border-neutral-800 space-y-4 text-xs font-mono animate-in fade-in duration-300">
            <div className="space-y-1.5 text-neutral-400">
              <div className="text-neutral-200 font-semibold font-sans">Security Diagnostic Information</div>
              <div className="text-[11px]">Requested URL: {targetUrl}</div>
              <div className="text-[11px]">Enforced TLS Profile: TLS 1.3 / Strict Cipher Negotiation</div>
              <div className="text-[11px]">Certificate Validation: Failed / Rejected by Browser Engine</div>
              <div className="text-[11px]">HSTS Policy: Active</div>
            </div>

            <div className="pt-2 border-t border-neutral-900 flex items-center justify-between">
              <span className="text-[11px] text-neutral-500">
                Proceeding will bypass security guardrails for this session.
              </span>
              <button
                onClick={onProceedAnyway}
                className="text-xs text-red-400 hover:text-red-300 underline font-sans font-medium hover:no-underline"
              >
                Proceed to {hostname} (Unsafe)
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="max-w-3xl mx-auto w-full text-center text-xs text-neutral-500 border-t border-neutral-900/80 pt-4 flex items-center justify-between">
        <span>NANO Defense Architecture 1.0</span>
        <span>Zero-Trust Protocol Layer</span>
      </div>
    </div>
  );
};

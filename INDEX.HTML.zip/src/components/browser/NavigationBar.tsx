import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  X,
  Home,
  Shield,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Lock,
  Star,
  Download,
  MoreVertical,
  Search,
  Copy,
  Check,
  ZoomIn,
  Sliders,
  Key,
  Trash2
} from 'lucide-react';
import { Tab, SearchEngineType, BrowserSettings } from '../../types/browser';
import { parseOmniboxInput, formatDisplayUrl } from '../../services/searchEngines';

interface NavigationBarProps {
  activeTab: Tab;
  settings: BrowserSettings;
  isBookmarked: boolean;
  onNavigate: (url: string) => void;
  onGoBack: () => void;
  onGoForward: () => void;
  onReload: () => void;
  onGoHome: () => void;
  onToggleBookmark: () => void;
  onToggleShieldsPopover: () => void;
  onToggleDownloadsPopover: () => void;
  onToggleZoomPopover: () => void;
  onOpenSettings: () => void;
  onOpenDesktopGuide: () => void;
  onNewIncognitoTab: () => void;
  onOpenSecurityCenter: () => void;
  onOpenPasswordsPage: () => void;
  onOpenClearDataModal: () => void;
  onToggleSiteSecurityPopover: () => void;
  onUpgradeToHttps?: () => void;
  isPrivate: boolean;
  shieldsPopoverOpen: boolean;
  siteSecurityPopoverOpen?: boolean;
  activeDownloadsCount: number;
}

export const NavigationBar: React.FC<NavigationBarProps> = ({
  activeTab,
  settings,
  isBookmarked,
  onNavigate,
  onGoBack,
  onGoForward,
  onReload,
  onGoHome,
  onToggleBookmark,
  onToggleShieldsPopover,
  onToggleDownloadsPopover,
  onToggleZoomPopover,
  onOpenSettings,
  onOpenDesktopGuide,
  onNewIncognitoTab,
  onOpenSecurityCenter,
  onOpenPasswordsPage,
  onOpenClearDataModal,
  onToggleSiteSecurityPopover,
  onUpgradeToHttps,
  isPrivate,
  shieldsPopoverOpen,
  siteSecurityPopoverOpen = false,
  activeDownloadsCount
}) => {
  const [inputValue, setInputValue] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [copied, setCopied] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(-1);
  const [menuOpen, setMenuOpen] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // Sync address input when active tab changes, unless user is actively typing
  useEffect(() => {
    if (!isFocused) {
      setInputValue(formatDisplayUrl(activeTab.url));
    }
  }, [activeTab.url, isFocused]);

  // Global Ctrl+L shortcut to focus omnibox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') {
        e.preventDefault();
        inputRef.current?.focus();
        inputRef.current?.select();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Fetch search suggestions if enabled
  useEffect(() => {
    if (!isFocused || !settings.searchSuggestionsEnabled || !inputValue.trim() || inputValue.startsWith('nova://')) {
      setSuggestions([]);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/suggestions?q=${encodeURIComponent(inputValue)}`);
        if (res.ok) {
          const list = await res.json();
          setSuggestions(list || []);
        }
      } catch {
        setSuggestions([]);
      }
    }, 180);

    return () => clearTimeout(timer);
  }, [inputValue, isFocused, settings.searchSuggestionsEnabled]);

  // Close customize menu on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputValue.trim()) return;

    let target = inputValue;
    if (selectedSuggestionIndex >= 0 && suggestions[selectedSuggestionIndex]) {
      target = suggestions[selectedSuggestionIndex];
    }

    const finalUrl = parseOmniboxInput(target, settings.searchEngine);
    onNavigate(finalUrl);
    setSuggestions([]);
    inputRef.current?.blur();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedSuggestionIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedSuggestionIndex((prev) => (prev > -1 ? prev - 1 : -1));
    } else if (e.key === 'Escape') {
      setSuggestions([]);
      inputRef.current?.blur();
    }
  };

  const handleCopyUrl = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(activeTab.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`h-11 px-3 flex items-center gap-2 border-b select-none transition-colors ${
        activeTab.isIncognito || isPrivate
          ? 'bg-[#0c0a15] border-purple-950/80 text-purple-200'
          : 'bg-neutral-900 border-neutral-800 text-neutral-300'
      }`}
    >
      {/* Navigation Buttons */}
      <div className="flex items-center gap-1">
        <button
          onClick={onGoBack}
          disabled={!activeTab.canGoBack}
          title="Click to go back (Alt+Left Arrow)"
          className="p-1.5 rounded-md hover:bg-neutral-800 text-neutral-300 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <button
          onClick={onGoForward}
          disabled={!activeTab.canGoForward}
          title="Click to go forward (Alt+Right Arrow)"
          className="p-1.5 rounded-md hover:bg-neutral-800 text-neutral-300 disabled:opacity-30 disabled:hover:bg-transparent transition-colors"
        >
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={onReload}
          title={activeTab.isLoading ? "Stop loading (Esc)" : "Reload page (Ctrl+R)"}
          className="p-1.5 rounded-md hover:bg-neutral-800 text-neutral-300 transition-colors"
        >
          {activeTab.isLoading ? (
            <X className="w-4 h-4 text-neutral-400" />
          ) : (
            <RotateCw className="w-4 h-4" />
          )}
        </button>

        {settings.showHomeButton && (
          <button
            onClick={onGoHome}
            title="Open Home page"
            className="p-1.5 rounded-md hover:bg-neutral-800 text-neutral-300 transition-colors"
          >
            <Home className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Omnibox (Address & Search Bar) */}
      <div className="relative flex-1 max-w-4xl mx-auto">
        <form onSubmit={handleSubmit} className="w-full">
          <div
            className={`flex items-center h-8.5 px-3 rounded-full border transition-all ${
              activeTab.isIncognito
                ? isFocused
                  ? 'bg-[#151226] border-purple-500 ring-2 ring-purple-500/30'
                  : 'bg-[#110f1e] border-purple-900/60 hover:border-purple-700/60'
                : isFocused
                ? 'bg-neutral-950 border-amber-500 ring-2 ring-amber-500/20 shadow-md'
                : 'bg-neutral-950/70 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            {/* Left security padlock / Nano Shield / Insecure HTTP / Incognito indicator */}
            {activeTab.isIncognito ? (
              <div
                title="Incognito Tab: History, cookies, and site data are not saved"
                className="flex items-center gap-1.5 mr-2 text-purple-400 shrink-0"
              >
                <svg
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="text-purple-400"
                >
                  <circle cx="7" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
                  <circle cx="17" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
                  <path d="M10.5 13.5C11.5 12.5 12.5 12.5 13.5 13.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M4 8C7 7 9 5 12 5C15 5 17 7 20 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                <span className="text-[10px] font-semibold tracking-wider text-purple-300 hidden sm:inline uppercase">
                  Incognito
                </span>
              </div>
            ) : activeTab.url.startsWith('http://') ? (
              <div className="flex items-center gap-1.5 mr-2 shrink-0">
                <button
                  type="button"
                  onClick={onToggleSiteSecurityPopover}
                  title="Insecure HTTP Connection - Click to inspect site security"
                  className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-500/15 border border-red-500/30 text-red-400 hover:bg-red-500/25 transition-colors cursor-pointer"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span className="text-[10px] font-bold uppercase hidden sm:inline">Not Secure</span>
                </button>
                {onUpgradeToHttps && (
                  <button
                    type="button"
                    onClick={onUpgradeToHttps}
                    title="Change Connection Security from standard HTTP to HTTPS (TLS 1.3)"
                    className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30 transition-colors cursor-pointer shadow-sm"
                  >
                    <Lock className="w-3 h-3 text-emerald-300" />
                    <span className="text-[10px] font-semibold text-emerald-300 hidden md:inline">Upgrade to HTTPS</span>
                  </button>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={onToggleSiteSecurityPopover}
                title="Connection is Secure (TLS 1.3) - Click for certificate & permissions"
                className="flex items-center gap-1.5 mr-2 text-neutral-400 hover:text-emerald-400 transition-colors shrink-0"
              >
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                {activeTab.blockedTrackersCount > 0 && (
                  <span className="bg-amber-500/20 text-amber-400 text-[10px] font-mono px-1 rounded font-medium">
                    {activeTab.blockedTrackersCount}
                  </span>
                )}
              </button>
            )}

            {/* URL / Search Input */}
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onFocus={() => {
                setIsFocused(true);
                // When focusing, show full URL for editing
                setInputValue(
                  activeTab.url === 'nano://newtab' ||
                  activeTab.url === 'nano://incognito' ||
                  activeTab.url === 'nova://newtab'
                    ? ''
                    : activeTab.url
                );
              }}
              onBlur={() => {
                // Short delay to allow clicking suggestions
                setTimeout(() => setIsFocused(false), 200);
              }}
              onKeyDown={handleKeyDown}
              placeholder={activeTab.isIncognito ? "Search privately or enter address" : "Search Google or enter address"}
              className="w-full bg-transparent text-xs text-neutral-100 placeholder-neutral-500 outline-none font-normal"
            />

            {/* Quick Actions inside Omnibox */}
            <div className="flex items-center gap-1 shrink-0 ml-2">
              {activeTab.url && activeTab.url !== 'nova://newtab' && (
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  title={copied ? "Copied URL!" : "Copy link"}
                  className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              )}

              <button
                type="button"
                onClick={onToggleBookmark}
                title={isBookmarked ? "Edit bookmark" : "Bookmark this tab"}
                className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-amber-400 transition-colors"
              >
                <Star
                  className={`w-3.5 h-3.5 ${
                    isBookmarked ? 'fill-amber-400 text-amber-400' : 'text-neutral-400'
                  }`}
                />
              </button>
            </div>
          </div>
        </form>

        {/* Omnibox Autocomplete & Suggestions Dropdown */}
        {isFocused && suggestions.length > 0 && (
          <div className="absolute top-10 left-0 right-0 z-50 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl overflow-hidden py-1">
            {suggestions.map((suggestion, index) => (
              <div
                key={index}
                onMouseDown={() => {
                  onNavigate(parseOmniboxInput(suggestion, settings.searchEngine));
                }}
                className={`px-4 py-2 flex items-center gap-3 text-xs cursor-pointer ${
                  selectedSuggestionIndex === index
                    ? 'bg-amber-500/15 text-amber-300'
                    : 'text-neutral-300 hover:bg-neutral-800'
                }`}
              >
                <Search className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                <span className="truncate flex-1">{suggestion}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Right Toolbar Actions */}
      <div className="flex items-center gap-1 shrink-0">
        {/* NANO VPN Quick Button */}
        <button
          onClick={() => onNavigate('nano://vpn')}
          title="NANO VPN & WireGuard Tunnel (nano://vpn)"
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium border border-cyan-500/30 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 transition-colors"
        >
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-mono text-[11px] font-semibold hidden sm:inline">VPN</span>
        </button>

        {/* Nano Shields Popover Trigger */}
        <button
          onClick={onToggleShieldsPopover}
          title={`Nano Shields (${activeTab.shieldsEnabled ? 'UP' : 'DOWN'})`}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
            shieldsPopoverOpen || activeTab.shieldsEnabled
              ? 'bg-amber-500/15 border-amber-500/40 text-amber-400 hover:bg-amber-500/25'
              : 'border-neutral-800 hover:bg-neutral-800 text-neutral-400'
          }`}
        >
          <Shield className="w-3.5 h-3.5 text-amber-500" />
          <span className="font-mono text-[11px] font-semibold">{activeTab.blockedTrackersCount}</span>
        </button>

        {/* Zoom Controls Button */}
        <button
          onClick={onToggleZoomPopover}
          title="Zoom controls"
          className="p-1.5 rounded-md hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
        >
          <ZoomIn className="w-4 h-4" />
        </button>

        {/* Downloads Button */}
        <button
          onClick={onToggleDownloadsPopover}
          title="Downloads manager"
          className="relative p-1.5 rounded-md hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
        >
          <Download className="w-4 h-4" />
          {activeDownloadsCount > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
          )}
        </button>

        {/* More Options / Settings Menu */}
        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            title="Customize and control Nano"
            className="p-1.5 rounded-md hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 top-10 z-50 w-56 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-1 text-xs text-neutral-200 backdrop-blur-md">
              <button
                onClick={() => {
                  onNavigate('nano://newtab');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between"
              >
                <span>New tab</span>
                <span className="text-[10px] text-neutral-500">Ctrl+T</span>
              </button>

              <button
                onClick={() => {
                  onNewIncognitoTab();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-purple-950/60 text-purple-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <svg
                    width="13"
                    height="13"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                    className="text-purple-400"
                  >
                    <circle cx="7" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
                    <circle cx="17" cy="14" r="3.5" stroke="currentColor" strokeWidth="2" />
                    <path d="M10.5 13.5C11.5 12.5 12.5 12.5 13.5 13.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                    <path d="M4 8C7 7 9 5 12 5C15 5 17 7 20 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                  <span>New Incognito tab</span>
                </div>
                <span className="text-[10px] text-purple-400">Ctrl+Shift+N</span>
              </button>

              <button
                onClick={() => {
                  onOpenDesktopGuide();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center gap-2 text-amber-400"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Windows 10/11 Installer</span>
              </button>

              <div className="h-px bg-neutral-800 my-1" />

              <button
                onClick={() => {
                  onNavigate('nano://bookmarks');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between"
              >
                <span>Bookmarks manager</span>
                <span className="text-[10px] text-neutral-500">Ctrl+Shift+O</span>
              </button>

              <button
                onClick={() => {
                  onNavigate('nano://history');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between"
              >
                <span>History</span>
                <span className="text-[10px] text-neutral-500">Ctrl+H</span>
              </button>

              <button
                onClick={() => {
                  onNavigate('nano://downloads');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between"
              >
                <span>Downloads</span>
                <span className="text-[10px] text-neutral-500">Ctrl+J</span>
              </button>

              <button
                onClick={() => {
                  onOpenPasswordsPage();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-purple-950/60 text-purple-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Key className="w-3.5 h-3.5 text-purple-400" />
                  <span>Password Vault</span>
                </div>
                <span className="text-[10px] text-purple-400 font-mono">AES-256</span>
              </button>

              <button
                onClick={() => {
                  onNavigate('nano://vpn');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-cyan-500/15 text-cyan-400 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>NANO VPN & WireGuard</span>
                </div>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-bold">
                  TUNNEL
                </span>
              </button>

              <button
                onClick={() => {
                  onOpenSecurityCenter();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-amber-500/15 text-amber-400 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>NANO Security Center</span>
                </div>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold">
                  DEFENSE
                </span>
              </button>

              <button
                onClick={() => {
                  onOpenClearDataModal();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between text-neutral-300"
              >
                <div className="flex items-center gap-2">
                  <Trash2 className="w-3.5 h-3.5 text-neutral-400" />
                  <span>Clear browsing data...</span>
                </div>
                <span className="text-[10px] text-neutral-500">Ctrl+Shift+Del</span>
              </button>

              <div className="h-px bg-neutral-800 my-1" />

              <button
                onClick={() => {
                  onOpenSettings();
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800"
              >
                Settings
              </button>

              <button
                onClick={() => {
                  onNavigate('nano://about');
                  setMenuOpen(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-800 text-neutral-400"
              >
                About Nano Browser
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

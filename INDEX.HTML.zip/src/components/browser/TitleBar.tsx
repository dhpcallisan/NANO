import React, { useState } from 'react';
import { Minus, Square, Copy, X, ShieldAlert, Monitor, ShieldCheck } from 'lucide-react';
import { NanoLogo } from '../brand/NanoLogo';

interface TitleBarProps {
  isPrivate: boolean;
  onTogglePrivate: () => void;
  onOpenDesktopGuide: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  isPrivate,
  onTogglePrivate,
  onOpenDesktopGuide
}) => {
  const [isMaximized, setIsMaximized] = useState(false);

  const handleMinimize = () => {
    if ((window as any).novaAPI?.minimizeWindow) {
      (window as any).novaAPI.minimizeWindow();
    }
  };

  const handleMaximize = () => {
    if ((window as any).novaAPI?.maximizeWindow) {
      (window as any).novaAPI.maximizeWindow();
      setIsMaximized(!isMaximized);
    } else {
      setIsMaximized(!isMaximized);
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    }
  };

  const handleClose = () => {
    if ((window as any).novaAPI?.closeWindow) {
      (window as any).novaAPI.closeWindow();
    }
  };

  return (
    <div
      className={`h-9 select-none flex items-center justify-between px-3 text-xs border-b border-neutral-800/80 transition-colors ${
        isPrivate ? 'bg-purple-950/40 text-purple-200' : 'bg-neutral-900/95 text-neutral-300'
      }`}
    >
      {/* Left: Brand Identity & Session Type */}
      <div className="flex items-center gap-3">
        <NanoLogo size={18} showText />

        {isPrivate ? (
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium bg-purple-900/60 text-purple-200 border border-purple-700/50">
            <ShieldAlert className="w-3 h-3 text-purple-300" />
            <span>Private Window</span>
          </div>
        ) : (
          <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-neutral-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>Shields Active</span>
          </div>
        )}
      </div>

      {/* Middle: Draggable window placeholder & Windows desktop status */}
      <div className="flex-1 text-center truncate mx-4 text-[11px] text-neutral-500 font-mono hidden md:block">
        Nano Browser 1.0 (Windows 10/11 x64 Architecture)
      </div>

      {/* Right: Quick actions & Window Controls */}
      <div className="flex items-center gap-1">
        <button
          onClick={onTogglePrivate}
          title={isPrivate ? "Switch to standard session" : "Open private browsing window"}
          className={`px-2 py-1 rounded text-[11px] font-medium transition-colors ${
            isPrivate
              ? 'bg-purple-800 text-purple-100 hover:bg-purple-700'
              : 'hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200'
          }`}
        >
          {isPrivate ? 'Exit Private' : 'Private Window'}
        </button>

        <button
          onClick={onOpenDesktopGuide}
          title="Windows Desktop Build & Packaging Instructions"
          className="flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium text-amber-400/90 hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
        >
          <Monitor className="w-3 h-3" />
          <span className="hidden sm:inline">Windows Release</span>
        </button>

        {/* Windows standard titlebar buttons */}
        <div className="flex items-center ml-2 border-l border-neutral-800/80 pl-2">
          <button
            onClick={handleMinimize}
            className="w-8 h-7 flex items-center justify-center hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
            title="Minimize"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleMaximize}
            className="w-8 h-7 flex items-center justify-center hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
            title={isMaximized ? "Restore Down" : "Maximize"}
          >
            {isMaximized ? <Copy className="w-3 h-3 rotate-180" /> : <Square className="w-3 h-3" />}
          </button>
          <button
            onClick={handleClose}
            className="w-8 h-7 flex items-center justify-center hover:bg-red-600 hover:text-white text-neutral-400 transition-colors"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};

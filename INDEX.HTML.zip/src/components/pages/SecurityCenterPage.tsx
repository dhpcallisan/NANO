import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  Lock,
  LockOpen,
  Key,
  Globe,
  Camera,
  Mic,
  MapPin,
  Bell,
  Trash2,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  Network,
  Cpu,
  FileCode,
  Clock,
  Radio
} from 'lucide-react';
import {
  BrowserSettings,
  SecurityEvent,
  SitePermission,
  ShieldStats
} from '../../types/browser';
import {
  THREAT_DATABASE_VERSION,
  THREAT_DATABASE_LAST_UPDATED,
  KNOWN_THREAT_RECORDS
} from '../../services/threatIntelligence';
import { KNOWN_TRACKERS } from '../../services/adblockEngine';

interface SecurityCenterPageProps {
  settings: BrowserSettings;
  stats: ShieldStats;
  securityLogs: SecurityEvent[];
  sitePermissions: SitePermission[];
  onUpdateSettings: (newSettings: Partial<BrowserSettings>) => void;
  onClearSecurityLogs: () => void;
  onRevokePermission: (origin: string, type: 'camera' | 'microphone' | 'location' | 'notifications') => void;
  onClearAllPermissions: () => void;
  onOpenPasswordsPage: () => void;
}

export const SecurityCenterPage: React.FC<SecurityCenterPageProps> = ({
  settings,
  stats,
  securityLogs,
  sitePermissions,
  onUpdateSettings,
  onClearSecurityLogs,
  onRevokePermission,
  onClearAllPermissions,
  onOpenPasswordsPage
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'events' | 'permissions' | 'network' | 'threats' | 'ssl'>('overview');
  const [eventFilter, setEventFilter] = useState<'all' | 'high' | 'tracker' | 'phishing'>('all');
  const [sslData, setSslData] = useState<any>(null);
  const [loadingSsl, setLoadingSsl] = useState(false);

  const checkSslDiagnostics = async () => {
    setLoadingSsl(true);
    try {
      const res = await fetch('/api/security/ssl-status');
      if (res.ok) {
        const data = await res.json();
        setSslData(data);
      }
    } catch {
      // Offline fallback
    } finally {
      setLoadingSsl(false);
    }
  };

  const filteredLogs = securityLogs.filter((log) => {
    if (eventFilter === 'all') return true;
    if (eventFilter === 'high') return log.severity === 'high' || log.severity === 'critical';
    if (eventFilter === 'tracker') return log.type === 'tracker_blocked';
    if (eventFilter === 'phishing') return log.type === 'phishing_blocked' || log.type === 'malware_blocked';
    return true;
  });

  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 flex flex-col overflow-hidden select-none">
      {/* Header */}
      <div className="p-6 border-b border-neutral-800 bg-neutral-900/40 shrink-0">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-neutral-100 flex items-center gap-2">
                <span>NANO Security Center</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  SHIELDS ACTIVE
                </span>
              </h1>
              <p className="text-xs text-neutral-400">
                Threat Intelligence, Website Isolation, TLS Enforcement & Audit Logging
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenPasswordsPage}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-200 border border-neutral-700 transition-colors"
            >
              <Key className="w-3.5 h-3.5 text-purple-400" />
              <span>Password Vault</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-6xl mx-auto flex items-center gap-1 mt-6 border-b border-neutral-800 -mb-6 overflow-x-auto">
          {[
            { id: 'overview', label: 'Security Health' },
            { id: 'events', label: `Audit Log (${securityLogs.length})` },
            { id: 'permissions', label: `Site Permissions (${sitePermissions.length})` },
            { id: 'network', label: 'Network & VPN' },
            { id: 'ssl', label: 'HTTPS & SSL/TLS Deployment' },
            { id: 'threats', label: 'Threat Intelligence Feed' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                if (tab.id === 'ssl' && !sslData) {
                  checkSslDiagnostics();
                }
              }}
              className={`px-4 py-2.5 text-xs font-medium border-b-2 transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'border-amber-500 text-amber-400'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Security Metrics Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>HTTPS Enforcement</span>
                    <Lock className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-xl font-bold text-neutral-100">TLS 1.3 Strict</div>
                  <div className="text-[11px] text-emerald-400">Insecure HTTP warned by default</div>
                </div>

                <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Trackers Blocked</span>
                    <Shield className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-xl font-bold text-neutral-100 font-mono">
                    {stats.trackersBlockedTotal.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-neutral-400">{KNOWN_TRACKERS.length}+ filter rules active</div>
                </div>

                <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Threat Feed Version</span>
                    <Radio className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="text-xl font-bold text-neutral-100 font-mono text-sm">
                    {THREAT_DATABASE_VERSION}
                  </div>
                  <div className="text-[11px] text-cyan-400">Zero-day feeds updated</div>
                </div>

                <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Site Isolation Sandbox</span>
                    <Cpu className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-xl font-bold text-neutral-100">Hardened</div>
                  <div className="text-[11px] text-purple-400">Process boundary active</div>
                </div>
              </div>

              {/* Core Security Controls Card */}
              <div className="p-6 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-5">
                <h3 className="text-sm font-bold text-neutral-100">Production Security Controls</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-neutral-200">HTTPS-First Mode</div>
                      <div className="text-[11px] text-neutral-400">Automatically upgrade HTTP connections to HTTPS</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.httpsEverywhere}
                      onChange={(e) => onUpdateSettings({ httpsEverywhere: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-neutral-200">Insecure HTTP Interstitial Warning</div>
                      <div className="text-[11px] text-neutral-400">Halt navigation and display security screen for unencrypted pages</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.insecureHttpWarning}
                      onChange={(e) => onUpdateSettings({ insecureHttpWarning: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-neutral-200">Phishing & Deceptive Site Defense</div>
                      <div className="text-[11px] text-neutral-400">Block known credential harvesting vectors and brand impersonators</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.phishingProtection}
                      onChange={(e) => onUpdateSettings({ phishingProtection: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                  <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-neutral-200">Malware & Malicious Download Inspection</div>
                      <div className="text-[11px] text-neutral-400">Heuristically inspect binaries, double-extensions, and exploits</div>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.malwareProtection}
                      onChange={(e) => onUpdateSettings({ malwareProtection: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: AUDIT LOG */}
          {activeTab === 'events' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  {(['all', 'high', 'tracker', 'phishing'] as const).map((filter) => (
                    <button
                      key={filter}
                      onClick={() => setEventFilter(filter)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${
                        eventFilter === filter
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                          : 'bg-neutral-900 text-neutral-400 hover:text-neutral-200 border border-neutral-800'
                      }`}
                    >
                      {filter} Events
                    </button>
                  ))}
                </div>

                <button
                  onClick={onClearSecurityLogs}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-red-500/15 border border-neutral-800 hover:border-red-500/40 text-xs text-neutral-400 hover:text-red-300 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear Audit Logs</span>
                </button>
              </div>

              {filteredLogs.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-neutral-900/50 border border-neutral-800 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <h3 className="text-sm font-semibold text-neutral-200">No Security Events Logged</h3>
                  <p className="text-xs text-neutral-400">Your session has encountered no active security violations.</p>
                </div>
              ) : (
                <div className="rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden">
                  <div className="divide-y divide-neutral-800">
                    {filteredLogs.map((log) => (
                      <div key={log.id} className="p-4 flex items-start justify-between gap-4 text-xs hover:bg-neutral-850 transition-colors">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold ${
                                log.severity === 'critical'
                                  ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                                  : log.severity === 'high'
                                  ? 'bg-orange-500/20 text-orange-300 border border-orange-500/30'
                                  : log.severity === 'medium'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                  : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                              }`}
                            >
                              {log.severity}
                            </span>
                            <span className="font-semibold text-neutral-200">{log.title}</span>
                          </div>
                          <div className="text-neutral-400 font-mono text-[11px]">{log.domain}</div>
                          {log.details && <div className="text-neutral-500 text-[11px]">{log.details}</div>}
                        </div>
                        <span className="text-[10px] text-neutral-500 font-mono whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SITE PERMISSIONS */}
          {activeTab === 'permissions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-neutral-100">Site Permissions Manager</h3>
                  <p className="text-xs text-neutral-400">Review and revoke hardware sensor and notification access.</p>
                </div>
                {sitePermissions.length > 0 && (
                  <button
                    onClick={onClearAllPermissions}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-red-500/15 border border-neutral-800 hover:border-red-500/40 text-xs text-neutral-400 hover:text-red-300 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Revoke All Permissions</span>
                  </button>
                )}
              </div>

              {sitePermissions.length === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-neutral-900/50 border border-neutral-800 space-y-2">
                  <ShieldCheck className="w-8 h-8 text-neutral-500 mx-auto" />
                  <h3 className="text-sm font-semibold text-neutral-200">No Custom Permissions Granted</h3>
                  <p className="text-xs text-neutral-400">All websites are held to zero-trust secure defaults (Prompt or Deny).</p>
                </div>
              ) : (
                <div className="rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden divide-y divide-neutral-800">
                  {sitePermissions.map((perm) => (
                    <div key={perm.origin} className="p-4 flex items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="font-semibold text-xs text-neutral-200 font-mono">{perm.origin}</div>
                        <div className="flex items-center gap-3 text-xs text-neutral-400">
                          <span className="flex items-center gap-1">
                            <Camera className="w-3.5 h-3.5 text-neutral-500" /> {perm.camera}
                          </span>
                          <span className="flex items-center gap-1">
                            <Mic className="w-3.5 h-3.5 text-neutral-500" /> {perm.microphone}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-neutral-500" /> {perm.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <Bell className="w-3.5 h-3.5 text-neutral-500" /> {perm.notifications}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => onRevokePermission(perm.origin, 'camera')}
                        className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-red-500/20 text-xs text-neutral-300 hover:text-red-300 transition-colors"
                      >
                        Revoke
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: NETWORK & VPN TRANSPARENCY */}
          {activeTab === 'network' && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3">
                <div className="flex items-center gap-2 font-bold text-sm text-neutral-100">
                  <Network className="w-4 h-4 text-amber-400" />
                  <span>Honest VPN & Network Architecture Disclosure</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  In compliance with NANO Browser Security Guidelines, NANO never simulates fake VPN connections or displays false connected statuses. A legitimate VPN requires an authenticated WireGuard or OpenVPN tunnel driver at the operating system layer.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                  <div className="text-xs font-bold text-neutral-200 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-neutral-500" />
                    <span>VPN Tunnel Status: Disconnected / Not Configured</span>
                  </div>
                  <p className="text-xs text-neutral-400">
                    No verified third-party VPN tunnel profile is currently attached. Traffic is routed directly through your standard network interface.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-2">
                  <div className="text-xs font-bold text-neutral-200 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>DNS-over-HTTPS (DoH): Active (Cloudflare / Quad9)</span>
                  </div>
                  <p className="text-xs text-neutral-400">
                    DNS inquiries are encrypted over TLS, preventing local Wi-Fi eavesdroppers from sniffing resolved domain names.
                  </p>
                </div>
              </div>

              {/* Comparison table */}
              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 text-xs">
                <div className="font-bold text-neutral-200">Security Distinction: VPN vs. Proxy vs. Private Mode</div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-neutral-400">
                    <thead className="border-b border-neutral-800 text-neutral-200 font-semibold">
                      <tr>
                        <th className="py-2">Feature</th>
                        <th className="py-2">IP Hidden</th>
                        <th className="py-2">Local History Isolated</th>
                        <th className="py-2">Encrypted Tunnel</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-800/60">
                      <tr>
                        <td className="py-2 font-medium text-neutral-300">NANO Private Window</td>
                        <td className="py-2 text-red-400">No (Revealed to sites)</td>
                        <td className="py-2 text-emerald-400">Yes (Wiped on close)</td>
                        <td className="py-2 text-neutral-400">Standard HTTPS</td>
                      </tr>
                      <tr>
                        <td className="py-2 font-medium text-neutral-300">Proxy Mode</td>
                        <td className="py-2 text-emerald-400">Yes (Proxy IP shown)</td>
                        <td className="py-2 text-neutral-400">Depends on session</td>
                        <td className="py-2 text-amber-400">Application level only</td>
                      </tr>
                      <tr>
                        <td className="py-2 font-medium text-neutral-300">Native OS VPN</td>
                        <td className="py-2 text-emerald-400">Yes (VPN exit node)</td>
                        <td className="py-2 text-neutral-400">No (Use Incognito)</td>
                        <td className="py-2 text-emerald-400">Yes (System-wide tunnel)</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB: HTTPS & PRODUCTION SSL/TLS DEPLOYMENT */}
          {activeTab === 'ssl' && (
            <div className="space-y-6">
              {/* Header Card */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-emerald-400" />
                    <h3 className="text-sm font-bold text-neutral-100">HTTPS, SSL/TLS & Production Deployment Architecture</h3>
                    <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      TLS 1.3 ENFORCED
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400">
                    Production traffic terminates at Google Cloud edge reverse proxies with automated Google Trust Services TLS certificates.
                  </p>
                </div>

                <button
                  onClick={checkSslDiagnostics}
                  disabled={loadingSsl}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 border border-neutral-700 transition-colors shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingSsl ? 'animate-spin text-amber-400' : 'text-neutral-400'}`} />
                  <span>{loadingSsl ? 'Checking Endpoints...' : 'Run Live TLS Audit'}</span>
                </button>
              </div>

              {/* Status Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                  <div className="text-neutral-400 flex items-center justify-between">
                    <span>Protocol & Transport</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-base font-bold text-neutral-100 font-mono">
                    {sslData?.protocol?.toUpperCase() || 'HTTPS (Strict)'}
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    {sslData?.tlsVersionEnforced || 'TLS 1.3 / Strict Cipher Negotiation'}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                  <div className="text-neutral-400 flex items-center justify-between">
                    <span>Managed CA Certificate</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-base font-bold text-neutral-100 font-mono">
                    Google Trust Services
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    Automated zero-touch 90-day renewal
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                  <div className="text-neutral-400 flex items-center justify-between">
                    <span>HSTS Protection</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-base font-bold text-neutral-100 font-mono">
                    31,536,000s (1 Year)
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    includeSubDomains enforced
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-1.5">
                  <div className="text-neutral-400 flex items-center justify-between">
                    <span>Mixed-Content Shield</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                  <div className="text-base font-bold text-neutral-100 font-mono">
                    Zero Mixed Content
                  </div>
                  <div className="text-[11px] text-neutral-500">
                    upgrade-insecure-requests CSP directive
                  </div>
                </div>
              </div>

              {/* Security Headers Breakdown */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 text-xs">
                <div className="font-bold text-neutral-200 flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-purple-400" />
                  <span>Enforced Production Security Headers</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800 space-y-1 font-mono">
                    <div className="text-neutral-200 font-semibold font-sans">Strict-Transport-Security (HSTS)</div>
                    <div className="text-emerald-400 text-[11px]">max-age=31536000; includeSubDomains</div>
                    <div className="text-neutral-500 text-[10px] font-sans">Prevents SSL-stripping and forces browsers to only connect over HTTPS.</div>
                  </div>

                  <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800 space-y-1 font-mono">
                    <div className="text-neutral-200 font-semibold font-sans">Content-Security-Policy (CSP)</div>
                    <div className="text-emerald-400 text-[11px]">upgrade-insecure-requests; object-src &apos;none&apos;; base-uri &apos;self&apos;</div>
                    <div className="text-neutral-500 text-[10px] font-sans">Automates HTTPS resource upgrades and mitigates cross-site scripting (XSS).</div>
                  </div>

                  <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800 space-y-1 font-mono">
                    <div className="text-neutral-200 font-semibold font-sans">X-Content-Type-Options & Frame-Options</div>
                    <div className="text-emerald-400 text-[11px]">nosniff | SAMEORIGIN</div>
                    <div className="text-neutral-500 text-[10px] font-sans">Blocks MIME-type sniffing and guards against UI clickjacking.</div>
                  </div>

                  <div className="p-3 rounded-xl bg-neutral-950/70 border border-neutral-800 space-y-1 font-mono">
                    <div className="text-neutral-200 font-semibold font-sans">Referrer-Policy & Permissions-Policy</div>
                    <div className="text-emerald-400 text-[11px]">strict-origin-when-cross-origin | camera=(self), mic=(self)</div>
                    <div className="text-neutral-500 text-[10px] font-sans">Redacts sensitive URL parameters and restricts device hardware to verified origins.</div>
                  </div>
                </div>
              </div>

              {/* Reverse Proxy & Custom Domain Deployment Guide */}
              <div className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-3 text-xs">
                <div className="font-bold text-neutral-200 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  <span>Production Hosting & Custom Domain Deployment</span>
                </div>

                <div className="space-y-2 text-neutral-300 leading-relaxed">
                  <p>
                    NANO Browser is containerized for production on <strong>Google Cloud Run</strong> with automatic TLS provisioning managed directly by Google edge infrastructure.
                  </p>
                  <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
                    <div className="font-semibold text-neutral-200">Custom Domain Mapping Steps:</div>
                    <ol className="list-decimal list-inside space-y-1 text-neutral-400">
                      <li>In Google Cloud Console or your DNS provider, navigate to <strong>Cloud Run &gt; Manage Custom Domains</strong>.</li>
                      <li>Add your verified domain (e.g., <code className="text-amber-400 font-mono">browser.yourcompany.com</code>).</li>
                      <li>Add the required <code className="text-amber-400 font-mono">CNAME</code> record pointing to <code className="text-cyan-400 font-mono">ghs.googlehosted.com</code> in your registrar (Cloudflare, Namecheap, Route 53).</li>
                      <li>Google Trust Services automatically negotiates and issues the TLS certificate. Provisioning completes in 15–30 minutes with zero manual certificate files required.</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: THREATS */}
          {activeTab === 'threats' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-neutral-100">Live Threat Intelligence Database</h3>
                  <p className="text-xs text-neutral-400">
                    Synchronized threat feed protecting against phishing campaigns, malware drop points, and cryptojackers.
                  </p>
                </div>
                <div className="text-[11px] font-mono text-neutral-400 bg-neutral-900 px-3 py-1.5 rounded-lg border border-neutral-800">
                  Feed Version: {THREAT_DATABASE_VERSION}
                </div>
              </div>

              <div className="rounded-2xl bg-neutral-900 border border-neutral-800 overflow-hidden divide-y divide-neutral-800 text-xs">
                {KNOWN_THREAT_RECORDS.map((threat) => (
                  <div key={threat.domainOrPattern} className="p-4 flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-neutral-200">{threat.domainOrPattern}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-red-500/20 text-red-300 border border-red-500/30">
                          {threat.category}
                        </span>
                      </div>
                      <p className="text-neutral-400">{threat.description}</p>
                    </div>
                    <span className="text-[11px] text-neutral-500 font-mono">{threat.source}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

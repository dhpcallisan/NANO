/**
 * NOVA BROWSER — High-Performance Native Content Blocking Engine
 * Uses fast Set lookups and regex pattern matching for webRequest interception
 */

export class NovaContentBlocker {
  private blockedDomains: Set<string>;
  private blockedRules: RegExp[];
  private siteExceptions: Set<string>; // Sites where shields are turned off
  private blockedCounter: number = 0;

  constructor() {
    this.siteExceptions = new Set();
    this.blockedDomains = new Set([
      'google-analytics.com',
      'googletagmanager.com',
      'doubleclick.net',
      'googleadservices.com',
      'pagead2.googlesyndication.com',
      'adservice.google.com',
      'facebook.com',
      'connect.facebook.net',
      'criteo.com',
      'taboola.com',
      'outbrain.com',
      'adnxs.com',
      'scorecardresearch.com',
      'quantserve.com',
      'hotjar.com',
      'clarity.ms',
      'segment.io',
      'mixpanel.com',
      'amplitude.com',
      'newrelic.com',
      'datadoghq-browser-agent.com',
      'adroll.com',
      'rubiconproject.com',
      'pubmatic.com',
      'openx.net',
      'casalemedia.com',
      'smartadserver.com',
      'moatads.com',
      'advertising.amazon.com',
      'amazon-adsystem.com',
      'ads-twitter.com',
      'analytics.twitter.com',
      'ads.linkedin.com',
      'pixel.wp.com',
      'chartbeat.com',
      'branch.io',
      'appsflyer.com',
      'adjust.com',
      'optimizely.com',
      'vwo.com',
      'mouseflow.com',
      'fullstory.com',
      'sentry-cdn.com',
      'bugsnag.com'
    ]);

    this.blockedRules = [
      /\/ads?\.(?:js|gif|png|jpe?g)$/i,
      /\/prebid(?:\.min)?\.js/i,
      /\/telemetry\/.*\.js/i,
      /\/analytics\/.*\.js/i,
      /\/tracking\/.*\.php/i,
      /\/pixel\.(?:gif|png)/i
    ];
  }

  public shouldBlock(requestUrl: string, initiatorOrigin?: string): boolean {
    try {
      const parsed = new URL(requestUrl);
      const hostname = parsed.hostname.toLowerCase();

      // Check if user disabled shields on initiator site
      if (initiatorOrigin) {
        try {
          const initiatorHost = new URL(initiatorOrigin).hostname.toLowerCase();
          if (this.siteExceptions.has(initiatorHost)) {
            return false;
          }
        } catch {
          // Continue
        }
      }

      // Check direct domain matching
      for (const domain of this.blockedDomains) {
        if (hostname === domain || hostname.endsWith('.' + domain)) {
          this.blockedCounter++;
          return true;
        }
      }

      // Check path rules
      const fullPath = parsed.pathname + parsed.search;
      for (const rule of this.blockedRules) {
        if (rule.test(fullPath)) {
          this.blockedCounter++;
          return true;
        }
      }

      return false;
    } catch {
      return false;
    }
  }

  public toggleSiteShields(domain: string, enabled: boolean): void {
    if (enabled) {
      this.siteExceptions.delete(domain.toLowerCase());
    } else {
      this.siteExceptions.add(domain.toLowerCase());
    }
  }

  public isSiteShieldsEnabled(domain: string): boolean {
    return !this.siteExceptions.has(domain.toLowerCase());
  }

  public getTotalBlockedCount(): number {
    return this.blockedCounter;
  }
}

import React from 'react';
import { Download, FileText, CheckCircle2, Clock, X, ExternalLink } from 'lucide-react';
import { DownloadItem } from '../../types/browser';

interface DownloadsPopoverProps {
  downloads: DownloadItem[];
  onOpenDownload: (item: DownloadItem) => void;
  onOpenDownloadsPage: () => void;
  onClose: () => void;
}

export const DownloadsPopover: React.FC<DownloadsPopoverProps> = ({
  downloads,
  onOpenDownload,
  onOpenDownloadsPage,
  onClose
}) => {
  return (
    <div className="absolute top-12 right-10 z-50 w-80 bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden text-neutral-200 backdrop-blur-xl select-none animate-in fade-in zoom-in-95 duration-150">
      <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-semibold text-neutral-100">
          <Download className="w-4 h-4 text-amber-500" />
          <span>Recent Downloads</span>
        </div>
        <button
          onClick={onClose}
          className="text-neutral-500 hover:text-neutral-300 transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="max-h-72 overflow-y-auto divide-y divide-neutral-800/80">
        {downloads.slice(0, 5).map((item) => (
          <div
            key={item.id}
            className="p-3 hover:bg-neutral-850 flex items-center justify-between gap-3 transition-colors group cursor-pointer"
            onClick={() => onOpenDownload(item)}
          >
            <div className="flex items-center gap-2.5 min-w-0 flex-1">
              <div className="w-8 h-8 rounded-lg bg-neutral-800 flex items-center justify-center shrink-0">
                <FileText className="w-4 h-4 text-amber-500" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium text-neutral-200 truncate group-hover:text-amber-400">
                  {item.fileName}
                </div>
                <div className="text-[10px] text-neutral-500 font-mono mt-0.5">
                  {item.fileSize} · {item.status}
                </div>
              </div>
            </div>

            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          </div>
        ))}

        {downloads.length === 0 && (
          <div className="p-6 text-center text-neutral-500 text-xs">
            No downloads yet
          </div>
        )}
      </div>

      <div className="p-2.5 bg-neutral-950/80 border-t border-neutral-800 text-center">
        <button
          onClick={() => {
            onOpenDownloadsPage();
            onClose();
          }}
          className="text-xs text-amber-400 hover:text-amber-300 font-medium transition-colors"
        >
          Show all downloads
        </button>
      </div>
    </div>
  );
};

import React from 'react';
import { Shield, Zap, Clock, Lock, EyeOff, Cookie, AlertTriangle, FileCheck, Info } from 'lucide-react';
import { ShieldStats, BrowserSettings } from '../../types/browser';
import { formatBytesSaved, formatTimeSaved } from '../../services/adblockEngine';
import { NanoLogo } from '../brand/NanoLogo';

interface ShieldsDashboardPageProps {
  stats: ShieldStats;
  settings: BrowserSettings;
  onUpdateSettings: (newSettings: Partial<BrowserSettings>) => void;
}

export const ShieldsDashboardPage: React.FC<ShieldsDashboardPageProps> = ({
  stats,
  settings,
  onUpdateSettings
}) => {
  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 overflow-y-auto p-8 select-none">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Title */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-500" />
              <span>Nano Shields Privacy Dashboard</span>
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">
              Live protection metrics, telemetry prevention, and network security statistics.
            </p>
          </div>
          <NanoLogo size={24} />
        </div>

        {/* Big 3 Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <Shield className="w-4 h-4 text-amber-500" />
              <span>Total Trackers & Ads Blocked</span>
            </div>
            <div className="font-mono text-3xl font-bold text-neutral-100 tabular-nums">
              {stats.trackersBlockedTotal.toLocaleString()}
            </div>
            <p className="text-[11px] text-neutral-500">
              Cross-site trackers stopped from monitoring your web activity.
            </p>
          </div>

          <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <Zap className="w-4 h-4 text-emerald-400" />
              <span>Bandwidth Saved</span>
            </div>
            <div className="font-mono text-3xl font-bold text-neutral-100 tabular-nums">
              {formatBytesSaved(stats.bandwidthSavedKB)}
            </div>
            <p className="text-[11px] text-neutral-500">
              Data not wasted downloading heavy advertisement payloads.
            </p>
          </div>

          <div className="p-5 bg-neutral-900 border border-neutral-800 rounded-2xl space-y-2">
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Estimated Time Saved</span>
            </div>
            <div className="font-mono text-3xl font-bold text-neutral-100 tabular-nums">
              {formatTimeSaved(stats.timeSavedMs)}
            </div>
            <p className="text-[11px] text-neutral-500">
              Page render latency saved by preventing script execution.
            </p>
          </div>
        </div>

        {/* Protection Categories */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-neutral-200">Active Filter Categories</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-neutral-900/60 border border-neutral-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-200">Behavioral Advertising Networks</span>
                <span className="text-[11px] font-mono text-amber-400 font-medium">ACTIVE</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-normal">
                Prevents ad servers (Google AdServices, Criteo, Taboola, Outbrain, Amazon AdSystem) from serving tracking banners and popups.
              </p>
            </div>

            <div className="p-4 bg-neutral-900/60 border border-neutral-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-200">Cross-Site Analytics & Telemetry</span>
                <span className="text-[11px] font-mono text-amber-400 font-medium">ACTIVE</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-normal">
                Blocks tracking scripts (Google Analytics, Segment, Mixpanel, Hotjar, Clarity, New Relic) from recording clickmaps and keystrokes.
              </p>
            </div>

            <div className="p-4 bg-neutral-900/60 border border-neutral-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-200">Social Graph Pixels</span>
                <span className="text-[11px] font-mono text-amber-400 font-medium">ACTIVE</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-normal">
                Stops Facebook Meta Pixel, Twitter/X pixel, and LinkedIn Insight tags from tracking off-platform browsing behavior.
              </p>
            </div>

            <div className="p-4 bg-neutral-900/60 border border-neutral-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-200">URL Tracking Token Stripper</span>
                <span className="text-[11px] font-mono text-amber-400 font-medium">ACTIVE</span>
              </div>
              <p className="text-[11px] text-neutral-400 leading-normal">
                Removes utm_source, utm_medium, fbclid, and gclid parameters automatically when links are opened or clicked.
              </p>
            </div>
          </div>
        </div>

        {/* Transparency & Security Limits (Mandatory requirement) */}
        <div className="p-5 bg-neutral-900/40 border border-neutral-800 rounded-2xl space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-neutral-300">
            <Info className="w-4 h-4 text-cyan-400" />
            <span>Honest Security Notice & Technical Limitations</span>
          </div>
          <p className="text-xs text-neutral-400 leading-relaxed">
            Nano Shields significantly minimizes tracking, reduces page load overhead, and eliminates commercial surveillance scripts. However, content blocking does not grant total anonymity. Your Internet Service Provider (ISP) and network operators can still observe destination domain names (via DNS or SNI) unless an encrypted VPN or Tor circuit is employed. Nano Browser does not sell user data, has no telemetry collection, and processes all filtering rules locally on your device.
          </p>
        </div>
      </div>
    </div>
  );
};

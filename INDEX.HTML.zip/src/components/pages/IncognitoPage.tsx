import React, { useState } from 'react';
import {
  ShieldAlert,
  Search,
  Lock,
  EyeOff,
  Cookie,
  AlertTriangle,
  X,
  ExternalLink,
  ChevronDown,
  Check,
  ShieldCheck,
  Globe
} from 'lucide-react';
import { SearchEngineType, BrowserSettings } from '../../types/browser';
import { SEARCH_ENGINES, parseOmniboxInput } from '../../services/searchEngines';

interface IncognitoPageProps {
  settings: BrowserSettings;
  onNavigate: (url: string) => void;
  onCloseIncognitoTabs: () => void;
  incognitoTabsCount: number;
}

export const IncognitoPage: React.FC<IncognitoPageProps> = ({
  settings,
  onNavigate,
  onCloseIncognitoTabs,
  incognitoTabsCount
}) => {
  const [searchInput, setSearchInput] = useState('');
  const [selectedEngine, setSelectedEngine] = useState<SearchEngineType>(settings.searchEngine);
  const [engineDropdownOpen, setEngineDropdownOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    const targetUrl = parseOmniboxInput(searchInput, selectedEngine);
    onNavigate(targetUrl);
  };

  const quickSites = [
    { name: 'DuckDuckGo', url: 'https://duckduckgo.com', desc: 'Private Search' },
    { name: 'Wikipedia', url: 'https://www.wikipedia.org', desc: 'Encyclopedia' },
    { name: 'Startpage', url: 'https://www.startpage.com', desc: 'Private Search' },
    { name: 'Hacker News', url: 'https://news.ycombinator.com', desc: 'Tech News' }
  ];

  return (
    <div className="h-full w-full bg-[#0d0c15] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-950/25 via-[#0d0c15] to-[#07060a] text-neutral-100 flex flex-col justify-between p-8 overflow-y-auto select-none">
      {/* Top Bar with Incognito Counter and Close Action */}
      <div className="max-w-4xl mx-auto w-full flex items-center justify-between">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-950/60 border border-purple-800/50 text-xs font-medium text-purple-200">
          <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
          <span>Incognito Session ({incognitoTabsCount} {incognitoTabsCount === 1 ? 'tab' : 'tabs'} open)</span>
        </div>

        <button
          onClick={onCloseIncognitoTabs}
          title="Close all open incognito tabs immediately"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900/80 hover:bg-red-500/15 border border-neutral-800 hover:border-red-500/40 text-xs font-medium text-neutral-300 hover:text-red-300 transition-all shadow-sm"
        >
          <X className="w-3.5 h-3.5" />
          <span>Close Incognito Tabs</span>
        </button>
      </div>

      {/* Main Center Section */}
      <div className="max-w-3xl mx-auto w-full my-auto space-y-8 py-6 text-center">
        {/* Incognito Icon Emblem */}
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-20 h-20 rounded-3xl bg-gradient-to-b from-purple-900/40 via-purple-950/60 to-neutral-950 border border-purple-500/30 shadow-[0_0_50px_rgba(168,85,247,0.18)] flex items-center justify-center">
            {/* Custom SVG Incognito Mask & Hat Emblem */}
            <svg
              width="44"
              height="44"
              viewBox="0 0 48 48"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-purple-300"
            >
              {/* Fedora Hat */}
              <path
                d="M8 20C12 18 16 14 24 14C32 14 36 18 40 20C42 21 44 21 44 23C44 24 41 24 40 24H8C7 24 4 24 4 23C4 21 6 21 8 20Z"
                fill="currentColor"
                fillOpacity="0.85"
              />
              <path
                d="M13 20C14 16 17 9 24 9C31 9 34 16 35 20H13Z"
                fill="currentColor"
              />
              <rect x="13" y="18" width="22" height="2" fill="#c084fc" />

              {/* Sunglasses */}
              <circle cx="17" cy="31" r="6" stroke="#c084fc" strokeWidth="2.5" fill="#181428" />
              <circle cx="31" cy="31" r="6" stroke="#c084fc" strokeWidth="2.5" fill="#181428" />
              <path d="M23 30C25 28.5 27 28.5 29 30" stroke="#c084fc" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-neutral-100">
              You've gone incognito
            </h1>
            <p className="text-xs md:text-sm text-neutral-400 max-w-xl mx-auto leading-relaxed">
              Pages you visit in Incognito Mode won't be saved to NANO's local browsing history. Downloads and bookmarks may remain on your device, and websites, your employer or school, and your internet service provider may still be able to observe your activity.
            </p>
          </div>
        </div>

        {/* Prominent Search & Omnibox */}
        <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto relative">
          <div className="flex items-center h-12 px-4 rounded-2xl bg-neutral-900/90 border border-purple-900/50 hover:border-purple-600/70 focus-within:border-purple-500 focus-within:ring-2 focus-within:ring-purple-500/20 shadow-2xl transition-all">
            {/* Engine Picker dropdown */}
            <div className="relative mr-3">
              <button
                type="button"
                onClick={() => setEngineDropdownOpen(!engineDropdownOpen)}
                className="flex items-center gap-1 text-xs font-medium text-purple-300 hover:text-purple-100 transition-colors"
              >
                <span>{SEARCH_ENGINES[selectedEngine]?.name}</span>
                <ChevronDown className="w-3 h-3 text-purple-400" />
              </button>

              {engineDropdownOpen && (
                <div className="absolute top-8 left-0 z-50 w-44 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-1 text-xs text-left">
                  {(Object.keys(SEARCH_ENGINES) as SearchEngineType[]).map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => {
                        setSelectedEngine(key);
                        setEngineDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between text-neutral-200"
                    >
                      <span>{SEARCH_ENGINES[key].name}</span>
                      {selectedEngine === key && <Check className="w-3.5 h-3.5 text-purple-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder={`Search with ${SEARCH_ENGINES[selectedEngine]?.name} or enter URL...`}
              className="w-full bg-transparent text-sm text-neutral-100 placeholder-neutral-500 outline-none"
            />

            <button
              type="submit"
              className="p-1.5 rounded-lg bg-purple-600 text-white hover:bg-purple-500 transition-colors shrink-0"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* Quick Access Private Navigation */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          {quickSites.map((site) => (
            <button
              key={site.name}
              onClick={() => onNavigate(site.url)}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-neutral-900/60 hover:bg-purple-950/50 border border-neutral-800/80 hover:border-purple-800/60 text-xs text-neutral-300 hover:text-neutral-100 transition-all group"
            >
              <Globe className="w-3.5 h-3.5 text-purple-400 group-hover:text-purple-300" />
              <span className="font-medium">{site.name}</span>
              <span className="text-[10px] text-neutral-500">· {site.desc}</span>
            </button>
          ))}
        </div>

        {/* Honest Privacy Breakdown Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left max-w-2xl mx-auto">
          {/* What NANO Incognito Does */}
          <div className="p-4 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-purple-300">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>What Incognito Mode Protects</span>
            </div>
            <ul className="text-xs text-neutral-400 space-y-1.5 leading-normal">
              <li>• Won't save pages to your local browsing history</li>
              <li>• Uses isolated, in-memory cookies wiped when tabs close</li>
              <li>• Prevents searches from polluting regular suggestions</li>
              <li>• Blocks third-party cross-site trackers with Nano Shields</li>
            </ul>
          </div>

          {/* What it Doesn't Do */}
          <div className="p-4 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 space-y-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>What It Doesn't Hide</span>
            </div>
            <ul className="text-xs text-neutral-400 space-y-1.5 leading-normal">
              <li>• Websites you visit can still see your network IP address</li>
              <li>• Employers, schools, or ISPs may log network DNS queries</li>
              <li>• Bookmarks and downloaded files are retained on your device</li>
              <li>• Web logins will recognize your authenticated account</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="max-w-4xl mx-auto w-full text-center text-xs text-neutral-500 border-t border-purple-950/40 pt-4 flex items-center justify-between">
        <span>NANO Browser Incognito Engine</span>
        <span>Transient in-memory session active</span>
      </div>
    </div>
  );
};

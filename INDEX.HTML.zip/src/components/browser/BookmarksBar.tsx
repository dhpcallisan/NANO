import React, { useState, useRef, useEffect } from 'react';
import { BookmarkItem, BookmarkFolder } from '../../types/browser';
import { Folder, Globe, ChevronDown, MoreHorizontal } from 'lucide-react';

interface BookmarksBarProps {
  bookmarks: BookmarkItem[];
  folders: BookmarkFolder[];
  onNavigate: (url: string) => void;
  onOpenBookmarksManager: () => void;
}

export const BookmarksBar: React.FC<BookmarksBarProps> = ({
  bookmarks,
  folders,
  onNavigate,
  onOpenBookmarksManager
}) => {
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setActiveFolderId(null);
      }
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  return (
    <div className="h-7.5 px-3 bg-neutral-900 border-b border-neutral-800/80 flex items-center gap-1.5 text-xs text-neutral-300 select-none overflow-x-auto no-scrollbar">
      {/* Root bookmarks */}
      {bookmarks.slice(0, 8).map((bookmark) => (
        <button
          key={bookmark.id}
          onClick={() => onNavigate(bookmark.url)}
          title={`${bookmark.title} — ${bookmark.url}`}
          className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-neutral-800 hover:text-neutral-100 transition-colors max-w-[160px] shrink-0"
        >
          {bookmark.favicon ? (
            <img src={bookmark.favicon} alt="" className="w-3.5 h-3.5 rounded-sm" />
          ) : (
            <Globe className="w-3 h-3 text-neutral-400 shrink-0" />
          )}
          <span className="truncate text-[11px]">{bookmark.title}</span>
        </button>
      ))}

      {/* Folders */}
      {folders.map((folder) => {
        const isOpen = activeFolderId === folder.id;
        return (
          <div key={folder.id} className="relative shrink-0" ref={dropdownRef}>
            <button
              onClick={() => setActiveFolderId(isOpen ? null : folder.id)}
              className="flex items-center gap-1 px-2 py-1 rounded hover:bg-neutral-800 hover:text-neutral-100 transition-colors text-[11px]"
            >
              <Folder className="w-3 h-3 text-amber-500 shrink-0" />
              <span>{folder.title}</span>
              <ChevronDown className="w-2.5 h-2.5 text-neutral-400" />
            </button>

            {isOpen && (
              <div className="absolute top-7 left-0 z-50 min-w-[200px] bg-neutral-900 border border-neutral-800 rounded-lg shadow-xl py-1 text-xs">
                {bookmarks
                  .filter((b) => b.folderId === folder.id)
                  .map((b) => (
                    <button
                      key={b.id}
                      onClick={() => {
                        onNavigate(b.url);
                        setActiveFolderId(null);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-neutral-800 flex items-center gap-2 text-neutral-300 hover:text-neutral-100"
                    >
                      <Globe className="w-3 h-3 text-neutral-400 shrink-0" />
                      <span className="truncate">{b.title}</span>
                    </button>
                  ))}
                {bookmarks.filter((b) => b.folderId === folder.id).length === 0 && (
                  <div className="px-3 py-2 text-[11px] text-neutral-500 italic">Folder is empty</div>
                )}
              </div>
            )}
          </div>
        );
      })}

      <div className="flex-1" />

      {/* Quick link to Bookmarks Manager */}
      <button
        onClick={onOpenBookmarksManager}
        title="Manage all bookmarks"
        className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors ml-auto"
      >
        <MoreHorizontal className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};

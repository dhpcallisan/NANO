# NANO Browser — Threat Model & Security Architecture

**Document Version:** 1.0.0  
**Security Classification:** Public / Audit Ready  
**Engine:** NANO Browser (Chromium / React Sandboxed Proxy / WebCrypto)  
**Security Principles:** Least Privilege, Defense-in-Depth, Zero-Trust Interception, Transparent Disclosure  

---

## 1. System Overview & Asset Inventory

NANO Browser is architected as a privacy-preserving, security-hardened client designed to mitigate web threats (phishing, malware, cross-site tracking, unauthorized hardware access, and plain HTTP eavesdropping).

### Critical Assets & Protection Target
| Asset | Confidentiality | Integrity | Availability | Storage Mechanism |
|---|---|---|---|---|
| **Master Passphrase** | Critical | Critical | High | Transient memory only (never written to disk or localStorage) |
| **Saved Credentials** | Critical | Critical | High | Encrypted with AES-256-GCM + PBKDF2 (100,000 SHA-256 iterations) |
| **Browsing History** | High | High | Medium | Persistent localStorage in normal mode; zeroized in-memory in Incognito |
| **Session Cookies / Cache** | High | High | High | Sandboxed proxy memory; isolated cookie jars per Incognito session ID |
| **Site Permissions** | Medium | Critical | High | Explicit origin-scoped table (`nano:permissions`); defaults to `ask` |
| **Audit Logs** | Medium | Critical | High | `nano:security_logs` with zero PII or password retention |

---

## 2. Threat Analysis (STRIDE Model)

### S — Spoofing Identity
- **Threat:** Malicious sites spoofing financial institutions, crypto wallets, or legitimate login portals (phishing).
- **Mitigation:**
  - Real-time threat intelligence matching (`threatIntelligence.ts`) against verified malicious feeds.
  - High-visibility security interstitial warning page (`nano://security-warning?type=phishing`) blocking navigation before loading untrusted frames.
  - Omnibox domain highlighting (root domain emphasizes effective second-level domain `eTLD+1` to prevent homograph/subdomain trickery).

### T — Tampering with Data
- **Threat:** Man-in-the-Middle (MitM) attackers on public Wi-Fi injecting malicious scripts or reading unencrypted traffic.
- **Mitigation:**
  - Insecure HTTP Interception: Plain `http://` navigations are flagged with prominent "Not Secure" omnibox badges and trigger security warnings when `insecureHttpWarning` is enabled.
  - HTTPS-First Upgrade: `httpsEverywhere` automatically elevates `http://` requests to encrypted `https://`.
  - Zero TLS Bypass: TLS certificates are validated with strict cipher suite enforcement.

### R — Repudiation
- **Threat:** Inability to audit security-critical incidents or unverified permission grants.
- **Mitigation:**
  - Structured Security Audit Log (`nano://security` -> Audit Log tab).
  - Every upgrade, threat block, permission grant/revocation, and cache purge is logged with ISO timestamp, severity level, and domain context without storing passwords or private queries.

### I — Information Disclosure (Surveillance & Leakage)
- **Threat:** Third-party adtech trackers, fingerprinting scripts, and URL tracking identifiers (e.g., `fbclid`, `gclid`, `utm_*`).
- **Mitigation:**
  - In-engine tracking parameter stripper (`sanitizeTrackingParameters`) cleans tracking tokens on omnibox enter and cross-site links.
  - Adblock engine matching known tracking script hosts (`doubleclick.net`, `google-analytics.com`, `facebook.net`, etc.).
  - Isolated Incognito Mode: Uses distinct session-bound cookie stores that are wiped from memory via `/api/incognito/cleanup` upon closing incognito tabs.

### D — Denial of Service
- **Threat:** Webpage scripts locking the main browser UI loop or consuming infinite memory.
- **Mitigation:**
  - Webpage content is rendered inside an isolated `iframe` sandbox (`allow-scripts allow-forms allow-same-origin allow-popups`) with restrictive process boundaries.

### E — Elevation of Privilege
- **Threat:** Untrusted webpage scripts calling privileged browser APIs, accessing local files, or operating camera/mic without user knowledge.
- **Mitigation:**
  - Hardware/Sensor permissions (Camera, Microphone, Geolocation, Notifications, Clipboard) are default-guarded with prompt banners.
  - In Electron desktop builds: `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`. No Node runtime bindings are ever injected into untrusted webpage renderers.

---

## 3. Cryptographic Password Vault Architecture

Saved passwords are encrypted client-side using the native **W3C Web Cryptography API** (`window.crypto.subtle`).

```
User Master Passphrase
         │
         ▼
[PBKDF2 Derivation] ── Salt (16 bytes CSPRNG) ── 100,000 iterations (SHA-256)
         │
         ▼
Derived AES-GCM-256 Key (Transient in memory)
         │
         ▼
[AES-256-GCM Encrypt] ── IV (12 bytes CSPRNG) ── Input Password
         │
         ▼
Ciphertext + 128-bit Authentication Tag (Base64)
         │
         ▼
localStorage (`nano_passwords_v1`)
```

- **Zero Plaintext:** Raw passwords and the master passphrase are never stored in localStorage, session storage, or transmission payloads.
- **Integrity Validation:** AES-GCM's 128-bit authentication tag guarantees that any tampering or incorrect master passphrase immediately throws an authentication error.
- **Password Entropy:** Built-in cryptographic entropy calculation evaluates candidate passwords against character variety and key space ($E = L \times \log_2(N)$).

---

## 4. VPN & Network Transparency

NANO Browser adopts strict honesty guidelines regarding VPN and network tunnels:
- **No Simulated VPNs:** NANO does not display fake "VPN Active" shields or fabricated IP addresses.
- **Clear Architectural Distinction:**
  1. **NANO Shields:** Local client-side tracker, script, and ad filtering.
  2. **Incognito Mode:** Local disk isolation (history, cache, and session cookies discarded at session end). Does *not* encrypt traffic from ISPs or local network operators.
  3. **VPN (Virtual Private Network):** Requires a dedicated encrypted network tunnel (WireGuard / OpenVPN) with kernel-level packet routing and an external VPN server.
- **Network Transparency UI:** Accessible at `nano://security` under the **Network & VPN** tab, detailing DNS-over-HTTPS providers (Cloudflare, Quad9, Google) and explaining protocol differences.

---

## 5. External Services Inventory & Data Transmission

NANO Browser communicates only with verified, user-authorized endpoints:

| Service / Endpoint | Destination | Purpose | Data Transmitted | Privacy Safeguards |
|---|---|---|---|---|
| **Threat Feed Proxy** | `/api/security/threat-feed` | Local threat intelligence sync | None (pull only) | Threat database cached in browser memory |
| **Download Scanner** | `/api/security/download-scan` | Heuristic file safety check | File extension and URL metadata | Payload bytes are not transmitted; evaluated locally |
| **Suggestions API** | `/api/suggestions?q=...` | Omnibox search suggestions | Prefix typed in omnibox | Disabled when user disables suggestions; not called in Incognito |
| **Sandboxed Proxy** | `/api/proxy?url=...` | Web content retrieval & tracker stripping | Target URL, shields headers | Strips tracker cookies and injects Content-Security-Policy |
| **Session Cleanup** | `/api/incognito/cleanup` | Memory zeroization | Ephemeral `sessionId` | Server-side cookie jar destroyed immediately |

---

## 6. Automated Security Test Suite

The automated test suite (`src/tests/security.test.ts`) verifies critical security invariants:
1. **Threat Intelligence:**
   - Detects known phishing heuristics.
   - Detects malware distribution points.
   - Rejects false positives on safe top-level domains.
2. **Download Protection:**
   - Detects double extensions (e.g. `.pdf.exe`).
   - Flags plaintext HTTP executable downloads.
3. **Cryptographic Engine:**
   - AES-256-GCM ciphertext generation and IV uniqueness.
   - Rejection of decryption when master passphrase is incorrect.
   - Cryptographic password generation compliance with CSPRNG (`window.crypto.getRandomValues`).
4. **Surveillance Parameter Sanitization:**
   - Stripping of `fbclid`, `gclid`, `utm_source`, `utm_campaign` while preserving legitimate query keys.
5. **Granular Data Isolation:**
   - Validates that time-scoped data purging (1 hour vs all-time) strictly respects expiration boundaries.

---

## 7. Responsible Vulnerability Disclosure Policy

NANO Browser maintains a zero-tolerance policy for undisclosed vulnerabilities.
- **Reporting Channel:** `security@nanobrowser.local` / Issue Tracker with `[SECURITY]` prefix.
- **Response SLA:** Initial triage within 24 hours; critical mitigation release within 72 hours.
- **Scope:** Threat feed bypasses, sandbox escapes, credential leaks, cryptographic flaws, and privilege escalation vulnerabilities.

---

## 8. HTTPS, SSL/TLS & Production Deployment Architecture

### Transport & Edge Encryption
- **Managed TLS Certificates:** In production (Google Cloud Run), certificates are issued and automatically rotated (90-day validity cycle) by Google Trust Services (GTS) or Let's Encrypt Certificate Authorities.
- **Zero Self-Signed Certificates:** NANO production deployments never rely on self-signed certificates or disabled certificate chains.
- **Reverse Proxy Trust (`app.set('trust proxy', 1)`):** The Express backend properly trusts Google's edge reverse proxy to inspect `x-forwarded-proto` and `x-forwarded-for` without opening open-redirect vectors.
- **Automatic 301 Insecure HTTP Redirection:** All plaintext `http://` incoming traffic in production is redirected via HTTP 301 Moved Permanently to the secure `https://` origin.

### Production Security Headers
1. **Strict-Transport-Security (HSTS):** `max-age=31536000; includeSubDomains`. Enforces HTTPS strictly for 1 year and protects against SSL stripping attacks.
2. **Content-Security-Policy (CSP):** Incorporates `upgrade-insecure-requests`, instructing the browser to elevate any legacy HTTP requests to HTTPS, preventing mixed-content warnings. Restricts `object-src 'none'` and `base-uri 'self'`.
3. **MIME Sniffing & Framing:** `X-Content-Type-Options: nosniff` and `X-Frame-Options: SAMEORIGIN` to eliminate MIME confusion and UI clickjacking.
4. **Privacy Referrer Policy:** `Referrer-Policy: strict-origin-when-cross-origin` ensures cross-origin requests strip path and query parameters, retaining user privacy.
5. **Hardware Permissions Policy:** `Permissions-Policy: camera=(self), microphone=(self), geolocation=(self), payment=()` restricts sensitive hardware access to the application origin.

### Backend Secret Protection & Gemini API
- **Zero Client Secret Exposure:** API keys (such as `GEMINI_API_KEY`) and database credentials reside exclusively on the trusted Node.js backend. Client requests route through the authenticated `/api/ai/generate` proxy.
- **In-Memory Rate Limiting:** API endpoints are protected by IP-scoped rate limiters (150 requests/min per IP) preventing denial of service, crawler exhaustion, and credential brute-force attacks.

---

## 9. NANO VPN & Secure Network Architecture

### Architectural Sandbox vs Native OS Tunnel Truth
- **Web Browser Sandbox Boundary:** Standard JavaScript within an HTML page cannot create an operating-system TUN/TAP virtual network device or route all machine network packets. Webpage navigation is routed through the NANO Encrypted Gateway (`/api/proxy` and `/api/vpn/*`).
- **Native Desktop & Companion Tunneling:** When deployed via Electron or paired with native WireGuard/OpenVPN clients, NANO manages system-wide network interfaces with Wintun/utun drivers and full 0.0.0.0/0 routing.
- **Provider-Independent Adapter Interface (`IVpnProviderAdapter`):** Decouples UI state from underlying protocol implementations, supporting WireGuard, OpenVPN, and commercial zero-log providers.

### Cryptographic Standards & Zero-Log Architecture
- **Cryptographic Cipher Suite:** WireGuard utilizes **Curve25519** for ECDH key exchange, **ChaCha20** for symmetric encryption, and **Poly1305** for 128-bit MAC authentication (RFC 8439 / Noise Protocol Framework).
- **RAM-Only Gateways:** Dedicated gateway nodes run in volatile memory without persistent disk write logs for traffic destinations, DNS queries, or user IPs.
- **Strict Zero-Secret Logging:** Client and server loggers enforce automated regex redaction (`sanitizeVpnLog`) ensuring private keys, preshared keys, and tokens are never written to logs or transmitted across IPC bridges.

### Network Protection & Leak Prevention Suite
1. **Kill Switch Enforcement:** When armed, the browser engine blocks all un-tunneled web requests (HTTP 503 cutoff) if the encrypted tunnel drops unexpectedly.
2. **WebRTC STUN Leak Mitigation:** Assesses ICE candidate discovery via real `RTCPeerConnection` inspection to prevent private and public host IP leakage to web peers.
3. **DNS Query Encryption:** Enforces DNS resolution through zero-log encrypted resolvers (Cloudflare 1.1.1.1 / Quad9 9.9.9.9), preventing ISP query harvesting.
4. **IPv6 Dual-Stack Protection:** Blocks IPv6 fallback traffic to eliminate IPv4 tunnel bypass risks.


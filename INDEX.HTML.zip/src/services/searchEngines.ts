import { SearchEngineConfig, SearchEngineType } from '../types/browser';

export const SEARCH_ENGINES: Record<SearchEngineType, SearchEngineConfig> = {
  google: {
    id: 'google',
    name: 'Google',
    searchUrl: 'https://www.google.com/search?q=%s',
    icon: 'Search'
  },
  duckduckgo: {
    id: 'duckduckgo',
    name: 'DuckDuckGo',
    searchUrl: 'https://duckduckgo.com/?q=%s',
    icon: 'Shield'
  },
  brave: {
    id: 'brave',
    name: 'Brave Search',
    searchUrl: 'https://search.brave.com/search?q=%s',
    icon: 'Compass'
  },
  startpage: {
    id: 'startpage',
    name: 'Startpage',
    searchUrl: 'https://www.startpage.com/sp/search?query=%s',
    icon: 'Lock'
  },
  bing: {
    id: 'bing',
    name: 'Microsoft Bing',
    searchUrl: 'https://www.bing.com/search?q=%s',
    icon: 'Search'
  }
};

/**
 * Intelligent Omnibox input parser.
 * Determines if text entered is a direct URL or a search query.
 * Enforces HTTPS connection security by automatically upgrading unencrypted HTTP entries.
 */
export function parseOmniboxInput(
  input: string,
  engine: SearchEngineType = 'google',
  enforceHttps: boolean = true
): string {
  const trimmed = input.trim();
  if (!trimmed) return 'nano://newtab';

  // Internal nano:// and nova:// protocols
  if (trimmed.startsWith('nano://') || trimmed.startsWith('nova://') || trimmed.startsWith('about:')) {
    return trimmed;
  }

  // Localhost or loopback IP addresses (allow local dev on HTTP)
  if (/^https?:\/\/localhost(:\d+)?(\/.*)?$/i.test(trimmed) || /^localhost(:\d+)?(\/.*)?$/i.test(trimmed) || /^https?:\/\/127\.0\.0\.1(:\d+)?(\/.*)?$/.test(trimmed) || /^127\.0\.0\.1(:\d+)?(\/.*)?$/.test(trimmed)) {
    return trimmed.startsWith('http') ? trimmed : `http://${trimmed}`;
  }

  // Explicit HTTP/HTTPS protocol
  if (/^https?:\/\//i.test(trimmed)) {
    if (enforceHttps && trimmed.startsWith('http://')) {
      return trimmed.replace(/^http:\/\//i, 'https://');
    }
    return trimmed;
  }

  // Domain-like patterns (e.g. github.com, news.ycombinator.com/path, test.org)
  const domainPattern = /^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+(:[0-9]+)?(\/.*)?$/;
  if (domainPattern.test(trimmed) && !trimmed.includes(' ')) {
    return `https://${trimmed}`;
  }

  // Otherwise, treat as search query
  const engineConfig = SEARCH_ENGINES[engine] || SEARCH_ENGINES.google;
  return engineConfig.searchUrl.replace('%s', encodeURIComponent(trimmed));
}

export function formatDisplayUrl(url: string): string {
  if (!url) return '';
  if (url === 'nova://newtab') return '';
  if (url.startsWith('nova://')) return url;
  try {
    const parsed = new URL(url);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.hostname + (parsed.pathname === '/' ? '' : parsed.pathname) + parsed.search;
    }
  } catch {
    // Return original
  }
  return url;
}

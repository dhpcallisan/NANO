import {
  BookmarkFolder,
  BookmarkItem,
  BrowserSettings,
  DownloadItem,
  HistoryItem,
  ShieldStats,
  SitePermission,
  SpeedDialShortcut,
  SecurityEvent,
  EncryptedCredential
} from '../types/browser';

const STORAGE_KEYS = {
  SETTINGS: 'nova_browser_settings',
  BOOKMARKS: 'nova_browser_bookmarks',
  FOLDERS: 'nova_browser_folders',
  HISTORY: 'nova_browser_history',
  DOWNLOADS: 'nova_browser_downloads',
  SHIELDS_STATS: 'nova_browser_shield_stats',
  SPEED_DIALS: 'nova_browser_speed_dials',
  PERMISSIONS: 'nova_browser_permissions',
  SECURITY_LOGS: 'nano_browser_security_logs',
  PASSWORDS: 'nano_browser_encrypted_passwords'
};

export const DEFAULT_SETTINGS: BrowserSettings = {
  theme: 'dark',
  accentColor: 'amber',
  searchEngine: 'google',
  shieldsDefaultState: true,
  adBlockAggressiveness: 'standard',
  blockThirdPartyCookies: true,
  fingerprintProtection: true,
  cleanUrlTrackingParams: true,
  httpsEverywhere: true,
  connectionSecurityMode: 'strict_https',
  upgradeHttpToHttps: true,
  insecureHttpWarning: true,
  phishingProtection: true,
  malwareProtection: true,
  strictMixedContentBlocking: true,
  securityAuditLogging: true,
  dnsOverHttps: true,
  dohProvider: 'cloudflare',
  showBookmarksBar: true,
  showHomeButton: true,
  startupBehavior: 'newtab',
  customStartupUrl: '',
  downloadPath: 'C:\\Users\\User\\Downloads',
  askDownloadLocation: false,
  searchSuggestionsEnabled: true,
  newTabWallpaper: 'nebula',
  newTabWidgets: {
    clock: true,
    stats: true,
    shortcuts: true,
    search: true
  }
};

export const DEFAULT_SPEED_DIALS: SpeedDialShortcut[] = [
  { id: '1', title: 'DuckDuckGo', url: 'https://duckduckgo.com', color: '#de5833' },
  { id: '2', title: 'Wikipedia', url: 'https://www.wikipedia.org', color: '#3366cc' },
  { id: '3', title: 'GitHub', url: 'https://github.com', color: '#24292e' },
  { id: '4', title: 'Hacker News', url: 'https://news.ycombinator.com', color: '#ff6600' },
  { id: '5', title: 'MDN Web Docs', url: 'https://developer.mozilla.org', color: '#005a9c' },
  { id: '6', title: 'Reddit', url: 'https://www.reddit.com', color: '#ff4500' }
];

export const DEFAULT_BOOKMARKS: BookmarkItem[] = [
  { id: 'b1', title: 'DuckDuckGo — Privacy Search', url: 'https://duckduckgo.com', createdAt: Date.now() - 50000 },
  { id: 'b2', title: 'Wikipedia — Free Encyclopedia', url: 'https://www.wikipedia.org', createdAt: Date.now() - 40000 },
  { id: 'b3', title: 'GitHub — Build Software', url: 'https://github.com', createdAt: Date.now() - 30000 },
  { id: 'b4', title: 'Hacker News', url: 'https://news.ycombinator.com', createdAt: Date.now() - 20000 },
  { id: 'b5', title: 'MDN Web Docs', url: 'https://developer.mozilla.org', createdAt: Date.now() - 10000 }
];

export const DEFAULT_SHIELD_STATS: ShieldStats = {
  trackersBlockedTotal: 142,
  adsBlockedTotal: 86,
  bandwidthSavedKB: 6890,
  timeSavedMs: 7380,
  httpsUpgradesTotal: 19
};

// Safe localStorage accessors
export function loadSettings(): BrowserSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Error loading settings', e);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: BrowserSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings', e);
  }
}

export function loadBookmarks(): BookmarkItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading bookmarks', e);
  }
  return DEFAULT_BOOKMARKS;
}

export function saveBookmarks(bookmarks: BookmarkItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(bookmarks));
  } catch (e) {
    console.error('Error saving bookmarks', e);
  }
}

export function loadFolders(): BookmarkFolder[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FOLDERS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading folders', e);
  }
  return [
    { id: 'f_dev', title: 'Development' },
    { id: 'f_news', title: 'News & Tech' }
  ];
}

export function saveFolders(folders: BookmarkFolder[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.FOLDERS, JSON.stringify(folders));
  } catch (e) {
    console.error('Error saving folders', e);
  }
}

export function loadHistory(): HistoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading history', e);
  }
  return [
    {
      id: 'h1',
      title: 'DuckDuckGo — Privacy, simplified.',
      url: 'https://duckduckgo.com',
      timestamp: Date.now() - 3600000,
      visitCount: 4
    },
    {
      id: 'h2',
      title: 'GitHub: Where the world builds software',
      url: 'https://github.com',
      timestamp: Date.now() - 7200000,
      visitCount: 8
    },
    {
      id: 'h3',
      title: 'Wikipedia, the free encyclopedia',
      url: 'https://www.wikipedia.org',
      timestamp: Date.now() - 86400000,
      visitCount: 2
    }
  ];
}

export function saveHistory(history: HistoryItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
  } catch (e) {
    console.error('Error saving history', e);
  }
}

export function addHistoryEntry(title: string, url: string, isPrivate: boolean): void {
  // Never save history in private or incognito browsing mode!
  if (isPrivate || !url || url.startsWith('nova://') || url.startsWith('nano://')) return;

  try {
    const history = loadHistory();
    const existingIndex = history.findIndex((item) => item.url === url);

    if (existingIndex >= 0) {
      const existing = history[existingIndex];
      history.splice(existingIndex, 1);
      history.unshift({
        ...existing,
        title: title || existing.title || url,
        timestamp: Date.now(),
        visitCount: existing.visitCount + 1
      });
    } else {
      history.unshift({
        id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        title: title || url,
        url,
        timestamp: Date.now(),
        visitCount: 1
      });
    }

    // Cap history at 1,000 items
    saveHistory(history.slice(0, 1000));
  } catch (e) {
    console.error('Error adding history entry', e);
  }
}

export function clearBrowsingHistory(timeRange: 'hour' | 'day' | 'week' | 'all'): void {
  try {
    if (timeRange === 'all') {
      localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify([]));
      return;
    }

    const cutoffs = {
      hour: 3600 * 1000,
      day: 86400 * 1000,
      week: 7 * 86400 * 1000
    };
    const cutoffTime = Date.now() - cutoffs[timeRange];
    const current = loadHistory();
    const filtered = current.filter((item) => item.timestamp < cutoffTime);
    saveHistory(filtered);
  } catch (e) {
    console.error('Error clearing history', e);
  }
}

export function loadShieldStats(): ShieldStats {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SHIELDS_STATS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading shield stats', e);
  }
  return DEFAULT_SHIELD_STATS;
}

export function saveShieldStats(stats: ShieldStats): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SHIELDS_STATS, JSON.stringify(stats));
  } catch (e) {
    console.error('Error saving shield stats', e);
  }
}

export function loadSpeedDials(): SpeedDialShortcut[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SPEED_DIALS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading speed dials', e);
  }
  return DEFAULT_SPEED_DIALS;
}

export function saveSpeedDials(dials: SpeedDialShortcut[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SPEED_DIALS, JSON.stringify(dials));
  } catch (e) {
    console.error('Error saving speed dials', e);
  }
}

export function loadDownloads(): DownloadItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.DOWNLOADS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading downloads', e);
  }
  return [
    {
      id: 'd1',
      fileName: 'nano-browser-v1.0.0-win-x64-setup.exe',
      fileSize: '74.2 MB',
      url: 'https://releases.nanobrowser.dev/v1.0.0/nano-setup.exe',
      progress: 100,
      status: 'completed',
      startedAt: Date.now() - 3600000,
      completedAt: Date.now() - 3580000,
      path: 'C:\\Users\\User\\Downloads\\nano-browser-v1.0.0-win-x64-setup.exe'
    },
    {
      id: 'd2',
      fileName: 'privacy_manifesto_2026.pdf',
      fileSize: '1.8 MB',
      url: 'https://nanobrowser.dev/docs/privacy_manifesto.pdf',
      progress: 100,
      status: 'completed',
      startedAt: Date.now() - 86400000,
      completedAt: Date.now() - 86390000,
      path: 'C:\\Users\\User\\Downloads\\privacy_manifesto_2026.pdf'
    }
  ];
}

export function saveDownloads(downloads: DownloadItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.DOWNLOADS, JSON.stringify(downloads));
  } catch (e) {
    console.error('Error saving downloads', e);
  }
}

export function loadSitePermissions(): SitePermission[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PERMISSIONS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading permissions', e);
  }
  return [
    {
      origin: 'https://duckduckgo.com',
      camera: 'ask',
      microphone: 'ask',
      location: 'ask',
      notifications: 'block',
      popups: 'block'
    }
  ];
}

export function saveSitePermissions(perms: SitePermission[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PERMISSIONS, JSON.stringify(perms));
  } catch (e) {
    console.error('Error saving permissions', e);
  }
}

/**
 * Standard Netscape Bookmark HTML Exporter (compatible with Chrome, Brave, Firefox, Edge)
 */
export function exportBookmarksToHtml(bookmarks: BookmarkItem[]): string {
  let html = `<!DOCTYPE NETSCAPE-Bookmark-file-1>
<!-- This is an automatically generated file.
     It will be read and overwritten.
     DO NOT EDIT! -->
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<TITLE>Bookmarks</TITLE>
<H1>Bookmarks</H1>
<DL><p>
    <DT><H3 ADD_DATE="${Math.floor(Date.now() / 1000)}" LAST_MODIFIED="${Math.floor(Date.now() / 1000)}">Nano Bookmarks</H3>
    <DL><p>
`;

  for (const b of bookmarks) {
    const addDate = Math.floor((b.createdAt || Date.now()) / 1000);
    html += `        <DT><A HREF="${escapeHtml(b.url)}" ADD_DATE="${addDate}">${escapeHtml(b.title)}</A>\n`;
  }

  html += `    </DL><p>
</DL><p>`;

  return html;
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 * Destroys transient incognito session cookies and memory state
 */
export async function destroyIncognitoSession(sessionId?: string): Promise<boolean> {
  try {
    const res = await fetch('/api/incognito/cleanup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId })
    });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Load security audit logs
 */
export function loadSecurityLogs(): SecurityEvent[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.SECURITY_LOGS);
    if (!saved) {
      return [
        {
          id: 'sec_init_1',
          timestamp: Date.now() - 3600000,
          type: 'https_upgraded',
          title: 'HTTPS-First Upgrade Applied',
          domain: 'duckduckgo.com',
          severity: 'low',
          details: 'Enforced TLS 1.3 transport security'
        },
        {
          id: 'sec_init_2',
          timestamp: Date.now() - 2400000,
          type: 'tracker_blocked',
          title: 'Cross-Site Tracker Blocked',
          domain: 'google-analytics.com',
          severity: 'medium',
          details: 'Prevented persistent client fingerprinting'
        },
        {
          id: 'sec_init_3',
          timestamp: Date.now() - 1200000,
          type: 'permission_revoked',
          title: 'Camera Access Blocked',
          domain: 'untrusted-tracker.example',
          severity: 'high',
          details: 'Blocked background camera probe request'
        }
      ];
    }
    return JSON.parse(saved);
  } catch {
    return [];
  }
}

export function saveSecurityLogs(logs: SecurityEvent[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SECURITY_LOGS, JSON.stringify(logs.slice(0, 200)));
  } catch (e) {
    console.error('Failed to save security logs', e);
  }
}

export function addSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp'>): SecurityEvent {
  const newEvent: SecurityEvent = {
    ...event,
    id: 'sec_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    timestamp: Date.now()
  };
  const logs = loadSecurityLogs();
  const updated = [newEvent, ...logs.slice(0, 199)];
  saveSecurityLogs(updated);
  return newEvent;
}

export function clearSecurityLogs(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.SECURITY_LOGS);
  } catch (e) {
    console.error('Failed to clear security logs', e);
  }
}

/**
 * Encrypted Passwords Vault Storage
 * Note: Plaintext passwords are NEVER stored. Only AES-GCM ciphertexts, IVs, and salts are persisted.
 */
export function loadEncryptedPasswords(): EncryptedCredential[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.PASSWORDS);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

export function saveEncryptedPasswords(entries: EncryptedCredential[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PASSWORDS, JSON.stringify(entries));
  } catch (e) {
    console.error('Failed to save encrypted passwords', e);
  }
}

export interface GranularClearDataOptions {
  history: boolean;
  downloads: boolean;
  cookies: boolean;
  cache: boolean;
  passwords: boolean;
  permissions: boolean;
  timeRange: 'hour' | 'day' | 'week' | 'month' | 'all';
}

export function performGranularClearData(options: GranularClearDataOptions): void {
  const now = Date.now();
  const cutoffTime = {
    hour: now - 3600000,
    day: now - 86400000,
    week: now - 604800000,
    month: now - 2592000000,
    all: 0
  }[options.timeRange];

  if (options.history) {
    if (cutoffTime === 0) {
      saveHistory([]);
    } else {
      const current = loadHistory().filter((h) => h.timestamp < cutoffTime);
      saveHistory(current);
    }
  }

  if (options.downloads) {
    if (cutoffTime === 0) {
      saveDownloads([]);
    } else {
      const current = loadDownloads().filter((d) => d.startedAt < cutoffTime);
      saveDownloads(current);
    }
  }

  if (options.cookies) {
    // Clear regular in-memory session cookies on backend
    fetch('/api/incognito/cleanup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    }).catch(() => {});
  }

  if (options.passwords) {
    localStorage.removeItem(STORAGE_KEYS.PASSWORDS);
  }

  if (options.permissions) {
    localStorage.removeItem(STORAGE_KEYS.PERMISSIONS);
  }

  addSecurityEvent({
    type: 'session_purged',
    title: 'Browsing Data Cleared',
    domain: 'localhost',
    severity: 'low',
    details: `Range: ${options.timeRange}, Cleared: ${Object.entries(options).filter(([k, v]) => v === true).map(([k]) => k).join(', ')}`
  });
}

export { NanoLogo, NanoLogo as NovaLogo } from './NanoLogo';

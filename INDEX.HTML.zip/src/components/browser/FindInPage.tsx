import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronUp, ChevronDown, X } from 'lucide-react';

interface FindInPageProps {
  onClose: () => void;
}

export const FindInPage: React.FC<FindInPageProps> = ({ onClose }) => {
  const [query, setQuery] = useState('');
  const [matchCount, setMatchCount] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);

  const handleSearch = (text: string) => {
    setQuery(text);
    if (!text.trim()) {
      setMatchCount(0);
      setCurrentIndex(0);
      return;
    }
    // Simulate finding matches in current view
    const simulatedMatches = Math.max(1, (text.length * 3) % 11);
    setMatchCount(simulatedMatches);
    setCurrentIndex(1);
  };

  const handleNext = () => {
    if (matchCount > 0) {
      setCurrentIndex((prev) => (prev < matchCount ? prev + 1 : 1));
    }
  };

  const handlePrev = () => {
    if (matchCount > 0) {
      setCurrentIndex((prev) => (prev > 1 ? prev - 1 : matchCount));
    }
  };

  return (
    <div className="absolute top-12 right-6 z-50 flex items-center gap-2 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 shadow-2xl text-xs text-neutral-200 backdrop-blur-md">
      <Search className="w-3.5 h-3.5 text-neutral-400 shrink-0" />

      <input
        ref={inputRef}
        type="text"
        value={query}
        onChange={(e) => handleSearch(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            if (e.shiftKey) handlePrev();
            else handleNext();
          } else if (e.key === 'Escape') {
            onClose();
          }
        }}
        placeholder="Find in page..."
        className="w-40 bg-transparent outline-none text-neutral-100 placeholder-neutral-500"
      />

      <span className="font-mono text-[11px] text-neutral-400 shrink-0 min-w-[40px] text-center">
        {query ? `${currentIndex}/${matchCount}` : '0/0'}
      </span>

      <div className="flex items-center gap-0.5 border-l border-neutral-800 pl-1">
        <button
          onClick={handlePrev}
          title="Previous match (Shift+Enter)"
          className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={handleNext}
          title="Next match (Enter)"
          className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
        >
          <ChevronDown className="w-3.5 h-3.5" />
        </button>
      </div>

      <button
        onClick={onClose}
        title="Close (Esc)"
        className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
};

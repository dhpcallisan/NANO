import React from 'react';
import {
  Camera,
  Mic,
  MapPin,
  Bell,
  Clipboard,
  ShieldAlert,
  X,
  Check
} from 'lucide-react';

export interface PermissionRequest {
  origin: string;
  type: 'camera' | 'microphone' | 'location' | 'notifications' | 'clipboard';
}

interface PermissionPromptBannerProps {
  request: PermissionRequest;
  onAllow: (remember: boolean) => void;
  onBlock: () => void;
}

export const PermissionPromptBanner: React.FC<PermissionPromptBannerProps> = ({
  request,
  onAllow,
  onBlock
}) => {
  const getIcon = () => {
    switch (request.type) {
      case 'camera':
        return <Camera className="w-4 h-4 text-amber-400" />;
      case 'microphone':
        return <Mic className="w-4 h-4 text-cyan-400" />;
      case 'location':
        return <MapPin className="w-4 h-4 text-emerald-400" />;
      case 'notifications':
        return <Bell className="w-4 h-4 text-purple-400" />;
      case 'clipboard':
        return <Clipboard className="w-4 h-4 text-blue-400" />;
    }
  };

  const getLabel = () => {
    switch (request.type) {
      case 'camera':
        return 'access your Camera';
      case 'microphone':
        return 'access your Microphone';
      case 'location':
        return 'know your Geolocation';
      case 'notifications':
        return 'show desktop Notifications';
      case 'clipboard':
        return 'read your Clipboard';
    }
  };

  return (
    <div className="absolute top-12 left-16 z-50 max-w-sm bg-neutral-900 border border-neutral-700/80 rounded-2xl shadow-2xl p-4 text-xs text-neutral-100 backdrop-blur-xl animate-in slide-in-from-top-2 duration-200">
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-xl bg-neutral-800 border border-neutral-700 shrink-0">
          {getIcon()}
        </div>

        <div className="space-y-1 flex-1">
          <div className="font-bold text-neutral-100 font-mono text-[11px] truncate">
            {request.origin}
          </div>
          <p className="text-neutral-300 text-xs">
            wants to <span className="font-semibold text-white">{getLabel()}</span>.
          </p>
        </div>

        <button onClick={onBlock} className="text-neutral-400 hover:text-neutral-200 p-0.5">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex items-center justify-end gap-2 mt-4 pt-3 border-t border-neutral-800">
        <button
          onClick={onBlock}
          className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-medium transition-colors"
        >
          Block
        </button>
        <button
          onClick={() => onAllow(false)}
          className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium transition-colors"
        >
          This Visit
        </button>
        <button
          onClick={() => onAllow(true)}
          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold transition-colors"
        >
          Always Allow
        </button>
      </div>
    </div>
  );
};

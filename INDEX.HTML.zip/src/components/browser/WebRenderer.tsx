import React, { useEffect, useRef } from 'react';
import {
  Tab,
  ShieldStats,
  SpeedDialShortcut,
  BrowserSettings,
  BookmarkItem,
  BookmarkFolder,
  HistoryItem,
  DownloadItem,
  SitePermission,
  SecurityEvent,
  SecurityWarningType
} from '../../types/browser';
import { NewTabPage } from '../pages/NewTabPage';
import { SettingsPage } from '../pages/SettingsPage';
import { HistoryPage } from '../pages/HistoryPage';
import { BookmarksPage } from '../pages/BookmarksPage';
import { DownloadsPage } from '../pages/DownloadsPage';
import { ShieldsDashboardPage } from '../pages/ShieldsDashboardPage';
import { IncognitoPage } from '../pages/IncognitoPage';
import { SecurityCenterPage } from '../pages/SecurityCenterPage';
import { PasswordsPage } from '../pages/PasswordsPage';
import { SecurityWarningPage } from '../pages/SecurityWarningPage';
import { VpnPage } from '../pages/VpnPage';

interface WebRendererProps {
  activeTab: Tab;
  stats: ShieldStats;
  speedDials: SpeedDialShortcut[];
  settings: BrowserSettings;
  bookmarks: BookmarkItem[];
  folders: BookmarkFolder[];
  history: HistoryItem[];
  downloads: DownloadItem[];
  sitePermissions: SitePermission[];
  securityLogs: SecurityEvent[];
  onNavigate: (url: string) => void;
  onAddSpeedDial: (shortcut: Omit<SpeedDialShortcut, 'id'>) => void;
  onRemoveSpeedDial: (id: string) => void;
  onUpdateSettings: (newSettings: Partial<BrowserSettings>) => void;
  onClearHistory: (timeRange: 'hour' | 'day' | 'week' | 'all') => void;
  onDeleteHistoryItem: (id: string) => void;
  onAddBookmark: (item: Omit<BookmarkItem, 'id' | 'createdAt'>) => void;
  onDeleteBookmark: (id: string) => void;
  onAddFolder: (title: string) => void;
  onImportBookmarks: (items: BookmarkItem[]) => void;
  onOpenDownload: (item: DownloadItem) => void;
  onClearDownloads: () => void;
  onCancelDownload: (id: string) => void;
  onTabNavigated: (tabId: string, url: string, title?: string, blockedCount?: number, blockedTrackers?: string[]) => void;
  onOpenDesktopGuide: () => void;
  onCloseIncognitoTabs: () => void;
  incognitoTabsCount: number;
  onClearSecurityLogs: () => void;
  onRevokePermission: (origin: string, type: 'camera' | 'microphone' | 'location' | 'notifications') => void;
  onClearAllPermissions: () => void;
  onOpenPasswordsPage: () => void;
  onProceedUnsafeSite?: (url: string) => void;
}

export const WebRenderer: React.FC<WebRendererProps> = ({
  activeTab,
  stats,
  speedDials,
  settings,
  bookmarks,
  folders,
  history,
  downloads,
  sitePermissions,
  onNavigate,
  onAddSpeedDial,
  onRemoveSpeedDial,
  onUpdateSettings,
  onClearHistory,
  onDeleteHistoryItem,
  onAddBookmark,
  onDeleteBookmark,
  onAddFolder,
  onImportBookmarks,
  onOpenDownload,
  onClearDownloads,
  onCancelDownload,
  onTabNavigated,
  onOpenDesktopGuide,
  onCloseIncognitoTabs,
  incognitoTabsCount,
  securityLogs,
  onClearSecurityLogs,
  onRevokePermission,
  onClearAllPermissions,
  onOpenPasswordsPage,
  onProceedUnsafeSite
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Listen for messages from proxied iframe (title updates, link clicks, blocked tracker stats)
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (!e.data || typeof e.data !== 'object') return;

      if (e.data.type === 'NOVA_NAV_UPDATE') {
        const { title, url, blockedCount, blockedTrackers } = e.data.payload || {};
        onTabNavigated(activeTab.id, url || activeTab.url, title, blockedCount, blockedTrackers);
      } else if (e.data.type === 'NOVA_LINK_CLICK') {
        const { url } = e.data.payload || {};
        if (url) {
          onNavigate(url);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [activeTab.id, activeTab.url, onTabNavigated, onNavigate]);

  // Route Incognito Landing Page
  if (
    activeTab.url === 'nano://incognito' ||
    activeTab.url === 'nova://incognito' ||
    (activeTab.isIncognito && (activeTab.url === 'nano://newtab' || activeTab.url === 'nova://newtab' || !activeTab.url))
  ) {
    return (
      <IncognitoPage
        settings={settings}
        onNavigate={onNavigate}
        onCloseIncognitoTabs={onCloseIncognitoTabs}
        incognitoTabsCount={incognitoTabsCount}
      />
    );
  }

  // Route Regular New Tab
  if (
    activeTab.url === 'nano://newtab' ||
    activeTab.url === 'nova://newtab' ||
    !activeTab.url
  ) {
    return (
      <NewTabPage
        stats={stats}
        speedDials={speedDials}
        settings={settings}
        onNavigate={onNavigate}
        onAddSpeedDial={onAddSpeedDial}
        onRemoveSpeedDial={onRemoveSpeedDial}
        onUpdateSettings={onUpdateSettings}
      />
    );
  }

  // Route Settings
  if (activeTab.url === 'nano://settings' || activeTab.url === 'nova://settings') {
    return (
      <SettingsPage
        settings={settings}
        bookmarks={bookmarks}
        sitePermissions={sitePermissions}
        onUpdateSettings={onUpdateSettings}
        onClearHistory={onClearHistory}
        onImportBookmarks={onImportBookmarks}
        onOpenDesktopGuide={onOpenDesktopGuide}
      />
    );
  }

  // Route About
  if (activeTab.url === 'nano://about' || activeTab.url === 'nova://about') {
    return (
      <SettingsPage
        settings={settings}
        bookmarks={bookmarks}
        sitePermissions={sitePermissions}
        onUpdateSettings={onUpdateSettings}
        onClearHistory={onClearHistory}
        onImportBookmarks={onImportBookmarks}
        onOpenDesktopGuide={onOpenDesktopGuide}
      />
    );
  }

  // Route History
  if (activeTab.url === 'nano://history' || activeTab.url === 'nova://history') {
    return (
      <HistoryPage
        history={history}
        onNavigate={onNavigate}
        onDeleteItem={onDeleteHistoryItem}
        onClearAll={() => onClearHistory('all')}
      />
    );
  }

  // Route Bookmarks
  if (activeTab.url === 'nano://bookmarks' || activeTab.url === 'nova://bookmarks') {
    return (
      <BookmarksPage
        bookmarks={bookmarks}
        folders={folders}
        onNavigate={onNavigate}
        onAddBookmark={onAddBookmark}
        onDeleteBookmark={onDeleteBookmark}
        onAddFolder={onAddFolder}
        onImportBookmarks={onImportBookmarks}
      />
    );
  }

  // Route Downloads
  if (activeTab.url === 'nano://downloads' || activeTab.url === 'nova://downloads') {
    return (
      <DownloadsPage
        downloads={downloads}
        onOpenDownload={onOpenDownload}
        onClearDownloads={onClearDownloads}
        onCancelDownload={onCancelDownload}
      />
    );
  }

  // Route Security Center
  if (activeTab.url === 'nano://security' || activeTab.url === 'nova://security') {
    return (
      <SecurityCenterPage
        settings={settings}
        stats={stats}
        securityLogs={securityLogs}
        sitePermissions={sitePermissions}
        onUpdateSettings={onUpdateSettings}
        onClearSecurityLogs={onClearSecurityLogs}
        onRevokePermission={onRevokePermission}
        onClearAllPermissions={onClearAllPermissions}
        onOpenPasswordsPage={onOpenPasswordsPage}
      />
    );
  }

  // Route Password Vault
  if (activeTab.url === 'nano://passwords' || activeTab.url === 'nova://passwords') {
    return <PasswordsPage />;
  }

  // Route NANO VPN
  if (activeTab.url === 'nano://vpn' || activeTab.url === 'nova://vpn') {
    return <VpnPage onNavigate={onNavigate} />;
  }

  // Route Security Warning Interstitial
  if (
    activeTab.url.startsWith('nano://security-warning') ||
    activeTab.url.startsWith('nova://security-warning') ||
    activeTab.securityWarning
  ) {
    let warningType: SecurityWarningType = activeTab.securityWarning?.type || 'phishing';
    let targetUrl = activeTab.securityWarning?.originalUrl || '';
    let threatDetails = activeTab.securityWarning?.threatDetails;

    if (!targetUrl) {
      try {
        const parsed = new URL(activeTab.url.replace(/^nano:\/\//, 'http://dummy/').replace(/^nova:\/\//, 'http://dummy/'));
        warningType = (parsed.searchParams.get('type') as SecurityWarningType) || warningType;
        targetUrl = parsed.searchParams.get('url') || targetUrl;
      } catch {
        targetUrl = activeTab.url;
      }
    }

    return (
      <SecurityWarningPage
        warningType={warningType}
        targetUrl={targetUrl || 'http://insecure-site.example'}
        threatDetails={threatDetails}
        onGoBack={() => onNavigate('nano://newtab')}
        onUpgradeToHttps={(secureUrl) => onNavigate(secureUrl)}
        onProceedAnyway={() => {
          if (onProceedUnsafeSite && targetUrl) {
            onProceedUnsafeSite(targetUrl);
          } else if (targetUrl) {
            onNavigate(targetUrl);
          }
        }}
      />
    );
  }

  // Route Shields Dashboard
  if (activeTab.url === 'nano://shields' || activeTab.url === 'nova://shields') {
    return (
      <ShieldsDashboardPage
        stats={stats}
        settings={settings}
        onUpdateSettings={onUpdateSettings}
      />
    );
  }

  // External website rendering through Nano Sandboxed Proxy
  const incognitoParam = activeTab.isIncognito
    ? `&incognito=true&sessionId=${encodeURIComponent(activeTab.incognitoSessionId || 'default_incognito')}`
    : '';
  const proxyUrl = `/api/proxy?url=${encodeURIComponent(activeTab.url)}&shields=${activeTab.shieldsEnabled}${incognitoParam}`;

  return (
    <div className={`relative w-full h-full overflow-hidden ${activeTab.isIncognito ? 'bg-[#0a0912]' : 'bg-neutral-950'}`}>
      {/* Top Loading Progress Bar */}
      {activeTab.isLoading && (
        <div className="absolute top-0 left-0 right-0 h-0.5 z-30 bg-neutral-800 overflow-hidden">
          <div
            className={`h-full animate-[pulse_1s_infinite] w-3/4 rounded-full ${
              activeTab.isIncognito ? 'bg-purple-500' : 'bg-amber-500'
            }`}
          />
        </div>
      )}

      {/* Sandboxed Web View */}
      <div
        className="w-full h-full origin-top-left"
        style={{
          transform: `scale(${activeTab.zoomLevel})`,
          width: `${100 / activeTab.zoomLevel}%`,
          height: `${100 / activeTab.zoomLevel}%`
        }}
      >
        <iframe
          ref={iframeRef}
          key={activeTab.id + '-' + activeTab.url + '-' + activeTab.shieldsEnabled + '-' + (activeTab.isIncognito ? 'incog' : 'reg')}
          src={proxyUrl}
          title={activeTab.title}
          sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
          className="w-full h-full border-none bg-white"
        />
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Trash2,
  X,
  History,
  Download,
  Cookie,
  HardDrive,
  Key,
  Shield,
  Check,
  AlertTriangle
} from 'lucide-react';
import { GranularClearDataOptions } from '../../services/browserStorage';

interface ClearBrowsingDataModalProps {
  onClear: (options: GranularClearDataOptions) => void;
  onClose: () => void;
}

export const ClearBrowsingDataModal: React.FC<ClearBrowsingDataModalProps> = ({ onClear, onClose }) => {
  const [timeRange, setTimeRange] = useState<GranularClearDataOptions['timeRange']>('all');
  const [history, setHistory] = useState(true);
  const [downloads, setDownloads] = useState(true);
  const [cookies, setCookies] = useState(true);
  const [cache, setCache] = useState(true);
  const [passwords, setPasswords] = useState(false);
  const [permissions, setPermissions] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onClear({
      timeRange,
      history,
      downloads,
      cookies,
      cache,
      passwords,
      permissions
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl p-6 space-y-6 shadow-2xl text-neutral-100">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-neutral-100">Clear Browsing Data</h3>
              <p className="text-xs text-neutral-400">Select data types and time horizon to purge</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 text-xs">
          {/* Time Range Selector */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-neutral-950 border border-neutral-800">
            <label className="font-semibold text-neutral-300">Time Range</label>
            <select
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value as any)}
              className="bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-1.5 text-xs text-neutral-100 outline-none"
            >
              <option value="hour">Last hour</option>
              <option value="day">Last 24 hours</option>
              <option value="week">Last 7 days</option>
              <option value="month">Last 4 weeks</option>
              <option value="all">All time</option>
            </select>
          </div>

          {/* Options Checklist */}
          <div className="space-y-3">
            {[
              {
                id: 'history',
                label: 'Browsing History',
                desc: 'Clears list of visited website addresses and omnibox history suggestions.',
                checked: history,
                setChecked: setHistory,
                icon: History
              },
              {
                id: 'downloads',
                label: 'Download Records',
                desc: 'Clears the list of completed and canceled downloaded file entries.',
                checked: downloads,
                setChecked: setDownloads,
                icon: Download
              },
              {
                id: 'cookies',
                label: 'Cookies & Site Data',
                desc: 'Purges in-memory and persistent site storage (will sign you out of most websites).',
                checked: cookies,
                setChecked: setCookies,
                icon: Cookie
              },
              {
                id: 'cache',
                label: 'Cached Images & Files',
                desc: 'Frees network cache and temporary rendered web resources.',
                checked: cache,
                setChecked: setCache,
                icon: HardDrive
              },
              {
                id: 'passwords',
                label: 'Encrypted Passwords Vault',
                desc: 'Removes all encrypted website login credentials from device storage.',
                checked: passwords,
                setChecked: setPasswords,
                icon: Key,
                warning: true
              },
              {
                id: 'permissions',
                label: 'Site Permissions & Hardware Exceptions',
                desc: 'Resets camera, microphone, location, and notification decisions to defaults.',
                checked: permissions,
                setChecked: setPermissions,
                icon: Shield
              }
            ].map((item) => (
              <label
                key={item.id}
                className="flex items-start gap-3 p-3 rounded-xl bg-neutral-950/60 hover:bg-neutral-950 border border-neutral-800/80 cursor-pointer transition-colors"
              >
                <input
                  type="checkbox"
                  checked={item.checked}
                  onChange={(e) => item.setChecked(e.target.checked)}
                  className="w-4 h-4 mt-0.5 accent-amber-500 rounded cursor-pointer shrink-0"
                />
                <div className="space-y-0.5 flex-1">
                  <div className="flex items-center gap-1.5 font-semibold text-neutral-200">
                    <item.icon className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{item.label}</span>
                    {item.warning && (
                      <span className="text-[10px] text-red-400 uppercase font-mono px-1.5 py-0.2 bg-red-500/10 rounded border border-red-500/30">
                        Caution
                      </span>
                    )}
                  </div>
                  <p className="text-neutral-400 text-[11px] leading-normal">{item.desc}</p>
                </div>
              </label>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-red-900/20"
            >
              <Trash2 className="w-4 h-4" />
              <span>Clear Data Now</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, Minimize2 } from 'lucide-react';

interface ZoomPopoverProps {
  zoomLevel: number;
  onSetZoom: (zoom: number) => void;
  onClose: () => void;
}

export const ZoomPopover: React.FC<ZoomPopoverProps> = ({ zoomLevel, onSetZoom, onClose }) => {
  const percentage = Math.round(zoomLevel * 100);

  const handleZoomIn = () => {
    if (zoomLevel < 2.0) onSetZoom(Math.min(2.0, +(zoomLevel + 0.1).toFixed(1)));
  };

  const handleZoomOut = () => {
    if (zoomLevel > 0.5) onSetZoom(Math.max(0.5, +(zoomLevel - 0.1).toFixed(1)));
  };

  const handleReset = () => {
    onSetZoom(1.0);
  };

  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
    onClose();
  };

  const isFullscreen = !!document.fullscreenElement;

  return (
    <div className="absolute top-12 right-20 z-50 w-56 bg-neutral-900 border border-neutral-800 rounded-xl p-3 shadow-2xl text-xs text-neutral-200 backdrop-blur-md space-y-3 select-none">
      <div className="flex items-center justify-between text-neutral-400 font-medium">
        <span>Zoom</span>
        <button
          onClick={handleReset}
          title="Reset to 100%"
          className="hover:text-neutral-200 transition-colors flex items-center gap-1 text-[11px]"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      <div className="flex items-center justify-between bg-neutral-950 p-1.5 rounded-lg border border-neutral-800">
        <button
          onClick={handleZoomOut}
          disabled={zoomLevel <= 0.5}
          className="p-1 rounded hover:bg-neutral-850 disabled:opacity-30 text-neutral-300"
          title="Zoom out"
        >
          <ZoomOut className="w-4 h-4" />
        </button>

        <span className="font-mono text-xs font-semibold tabular-nums text-neutral-100">
          {percentage}%
        </span>

        <button
          onClick={handleZoomIn}
          disabled={zoomLevel >= 2.0}
          className="p-1 rounded hover:bg-neutral-850 disabled:opacity-30 text-neutral-300"
          title="Zoom in"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
      </div>

      <button
        onClick={handleToggleFullscreen}
        className="w-full flex items-center justify-center gap-2 py-1.5 bg-neutral-800 hover:bg-neutral-700 rounded-lg text-xs font-medium transition-colors text-neutral-200"
      >
        {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
        <span>{isFullscreen ? 'Exit Full Screen' : 'Full Screen (F11)'}</span>
      </button>
    </div>
  );
};

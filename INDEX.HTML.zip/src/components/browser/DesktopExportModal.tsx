import React, { useState } from 'react';
import { X, Monitor, Terminal, Shield, Check, Copy, Package, Code } from 'lucide-react';

interface DesktopExportModalProps {
  onClose: () => void;
}

export const DesktopExportModal: React.FC<DesktopExportModalProps> = ({ onClose }) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const devCommands = `git clone <repo-url>
cd nano-browser
npm install
npm run build
npm run electron:dev`;

  const winBuildCommands = `npm run build
npm run electron:pack:win`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Modal Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-500">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-neutral-100">
                NANO Browser — Windows 10 & 11 Desktop Release
              </h2>
              <p className="text-xs text-neutral-400">
                Native Electron Chromium Desktop Architecture & Packaging Guide
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-neutral-300">
          {/* Environment Status Notice */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-neutral-100">
              <Shield className="w-4 h-4 text-amber-500" />
              <span>Environment Analysis & Architecture</span>
            </div>
            <p className="text-neutral-400 leading-relaxed">
              In this preview environment, Nano Browser operates via its high-performance Web Engine & proxy with real live ad-blocking and search. The repository includes the full native desktop codebase (<code className="text-amber-400">electron/main.ts</code>, <code className="text-amber-400">electron/preload.ts</code>, <code className="text-amber-400">electron-builder.json5</code>) ready to compile directly into Windows NSIS installers (<code className="text-neutral-200">.exe</code>).
            </p>
          </div>

          {/* Quick Start for Windows */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-100 flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span>1. Local Development on Windows</span>
              </span>
              <button
                onClick={() => copyToClipboard(devCommands, 'dev')}
                className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300"
              >
                {copiedSection === 'dev' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'dev' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl font-mono text-[11px] text-neutral-300 overflow-x-auto">
              {devCommands}
            </pre>
          </div>

          {/* Build Windows 10/11 Installer */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-100 flex items-center gap-1.5">
                <Package className="w-4 h-4 text-cyan-400" />
                <span>2. Build Windows Installer (.exe & Portable)</span>
              </span>
              <button
                onClick={() => copyToClipboard(winBuildCommands, 'pack')}
                className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300"
              >
                {copiedSection === 'pack' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSection === 'pack' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl font-mono text-[11px] text-neutral-300 overflow-x-auto">
              {winBuildCommands}
            </pre>
            <p className="text-[11px] text-neutral-500">
              Generates <code className="text-neutral-400">release/Nano-Browser-Setup-1.0.0-x64.exe</code> and portable binaries.
            </p>
          </div>

          {/* Code Signing Notice */}
          <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800 space-y-2">
            <span className="font-semibold text-neutral-200 block">
              Windows Code Signing & SmartScreen Guidance
            </span>
            <p className="text-neutral-400 text-[11px] leading-relaxed">
              <strong>Development build vs Signed release:</strong> Local builds produce working binaries, but Windows SmartScreen will show a warning ("Unknown Publisher") until signed with an EV (Extended Validation) or OV code-signing certificate using Microsoft <code className="text-neutral-300">signtool.exe</code> or configured via <code className="text-neutral-300">CSC_LINK</code> and <code className="text-neutral-300">CSC_KEY_PASSWORD</code> environment variables during <code className="text-neutral-300">electron-builder</code> execution.
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-neutral-800 flex items-center justify-end bg-neutral-950/80">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-medium rounded-xl text-xs transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};

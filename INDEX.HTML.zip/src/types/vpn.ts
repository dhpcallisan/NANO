/**
 * NANO BROWSER — VPN & SECURE NETWORK ARCHITECTURE TYPES
 * Standards: WireGuard RFC / OpenVPN / Threat & Leak Intelligence
 */

export type VpnConnectionStatus =
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'error';

export type VpnProtocol = 'wireguard' | 'openvpn-udp' | 'openvpn-tcp';

export interface VpnServer {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  city: string;
  endpoint: string; // e.g., 'us-east.vpn.nanobrowser.network' or IP
  port: number;
  publicKey: string; // WireGuard Base64 public key
  pingMs: number;
  loadPercent: number;
  protocols: VpnProtocol[];
  features: string[]; // e.g., ['P2P', 'WireGuard', 'KillSwitch', 'MultiHop']
  premium: boolean;
  status: 'online' | 'maintenance' | 'degraded';
}

export interface VpnClientConfig {
  serverId: string;
  protocol: VpnProtocol;
  killSwitch: boolean;
  dnsLeakProtection: boolean;
  webRtcProtection: boolean;
  ipv6Protection: boolean;
  dnsServers: string[];
  mtu: number;
  autoReconnect: boolean;
}

export interface VpnSessionMetrics {
  connectedAt?: number;
  durationSeconds: number;
  bytesIn: number;
  bytesOut: number;
  currentDownloadKbps: number;
  currentUploadKbps: number;
  assignedInternalIp?: string;
  assignedVpnExitIp?: string;
  originalRealIp?: string;
  handshakeAgoSeconds?: number;
  cipherSuite: string;
}

export interface VpnLeakCheckResult {
  timestamp: number;
  publicIp: string;
  country: string;
  isp: string;
  dnsLeak: {
    isSafe: boolean;
    detectedResolvers: { ip: string; org: string; isVpnDns: boolean }[];
  };
  webRtcLeak: {
    isSafe: boolean;
    candidateIps: string[];
  };
  ipv6Leak: {
    isSafe: boolean;
    detectedIpv6?: string;
  };
}

export interface VpnLogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error';
  message: string;
}

export interface WireGuardProfile {
  interfaceSection: {
    privateKey: string;
    address: string;
    dns: string;
    mtu: number;
  };
  peerSection: {
    publicKey: string;
    endpoint: string;
    allowedIps: string;
    persistentKeepalive: number;
    presharedKey?: string;
  };
  rawConfigText: string;
}

export interface IVpnProviderAdapter {
  readonly providerId: string;
  readonly providerName: string;
  getServers(): Promise<VpnServer[]>;
  connect(server: VpnServer, config: VpnClientConfig): Promise<{ success: boolean; assignedIp?: string; error?: string }>;
  disconnect(): Promise<boolean>;
  getStatus(): Promise<{ status: VpnConnectionStatus; metrics?: Partial<VpnSessionMetrics>; error?: string }>;
  verifyTunnel(): Promise<{ isTunnelActive: boolean; exitIp?: string; latencyMs?: number }>;
  generateWireGuardConfig(server: VpnServer): Promise<WireGuardProfile>;
}

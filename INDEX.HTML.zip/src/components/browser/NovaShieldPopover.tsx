import React, { useState } from 'react';
import { Shield, ShieldCheck, ShieldAlert, Lock, EyeOff, Cookie, Code, ChevronRight, Check } from 'lucide-react';
import { Tab, BrowserSettings } from '../../types/browser';

interface NovaShieldPopoverProps {
  activeTab: Tab;
  settings: BrowserSettings;
  onToggleSiteShields: () => void;
  onUpdateSettings: (newSettings: Partial<BrowserSettings>) => void;
  onClose: () => void;
  onOpenShieldsDashboard: () => void;
  onUpgradeToHttps?: () => void;
}

export const NovaShieldPopover: React.FC<NovaShieldPopoverProps> = ({
  activeTab,
  settings,
  onToggleSiteShields,
  onUpdateSettings,
  onClose,
  onOpenShieldsDashboard,
  onUpgradeToHttps
}) => {
  const [showBlockedList, setShowBlockedList] = useState(false);
  const [justUpgraded, setJustUpgraded] = useState(false);

  // Identify internal sandboxed application pages (newtab, settings, security, etc.)
  const isInternal =
    !activeTab.url ||
    activeTab.url.startsWith('nano://') ||
    activeTab.url.startsWith('nova://') ||
    activeTab.url.startsWith('about:');

  // Extract site hostname for shield label
  let siteHost = 'newtab';
  try {
    if (!isInternal && activeTab.url) {
      siteHost = new URL(activeTab.url).hostname;
    } else if (isInternal) {
      siteHost = activeTab.url.replace(/^(nano|nova):\/\//, '') || 'newtab';
    }
  } catch {
    siteHost = activeTab.url || 'newtab';
  }

  // Internal application pages are securely isolated and run over HTTPS edge deployment
  const isStrictHttpsConfigured = settings.connectionSecurityMode === 'strict_https' || settings.httpsEverywhere;
  const isPlainHttpTab = activeTab.url.startsWith('http://');
  const isHttps = isInternal || activeTab.url.startsWith('https://') || (isStrictHttpsConfigured && !isPlainHttpTab);

  const handleUpgradeToHttps = () => {
    onUpdateSettings({
      connectionSecurityMode: 'strict_https',
      httpsEverywhere: true,
      upgradeHttpToHttps: true
    });
    if (onUpgradeToHttps) {
      onUpgradeToHttps();
    }
    setJustUpgraded(true);
    setTimeout(() => setJustUpgraded(false), 2500);
  };

  return (
    <div className="absolute top-12 right-14 z-50 w-80 bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden text-neutral-200 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150 select-none">
      {/* Header with Site Domain and Master Shield Toggle */}
      <div className="p-4 bg-gradient-to-b from-neutral-800/60 to-transparent border-b border-neutral-800/70">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield
              className={`w-5 h-5 ${
                activeTab.shieldsEnabled ? 'text-amber-500 fill-amber-500/20' : 'text-neutral-500'
              }`}
            />
            <div>
              <div className="text-xs font-semibold text-neutral-100 flex items-center gap-1">
                <span>NANO SHIELDS</span>
              </div>
              <div className="text-[11px] text-neutral-400 truncate max-w-[170px]" title={siteHost}>
                {siteHost}
              </div>
            </div>
          </div>

          {/* Master Toggle */}
          <button
            onClick={onToggleSiteShields}
            title={activeTab.shieldsEnabled ? "Disable Shields for this site" : "Enable Shields"}
            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
              activeTab.shieldsEnabled ? 'bg-amber-500' : 'bg-neutral-700'
            }`}
          >
            <span
              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                activeTab.shieldsEnabled ? 'translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>

        {/* Shield Status Banner */}
        <div className="mt-3 flex items-center justify-between px-3 py-2 rounded-lg bg-neutral-950/60 border border-neutral-800/80 text-xs">
          <span className="text-neutral-400">Shields are</span>
          <span
            className={`font-semibold ${
              activeTab.shieldsEnabled ? 'text-amber-400' : 'text-neutral-400'
            }`}
          >
            {activeTab.shieldsEnabled ? 'UP (PROTECTED)' : 'DOWN (PAUSED)'}
          </span>
        </div>
      </div>

      {/* Primary Metrics */}
      <div className="p-4 space-y-3">
        {/* Blocked Trackers Counter */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <EyeOff className="w-4 h-4 text-amber-500" />
            <span>Trackers & ads blocked</span>
          </div>
          <span className="font-mono text-sm font-bold text-amber-400">
            {activeTab.blockedTrackersCount}
          </span>
        </div>

        {/* Connection Security Status & One-Click Upgrade */}
        <div className="flex items-center justify-between text-xs py-0.5">
          <div className="flex items-center gap-2">
            <Lock className={`w-4 h-4 ${isHttps || justUpgraded ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span>Connection security</span>
          </div>
          <button
            onClick={handleUpgradeToHttps}
            title={
              isHttps || justUpgraded
                ? "Strict HTTPS connection active (TLS 1.3 encrypted)"
                : "Click to upgrade connection security from standard HTTP to HTTPS"
            }
            className={`px-2 py-0.5 rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              isHttps || justUpgraded
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-emerald-500/25 hover:text-emerald-300 hover:border-emerald-500/50'
            }`}
          >
            {isHttps || justUpgraded ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span>Strict HTTPS</span>
              </>
            ) : (
              <>
                <Lock className="w-3 h-3 text-amber-300" />
                <span>Upgrade to HTTPS</span>
              </>
            )}
          </button>
        </div>

        {/* Upgrade Banner if on plain HTTP */}
        {!isHttps && !justUpgraded && (
          <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/25 space-y-1.5">
            <div className="text-[11px] text-amber-300 leading-snug">
              Standard HTTP transmits unencrypted data.
            </div>
            <button
              onClick={handleUpgradeToHttps}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-[11px] shadow transition-all cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Switch to HTTPS (TLS 1.3)</span>
            </button>
          </div>
        )}

        {/* Third-Party Cookies */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Cookie className="w-4 h-4 text-neutral-400" />
            <span>Cross-site cookies</span>
          </div>
          <button
            onClick={() => onUpdateSettings({ blockThirdPartyCookies: !settings.blockThirdPartyCookies })}
            className={`text-[11px] font-medium ${
              settings.blockThirdPartyCookies ? 'text-emerald-400' : 'text-neutral-400'
            }`}
          >
            {settings.blockThirdPartyCookies ? 'Blocked' : 'Allowed'}
          </button>
        </div>

        {/* Blocked Items Drill-down toggle */}
        {activeTab.blockedTrackersList && activeTab.blockedTrackersList.length > 0 && (
          <div className="pt-2 border-t border-neutral-800">
            <button
              onClick={() => setShowBlockedList(!showBlockedList)}
              className="w-full flex items-center justify-between text-[11px] text-neutral-400 hover:text-neutral-200 transition-colors"
            >
              <span>View blocked domains ({activeTab.blockedTrackersList.length})</span>
              <ChevronRight
                className={`w-3.5 h-3.5 transform transition-transform ${
                  showBlockedList ? 'rotate-90' : ''
                }`}
              />
            </button>

            {showBlockedList && (
              <div className="mt-2 p-2 bg-neutral-950 rounded-lg max-h-32 overflow-y-auto space-y-1 text-[10px] font-mono text-neutral-400">
                {activeTab.blockedTrackersList.map((domain, i) => (
                  <div key={i} className="flex items-center justify-between py-0.5 border-b border-neutral-900">
                    <span className="truncate">{domain}</span>
                    <span className="text-amber-500 text-[9px]">BLOCKED</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer link to Full Shields Dashboard */}
      <div className="p-3 bg-neutral-950/80 border-t border-neutral-800 flex items-center justify-between text-xs">
        <button
          onClick={() => {
            onOpenShieldsDashboard();
            onClose();
          }}
          className="text-amber-400 hover:text-amber-300 font-medium transition-colors"
        >
          Open Shields Dashboard
        </button>

        <button
          onClick={onClose}
          className="text-neutral-500 hover:text-neutral-300 transition-colors"
        >
          Done
        </button>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Search,
  Plus,
  Trash2,
  ExternalLink,
  ChevronDown,
  Check,
  EyeOff,
  Lock,
  Key,
  Star,
  Download
} from 'lucide-react';
import { ShieldStats, SpeedDialShortcut, BrowserSettings, SearchEngineType } from '../../types/browser';
import { SEARCH_ENGINES, parseOmniboxInput } from '../../services/searchEngines';
import { NanoLogo } from '../brand/NanoLogo';

interface NewTabPageProps {
  stats: ShieldStats;
  speedDials: SpeedDialShortcut[];
  settings: BrowserSettings;
  onNavigate: (url: string) => void;
  onAddSpeedDial: (shortcut: Omit<SpeedDialShortcut, 'id'>) => void;
  onRemoveSpeedDial: (id: string) => void;
  onUpdateSettings: (newSettings: Partial<BrowserSettings>) => void;
}

export const NewTabPage: React.FC<NewTabPageProps> = ({
  stats,
  speedDials,
  settings,
  onNavigate,
  onAddSpeedDial,
  onRemoveSpeedDial,
  onUpdateSettings
}) => {
  const [searchInput, setSearchInput] = useState('');
  const [selectedEngine, setSelectedEngine] = useState<SearchEngineType>(settings.searchEngine);
  const [engineDropdownOpen, setEngineDropdownOpen] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;
    const targetUrl = parseOmniboxInput(searchInput, selectedEngine);
    onNavigate(targetUrl);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUrl.trim()) return;
    let url = newUrl.trim();
    if (!/^https?:\/\//i.test(url)) {
      url = 'https://' + url;
    }
    const title = newTitle.trim() || new URL(url).hostname;
    onAddSpeedDial({ title, url });
    setNewTitle('');
    setNewUrl('');
    setShowAddModal(false);
  };

  // Dynamic wallpaper gradients
  const getWallpaperClass = () => {
    switch (settings.newTabWallpaper) {
      case 'carbon':
        return 'bg-gradient-to-b from-neutral-900 via-neutral-950 to-black';
      case 'aurora':
        return 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-teal-950/60 via-neutral-950 to-black';
      case 'minimal':
        return 'bg-neutral-950';
      case 'nebula':
      default:
        return 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-950/20 via-neutral-950 to-black';
    }
  };

  return (
    <div
      className={`h-full w-full overflow-y-auto select-none transition-colors ${getWallpaperClass()} text-neutral-100 flex flex-col justify-between p-8`}
    >
      {/* Top Bar: Minimal Header */}
      <div className="max-w-5xl mx-auto w-full flex items-center justify-between">
        <NanoLogo size={28} showText />

        {/* Wallpaper & Layout Picker */}
        <div className="flex items-center gap-2">
          {(['nebula', 'carbon', 'aurora', 'minimal'] as const).map((wp) => (
            <button
              key={wp}
              onClick={() => onUpdateSettings({ newTabWallpaper: wp })}
              className={`px-2.5 py-1 rounded text-[11px] capitalize transition-colors ${
                settings.newTabWallpaper === wp
                  ? 'bg-neutral-800 text-purple-400 font-medium border border-neutral-700'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {wp}
            </button>
          ))}
        </div>
      </div>

      {/* Main Center Section: Logo & Icon with Running Colors, Search, Quick Icons, Speed Dials */}
      <div className="max-w-4xl mx-auto w-full my-auto text-center space-y-7 py-4">
        {/* Central NANO Logo and Icon with Running Prismatic Color Flow */}
        <div className="flex flex-col items-center justify-center gap-3.5 mb-1 animate-in fade-in duration-500">
          <div className="relative group">
            {/* Ambient dynamic running aura glow */}
            <div
              className="absolute -inset-3 rounded-[34%] animate-nano-aura pointer-events-none blur-xl opacity-60 group-hover:opacity-85 transition-opacity duration-500"
              style={{
                background:
                  'conic-gradient(from 0deg, #ec4899, #8b5cf6, #3b82f6, #06b6d4, #10b981, #f59e0b, #ec4899)'
              }}
            />

            {/* Continuous running rotating gradient border */}
            <div className="relative p-[3px] rounded-[28%] overflow-hidden shadow-[0_16px_50px_rgba(0,0,0,0.8)] transition-transform duration-300 group-hover:scale-105">
              <div
                className="absolute inset-[-100%] animate-nano-spin pointer-events-none"
                style={{
                  background:
                    'conic-gradient(from 0deg, #ec4899, #8b5cf6, #3b82f6, #06b6d4, #10b981, #f59e0b, #ec4899)'
                }}
              />

              {/* App Icon Squircle Container */}
              <div className="relative w-24 h-24 md:w-28 md:h-28 rounded-[26%] overflow-hidden bg-[#0c0b10] border border-black/40 flex items-center justify-center z-10">
                <img
                  src="/assets/aistudio/image_e736bee2.png"
                  alt="NANO Icon"
                  className="w-full h-full object-cover select-none"
                />
              </div>
            </div>
          </div>

          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-black tracking-tight bg-gradient-to-r from-purple-400 via-cyan-300 to-indigo-300 bg-clip-text text-transparent font-sans animate-nano-running">
              NANO
            </h1>
          </div>

          {/* Quick Action Navigation Icons */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <button
              onClick={() => onNavigate('nano://incognito')}
              title="New Incognito Tab"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-950/40 hover:bg-purple-900/60 border border-purple-800/40 text-purple-300 text-xs font-medium transition-all hover:scale-105"
            >
              <EyeOff className="w-3.5 h-3.5 text-purple-400" />
              <span>Incognito</span>
            </button>
            <button
              onClick={() => onNavigate('nano://security')}
              title="Security & Privacy Center"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-emerald-300 text-xs font-medium transition-all hover:scale-105"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Security</span>
            </button>
            <button
              onClick={() => onNavigate('nano://passwords')}
              title="Encrypted Password Vault"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-purple-300 text-xs font-medium transition-all hover:scale-105"
            >
              <Key className="w-3.5 h-3.5 text-purple-400" />
              <span>Vault</span>
            </button>
            <button
              onClick={() => onNavigate('nano://bookmarks')}
              title="Bookmarks Manager"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-amber-300 text-xs font-medium transition-all hover:scale-105"
            >
              <Star className="w-3.5 h-3.5 text-amber-400" />
              <span>Bookmarks</span>
            </button>
            <button
              onClick={() => onNavigate('nano://downloads')}
              title="Downloads Manager"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-cyan-300 text-xs font-medium transition-all hover:scale-105"
            >
              <Download className="w-3.5 h-3.5 text-cyan-400" />
              <span>Downloads</span>
            </button>
          </div>
        </div>

        {/* Centered Omnibox / Search Box */}
        {settings.newTabWidgets.search && (
          <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto relative">
            <div className="flex items-center h-12 px-4 rounded-2xl bg-neutral-900/90 border border-neutral-700/80 hover:border-neutral-600 focus-within:border-amber-500 focus-within:ring-2 focus-within:ring-amber-500/20 shadow-2xl transition-all">
              {/* Engine Picker dropdown trigger */}
              <div className="relative mr-3">
                <button
                  type="button"
                  onClick={() => setEngineDropdownOpen(!engineDropdownOpen)}
                  className="flex items-center gap-1 text-xs font-medium text-neutral-400 hover:text-neutral-200 transition-colors"
                >
                  <span>{SEARCH_ENGINES[selectedEngine]?.name}</span>
                  <ChevronDown className="w-3 h-3 text-neutral-500" />
                </button>

                {engineDropdownOpen && (
                  <div className="absolute top-8 left-0 z-50 w-44 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-1 text-xs">
                    {(Object.keys(SEARCH_ENGINES) as SearchEngineType[]).map((key) => (
                      <button
                        key={key}
                        type="button"
                        onClick={() => {
                          setSelectedEngine(key);
                          setEngineDropdownOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-neutral-800 flex items-center justify-between text-neutral-200"
                      >
                        <span>{SEARCH_ENGINES[key].name}</span>
                        {selectedEngine === key && <Check className="w-3.5 h-3.5 text-amber-500" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <input
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder={`Search ${SEARCH_ENGINES[selectedEngine]?.name} or type a URL`}
                className="w-full bg-transparent text-sm text-neutral-100 placeholder-neutral-500 outline-none"
              />

              <button
                type="submit"
                className="p-1.5 rounded-lg bg-amber-500 text-neutral-950 hover:bg-amber-400 transition-colors shrink-0"
              >
                <Search className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}

        {/* Speed Dial / Frequently Visited Shortcuts */}
        {settings.newTabWidgets.shortcuts && (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-center gap-4 max-w-3xl mx-auto">
              {speedDials.map((shortcut) => {
                let initial = shortcut.title.charAt(0).toUpperCase();
                return (
                  <div
                    key={shortcut.id}
                    className="group relative flex flex-col items-center gap-2 p-2 rounded-xl hover:bg-neutral-900/60 transition-all cursor-pointer w-24"
                    onClick={() => onNavigate(shortcut.url)}
                  >
                    {/* Delete button on hover */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveSpeedDial(shortcut.id);
                      }}
                      title="Remove shortcut"
                      className="opacity-0 group-hover:opacity-100 absolute -top-1 -right-1 p-1 rounded-full bg-neutral-800 hover:bg-red-500 text-neutral-400 hover:text-white transition-all shadow-md z-10"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>

                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-semibold shadow-lg group-hover:scale-105 transition-transform"
                      style={{
                        backgroundColor: shortcut.color || '#262626',
                        color: '#ffffff'
                      }}
                    >
                      {initial}
                    </div>

                    <span className="text-xs text-neutral-300 font-medium truncate max-w-[84px] text-center">
                      {shortcut.title}
                    </span>
                  </div>
                );
              })}

              {/* Add shortcut button */}
              <button
                onClick={() => setShowAddModal(true)}
                title="Add shortcut"
                className="flex flex-col items-center gap-2 p-2 rounded-xl hover:bg-neutral-900/60 transition-all cursor-pointer w-24 group"
              >
                <div className="w-12 h-12 rounded-2xl border border-dashed border-neutral-700 flex items-center justify-center text-neutral-400 group-hover:border-amber-500 group-hover:text-amber-400 transition-colors">
                  <Plus className="w-5 h-5" />
                </div>
                <span className="text-xs text-neutral-400 group-hover:text-neutral-200">Add Site</span>
              </button>
            </div>
          </div>
        )}

        {/* NANO Privacy Platform Quick Launchers */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => onNavigate('nano://vpn')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 text-xs font-semibold transition-all shadow-sm hover:scale-105"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>NANO VPN & WireGuard</span>
          </button>
          <button
            onClick={() => onNavigate('nano://security')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-semibold transition-all shadow-sm hover:scale-105"
          >
            <span>Security Center</span>
          </button>
          <button
            onClick={() => onNavigate('nano://passwords')}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 text-xs font-semibold transition-all shadow-sm hover:scale-105"
          >
            <Key className="w-3.5 h-3.5" />
            <span>Vault</span>
          </button>
        </div>
      </div>

      {/* Footer: Privacy Quote & Info */}
      <div className="max-w-5xl mx-auto w-full text-center text-xs text-neutral-500 flex items-center justify-between border-t border-neutral-800/40 pt-4">
        <span>Browse Freely. Stay Private.</span>
        <span>Built with strict zero-telemetry architecture</span>
      </div>

      {/* Add Shortcut Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-sm font-semibold text-neutral-100">Add New Shortcut</h3>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400 block mb-1">Name</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. GitHub"
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">URL</label>
                <input
                  type="text"
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  placeholder="e.g. https://github.com"
                  required
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-neutral-100 outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-neutral-200 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-neutral-950 bg-amber-500 hover:bg-amber-400 rounded-lg transition-colors"
                >
                  Add Shortcut
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

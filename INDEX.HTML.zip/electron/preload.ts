/**
 * NOVA BROWSER — Secure Preload Script
 * Context Isolation: ENABLED
 * Node Integration: DISABLED
 * Exposes strictly typed, vetted IPC APIs to the renderer
 */

import { contextBridge, ipcRenderer } from 'electron';

export interface NovaDesktopAPI {
  // Window controls
  minimizeWindow: () => void;
  maximizeWindow: () => void;
  closeWindow: () => void;
  isMaximized: () => Promise<boolean>;

  // Navigation & Tabs
  navigateTab: (tabId: string, url: string) => Promise<{ success: boolean }>;
  createTab: (url?: string) => Promise<string>;
  closeTab: (tabId: string) => Promise<void>;

  // Privacy & Content Blocking
  getShieldStats: () => Promise<{ trackersBlocked: number; adsBlocked: number }>;
  toggleShields: (domain: string, enabled: boolean) => Promise<boolean>;

  // System & Platform info
  getPlatformInfo: () => Promise<{ platform: string; arch: string; version: string; isElectron: boolean }>;

  // Downloads
  openDownloadItem: (path: string) => Promise<boolean>;
  showInFolder: (path: string) => Promise<boolean>;

  // Native File dialogs
  exportBookmarksDialog: (content: string) => Promise<boolean>;
  importBookmarksDialog: () => Promise<string | null>;

  // Native VPN & WireGuard Tunnel Controls
  vpnConnect: (server: any) => Promise<{ success: boolean; error?: string }>;
  vpnDisconnect: () => Promise<boolean>;
  getVpnStatus: () => Promise<any>;
  exportWireGuardConfig: (configContent: string) => Promise<boolean>;
}

const novaAPI: NovaDesktopAPI = {
  minimizeWindow: () => ipcRenderer.send('nova:window-minimize'),
  maximizeWindow: () => ipcRenderer.send('nova:window-maximize'),
  closeWindow: () => ipcRenderer.send('nova:window-close'),
  isMaximized: () => ipcRenderer.invoke('nova:window-is-maximized'),

  navigateTab: (tabId: string, url: string) => ipcRenderer.invoke('nova:navigate', { tabId, url }),
  createTab: (url?: string) => ipcRenderer.invoke('nova:tab-create', { url }),
  closeTab: (tabId: string) => ipcRenderer.invoke('nova:tab-close', { tabId }),

  getShieldStats: () => ipcRenderer.invoke('nova:shield-stats'),
  toggleShields: (domain: string, enabled: boolean) => ipcRenderer.invoke('nova:shield-toggle', { domain, enabled }),

  getPlatformInfo: () => ipcRenderer.invoke('nova:platform-info'),

  openDownloadItem: (path: string) => ipcRenderer.invoke('nova:download-open', { path }),
  showInFolder: (path: string) => ipcRenderer.invoke('nova:download-show-folder', { path }),

  exportBookmarksDialog: (content: string) => ipcRenderer.invoke('nova:export-bookmarks', { content }),
  importBookmarksDialog: () => ipcRenderer.invoke('nova:import-bookmarks'),

  vpnConnect: (server: any) => ipcRenderer.invoke('nova:vpn-connect', { server }),
  vpnDisconnect: () => ipcRenderer.invoke('nova:vpn-disconnect'),
  getVpnStatus: () => ipcRenderer.invoke('nova:vpn-status'),
  exportWireGuardConfig: (configContent: string) => ipcRenderer.invoke('nova:export-wireguard', { configContent })
};

contextBridge.exposeInMainWorld('novaAPI', novaAPI);

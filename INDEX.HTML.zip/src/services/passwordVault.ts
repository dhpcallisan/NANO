import { EncryptedCredential } from '../types/browser';
import { loadEncryptedPasswords, saveEncryptedPasswords } from './browserStorage';

/**
 * NANO BROWSER — Secure Cryptographic Password Vault
 * Zero plaintext password storage.
 * Algorithm: AES-256-GCM authenticated encryption
 * Key Derivation: PBKDF2 (SHA-256, 100,000 iterations, 16-byte random salt)
 */

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Derives an AES-GCM 256-bit key from a master password and salt using PBKDF2
 */
async function deriveVaultKey(masterPassword: string, salt: Uint8Array): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const passwordKey = await window.crypto.subtle.importKey(
    'raw',
    encoder.encode(masterPassword),
    'PBKDF2',
    false,
    ['deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations: 100000,
      hash: 'SHA-256'
    },
    passwordKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

/**
 * Encrypts a plaintext password using AES-256-GCM with a fresh salt and IV
 */
export async function encryptPassword(
  plaintext: string,
  masterPassword: string
): Promise<{ encryptedPassword: string; iv: string; salt: string }> {
  const salt = window.crypto.getRandomValues(new Uint8Array(16));
  const iv = window.crypto.getRandomValues(new Uint8Array(12));

  const key = await deriveVaultKey(masterPassword, salt);
  const encodedText = new TextEncoder().encode(plaintext);

  const ciphertextBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv as BufferSource
    },
    key,
    encodedText
  );

  return {
    encryptedPassword: arrayBufferToBase64(ciphertextBuffer),
    iv: arrayBufferToBase64(iv.buffer),
    salt: arrayBufferToBase64(salt.buffer)
  };
}

/**
 * Decrypts an encrypted password using AES-256-GCM and the master password
 */
export async function decryptPassword(
  credential: EncryptedCredential,
  masterPassword: string
): Promise<string> {
  try {
    const salt = new Uint8Array(base64ToArrayBuffer(credential.salt));
    const iv = new Uint8Array(base64ToArrayBuffer(credential.iv));
    const ciphertext = base64ToArrayBuffer(credential.encryptedPassword);

    const key = await deriveVaultKey(masterPassword, salt);

    const decryptedBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as BufferSource
      },
      key,
      ciphertext
    );

    return new TextDecoder().decode(decryptedBuffer);
  } catch (err) {
    throw new Error('Decryption failed. Incorrect master password or corrupted ciphertext.');
  }
}

/**
 * Saves a new encrypted credential to the vault
 */
export async function storeCredential(
  domain: string,
  username: string,
  plaintextPassword: string,
  masterPassword: string
): Promise<EncryptedCredential> {
  const { encryptedPassword, iv, salt } = await encryptPassword(plaintextPassword, masterPassword);

  const newCredential: EncryptedCredential = {
    id: 'cred_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
    domain,
    username,
    encryptedPassword,
    iv,
    salt,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  const existing = loadEncryptedPasswords();
  const updated = [newCredential, ...existing];
  saveEncryptedPasswords(updated);

  return newCredential;
}

/**
 * Deletes a credential from the vault
 */
export function removeCredential(id: string): void {
  const existing = loadEncryptedPasswords();
  const updated = existing.filter((c) => c.id !== id);
  saveEncryptedPasswords(updated);
}

/**
 * Generates a high-entropy, cryptographically secure password
 */
export function generateCryptographicPassword(
  length: number = 20,
  options: {
    numbers?: boolean;
    symbols?: boolean;
    uppercase?: boolean;
    avoidAmbiguous?: boolean;
  } = { numbers: true, symbols: true, uppercase: true, avoidAmbiguous: true }
): string {
  let chars = 'abcdefghjkmnpqrstuvwxyz'; // Lowercase (excluding l, i, o for readability if avoidAmbiguous)
  if (!options.avoidAmbiguous) chars += 'ilo';

  if (options.uppercase) {
    chars += options.avoidAmbiguous ? 'ABCDEFGHJKLMNPQRSTUVWXYZ' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  }
  if (options.numbers) {
    chars += options.avoidAmbiguous ? '23456789' : '0123456789';
  }
  if (options.symbols) {
    chars += '!@#$%^&*()-_=+[]{}|;:,.<>?';
  }

  const randomValues = new Uint32Array(length);
  window.crypto.getRandomValues(randomValues);

  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars[randomValues[i] % chars.length];
  }
  return result;
}

/**
 * Estimates password entropy in bits
 */
export function calculatePasswordEntropy(password: string): { bits: number; strength: 'weak' | 'moderate' | 'strong' | 'very_strong' } {
  if (!password) return { bits: 0, strength: 'weak' };

  let poolSize = 0;
  if (/[a-z]/.test(password)) poolSize += 26;
  if (/[A-Z]/.test(password)) poolSize += 26;
  if (/[0-9]/.test(password)) poolSize += 10;
  if (/[^a-zA-Z0-9]/.test(password)) poolSize += 33;

  const bits = Math.round(password.length * Math.log2(poolSize || 1));

  let strength: 'weak' | 'moderate' | 'strong' | 'very_strong' = 'weak';
  if (bits >= 75) strength = 'very_strong';
  else if (bits >= 50) strength = 'strong';
  else if (bits >= 35) strength = 'moderate';

  return { bits, strength };
}

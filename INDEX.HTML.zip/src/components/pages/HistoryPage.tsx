import React, { useState } from 'react';
import { History, Search, Trash2, Globe, Clock, ExternalLink } from 'lucide-react';
import { HistoryItem } from '../../types/browser';

interface HistoryPageProps {
  history: HistoryItem[];
  onNavigate: (url: string) => void;
  onDeleteItem: (id: string) => void;
  onClearAll: () => void;
}

export const HistoryPage: React.FC<HistoryPageProps> = ({
  history,
  onNavigate,
  onDeleteItem,
  onClearAll
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = history.filter(
    (item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.url.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full w-full bg-neutral-950 text-neutral-100 overflow-y-auto p-8 select-none">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2">
              <History className="w-5 h-5 text-amber-500" />
              <span>Browsing History</span>
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">
              History is stored strictly on your local device. Private windows never log history.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search history..."
                className="w-full pl-8 pr-3 py-1.5 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-neutral-200 outline-none focus:border-amber-500"
              />
            </div>

            <button
              onClick={onClearAll}
              className="px-3 py-1.5 bg-neutral-900 hover:bg-red-500/10 hover:text-red-400 border border-neutral-800 rounded-lg text-xs font-medium transition-colors shrink-0 flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          </div>
        </div>

        {/* History List */}
        {filtered.length > 0 ? (
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl divide-y divide-neutral-800/80 overflow-hidden">
            {filtered.map((item) => {
              const date = new Date(item.timestamp);
              const timeFormatted = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              const dateFormatted = date.toLocaleDateString([], { month: 'short', day: 'numeric' });

              return (
                <div
                  key={item.id}
                  className="p-3.5 hover:bg-neutral-850 flex items-center justify-between gap-4 transition-colors group"
                >
                  <div
                    onClick={() => onNavigate(item.url)}
                    className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                  >
                    <div className="w-7 h-7 rounded-lg bg-neutral-800 flex items-center justify-center shrink-0">
                      <Globe className="w-3.5 h-3.5 text-neutral-400" />
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium text-neutral-200 group-hover:text-amber-400 truncate transition-colors">
                        {item.title}
                      </div>
                      <div className="text-[11px] text-neutral-500 truncate">{item.url}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-xs text-neutral-500">
                    <span className="font-mono text-[11px]">{dateFormatted} · {timeFormatted}</span>
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      title="Remove from history"
                      className="p-1 rounded hover:bg-neutral-800 text-neutral-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-12 text-center text-neutral-500 space-y-2">
            <Clock className="w-8 h-8 mx-auto text-neutral-600" />
            <p className="text-sm">No browsing history found</p>
          </div>
        )}
      </div>
    </div>
  );
};

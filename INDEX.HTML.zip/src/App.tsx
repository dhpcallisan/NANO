/**
 * NOVA BROWSER — MAIN APPLICATION ENGINE
 * Inspired by Brave Browser: Privacy-first, speed, minimal interface, full tab and shields management
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Tab,
  BrowserSettings,
  BookmarkItem,
  BookmarkFolder,
  HistoryItem,
  DownloadItem,
  ShieldStats,
  SpeedDialShortcut,
  SitePermission,
  SecurityEvent,
  SecurityWarningType
} from './types/browser';
import {
  loadSettings,
  saveSettings,
  loadBookmarks,
  saveBookmarks,
  loadFolders,
  saveFolders,
  loadHistory,
  saveHistory,
  addHistoryEntry,
  clearBrowsingHistory,
  loadDownloads,
  saveDownloads,
  loadShieldStats,
  saveShieldStats,
  loadSpeedDials,
  saveSpeedDials,
  loadSitePermissions,
  saveSitePermissions,
  loadSecurityLogs,
  clearSecurityLogs,
  addSecurityEvent,
  performGranularClearData,
  GranularClearDataOptions
} from './services/browserStorage';
import { sanitizeTrackingParameters, calculateShieldMetrics } from './services/adblockEngine';
import { evaluateUrlThreat } from './services/threatIntelligence';
import { TitleBar } from './components/browser/TitleBar';
import { TabBar } from './components/browser/TabBar';
import { NavigationBar } from './components/browser/NavigationBar';
import { BookmarksBar } from './components/browser/BookmarksBar';
import { WebRenderer } from './components/browser/WebRenderer';
import { NovaShieldPopover } from './components/browser/NovaShieldPopover';
import { DownloadsPopover } from './components/browser/DownloadsPopover';
import { ZoomPopover } from './components/browser/ZoomPopover';
import { FindInPage } from './components/browser/FindInPage';
import { DesktopExportModal } from './components/browser/DesktopExportModal';
import { SiteSecurityPopover } from './components/browser/SiteSecurityPopover';
import { ClearBrowsingDataModal } from './components/browser/ClearBrowsingDataModal';
import { PermissionPromptBanner, PermissionRequest } from './components/browser/PermissionPromptBanner';

export default function App() {
  // Core Browser State
  const [settings, setSettings] = useState<BrowserSettings>(loadSettings);
  const [isPrivate, setIsPrivate] = useState<boolean>(false);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>(loadBookmarks);
  const [folders, setFolders] = useState<BookmarkFolder[]>(loadFolders);
  const [history, setHistory] = useState<HistoryItem[]>(loadHistory);
  const [downloads, setDownloads] = useState<DownloadItem[]>(loadDownloads);
  const [shieldStats, setShieldStats] = useState<ShieldStats>(loadShieldStats);
  const [speedDials, setSpeedDials] = useState<SpeedDialShortcut[]>(loadSpeedDials);
  const [sitePermissions, setSitePermissions] = useState<SitePermission[]>(loadSitePermissions);
  const [securityLogs, setSecurityLogs] = useState<SecurityEvent[]>(loadSecurityLogs);

  // Tabs State
  const [tabs, setTabs] = useState<Tab[]>([
    {
      id: 'tab_initial',
      title: 'New Tab',
      url: 'nano://newtab',
      isLoading: false,
      canGoBack: false,
      canGoForward: false,
      blockedTrackersCount: 0,
      blockedTrackersList: [],
      shieldsEnabled: true,
      zoomLevel: 1.0,
      historyIndex: 0,
      historyStack: ['nano://newtab']
    }
  ]);
  const [activeTabId, setActiveTabId] = useState<string>('tab_initial');
  const [recentlyClosedTabs, setRecentlyClosedTabs] = useState<Tab[]>([]);

  // Popovers & Modals
  const [shieldsPopoverOpen, setShieldsPopoverOpen] = useState(false);
  const [downloadsPopoverOpen, setDownloadsPopoverOpen] = useState(false);
  const [zoomPopoverOpen, setZoomPopoverOpen] = useState(false);
  const [findInPageOpen, setFindInPageOpen] = useState(false);
  const [desktopGuideOpen, setDesktopGuideOpen] = useState(false);
  const [siteSecurityPopoverOpen, setSiteSecurityPopoverOpen] = useState(false);
  const [clearDataModalOpen, setClearDataModalOpen] = useState(false);
  const [pendingPermissionRequest, setPendingPermissionRequest] = useState<PermissionRequest | null>(null);

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  // Set accent color on document root
  useEffect(() => {
    document.documentElement.setAttribute('data-accent', settings.accentColor);
  }, [settings.accentColor]);

  // Handle Tab Creation
  const handleNewTab = useCallback((url: string = 'nano://newtab') => {
    const newTabId = 'tab_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const newTab: Tab = {
      id: newTabId,
      title: url === 'nano://newtab' || url === 'nova://newtab' ? 'New Tab' : 'Loading...',
      url,
      isLoading: url !== 'nano://newtab' && url !== 'nova://newtab',
      canGoBack: false,
      canGoForward: false,
      blockedTrackersCount: 0,
      blockedTrackersList: [],
      shieldsEnabled: settings.shieldsDefaultState,
      zoomLevel: 1.0,
      historyIndex: 0,
      historyStack: [url]
    };

    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTabId);
  }, [settings.shieldsDefaultState]);

  // Handle Incognito Tab Creation (Ctrl+Shift+N)
  const handleNewIncognitoTab = useCallback((url: string = 'nano://incognito') => {
    const newTabId = 'tab_incog_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const incogSessionId = 'incog_session_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const newTab: Tab = {
      id: newTabId,
      title: url === 'nano://incognito' || url === 'nova://incognito' ? 'Incognito Tab' : 'Loading...',
      url,
      isLoading: url !== 'nano://incognito' && url !== 'nova://incognito',
      canGoBack: false,
      canGoForward: false,
      isIncognito: true,
      incognitoSessionId: incogSessionId,
      blockedTrackersCount: 0,
      blockedTrackersList: [],
      shieldsEnabled: true,
      zoomLevel: 1.0,
      historyIndex: 0,
      historyStack: [url]
    };

    setTabs((prev) => [...prev, newTab]);
    setActiveTabId(newTabId);
  }, []);

  // Handle Closing All Incognito Tabs & Purging Ephemeral Session Storage
  const handleCloseAllIncognitoTabs = useCallback(() => {
    // Purge server-side in-memory cookie jars for isolated incognito sessions
    fetch('/api/incognito/cleanup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    }).catch(() => {});

    setTabs((prev) => {
      const regularTabs = prev.filter((t) => !t.isIncognito);
      if (regularTabs.length === 0) {
        const freshTab: Tab = {
          id: 'tab_' + Date.now(),
          title: 'New Tab',
          url: 'nano://newtab',
          isLoading: false,
          canGoBack: false,
          canGoForward: false,
          blockedTrackersCount: 0,
          blockedTrackersList: [],
          shieldsEnabled: settings.shieldsDefaultState,
          zoomLevel: 1.0,
          historyIndex: 0,
          historyStack: ['nano://newtab']
        };
        setActiveTabId(freshTab.id);
        return [freshTab];
      }

      // If active tab was an incognito tab, switch to the first regular tab
      const isCurrentIncognito = prev.find((t) => t.id === activeTabId)?.isIncognito;
      if (isCurrentIncognito) {
        setActiveTabId(regularTabs[0].id);
      }
      return regularTabs;
    });

    addSecurityEvent({
      type: 'session_purged',
      title: 'Incognito session data purged',
      domain: 'browser-memory',
      severity: 'low',
      details: 'Ephemeral cookie jar and private site state zeroized'
    });
    setSecurityLogs(loadSecurityLogs());
  }, [activeTabId, settings.shieldsDefaultState]);

  // Handle Tab Close
  const handleCloseTab = useCallback((tabId: string) => {
    setTabs((prev) => {
      const closingTab = prev.find((t) => t.id === tabId);
      // Privacy Isolation: Never save incognito tabs to recentlyClosedTabs
      if (closingTab && !closingTab.isIncognito) {
        setRecentlyClosedTabs((r) => [closingTab, ...r.slice(0, 9)]);
      }

      // If closing an incognito tab, check if it was the last incognito tab
      if (closingTab?.isIncognito) {
        const remainingIncognito = prev.filter((t) => t.isIncognito && t.id !== tabId);
        if (remainingIncognito.length === 0) {
          fetch('/api/incognito/cleanup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sessionId: closingTab.incognitoSessionId })
          }).catch(() => {});
        }
      }

      if (prev.length === 1) {
        // If closing last tab, replace with empty new tab
        const freshTab: Tab = {
          id: 'tab_' + Date.now(),
          title: 'New Tab',
          url: 'nano://newtab',
          isLoading: false,
          canGoBack: false,
          canGoForward: false,
          blockedTrackersCount: 0,
          blockedTrackersList: [],
          shieldsEnabled: settings.shieldsDefaultState,
          zoomLevel: 1.0,
          historyIndex: 0,
          historyStack: ['nano://newtab']
        };
        setActiveTabId(freshTab.id);
        return [freshTab];
      }

      const filtered = prev.filter((t) => t.id !== tabId);
      if (activeTabId === tabId) {
        const index = prev.findIndex((t) => t.id === tabId);
        const nextActive = filtered[Math.max(0, index - 1)];
        if (nextActive) setActiveTabId(nextActive.id);
      }
      return filtered;
    });
  }, [activeTabId, settings.shieldsDefaultState]);

  // Restore recently closed tab (Ctrl+Shift+T)
  const handleRestoreClosedTab = useCallback(() => {
    if (recentlyClosedTabs.length === 0) return;
    const [tabToRestore, ...remaining] = recentlyClosedTabs;
    setRecentlyClosedTabs(remaining);
    setTabs((prev) => [...prev, tabToRestore]);
    setActiveTabId(tabToRestore.id);
  }, [recentlyClosedTabs]);

  // Duplicate Tab
  const handleDuplicateTab = useCallback((tabId: string) => {
    const source = tabs.find((t) => t.id === tabId);
    if (!source) return;
    handleNewTab(source.url);
  }, [tabs, handleNewTab]);

  // Toggle Pin Tab
  const handleTogglePinTab = useCallback((tabId: string) => {
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, isPinned: !t.isPinned } : t))
    );
  }, []);

  // Toggle Mute Tab
  const handleToggleMuteTab = useCallback((tabId: string) => {
    setTabs((prev) =>
      prev.map((t) => (t.id === tabId ? { ...t, isMuted: !t.isMuted } : t))
    );
  }, []);

  // Close Other Tabs
  const handleCloseOtherTabs = useCallback((tabId: string) => {
    setTabs((prev) => prev.filter((t) => t.id === tabId));
    setActiveTabId(tabId);
  }, []);

  // Core Navigation Logic with Threat Intelligence and Insecure HTTP Interception
  const handleNavigate = useCallback((rawUrl: string) => {
    let target = rawUrl;

    // Clean tracking parameters
    if (settings.cleanUrlTrackingParams) {
      target = sanitizeTrackingParameters(target);
    }

    const isInternal = target.startsWith('nano://') || target.startsWith('nova://');

    // Connection Security Enforcement: Upgrade standard HTTP to HTTPS (TLS 1.3)
    const isStrictHttps =
      settings.connectionSecurityMode === 'strict_https' ||
      settings.httpsEverywhere ||
      settings.upgradeHttpToHttps;

    if (isStrictHttps && target.startsWith('http://') && !isInternal) {
      target = target.replace(/^http:\/\//i, 'https://');
      let hostname = '';
      try {
        hostname = new URL(target).hostname;
      } catch {
        hostname = target;
      }
      addSecurityEvent({
        type: 'https_upgraded',
        title: `Connection security upgraded to HTTPS (${hostname})`,
        domain: hostname,
        severity: 'low',
        details: 'Enforced TLS 1.3 transport security over unencrypted standard HTTP'
      });
      setSecurityLogs(loadSecurityLogs());
    }

    // Insecure HTTP Warning Check
    if (settings.insecureHttpWarning && target.startsWith('http://') && !isInternal) {
      let hostname = '';
      try {
        hostname = new URL(target).hostname;
      } catch {
        hostname = target;
      }

      addSecurityEvent({
        type: 'insecure_http_warned',
        title: `Insecure HTTP page warning shown: ${hostname}`,
        domain: hostname,
        severity: 'medium',
        details: 'Intercepted unencrypted plaintext HTTP navigation'
      });
      setSecurityLogs(loadSecurityLogs());

      target = `nano://security-warning?type=insecure_http&url=${encodeURIComponent(target)}`;
    }

    // Phishing & Malware Threat Intelligence Check
    if (!isInternal && !target.startsWith('nano://security-warning')) {
      const evaluation = evaluateUrlThreat(target);
      if (
        evaluation.isThreat &&
        evaluation.threat &&
        ((evaluation.isPhishing && settings.phishingProtection) ||
          (evaluation.isMalware && settings.malwareProtection) ||
          evaluation.threat.severity === 'critical')
      ) {
        let domain = '';
        try {
          domain = new URL(target).hostname;
        } catch {
          domain = target;
        }

        addSecurityEvent({
          type: evaluation.isPhishing ? 'phishing_blocked' : 'malware_blocked',
          title: `Threat blocked: ${evaluation.threat.category.toUpperCase()} on ${domain}`,
          domain,
          severity: 'critical',
          details: evaluation.threat.description
        });
        setSecurityLogs(loadSecurityLogs());

        target = `nano://security-warning?type=${evaluation.threat.category}&url=${encodeURIComponent(target)}`;
      }
    }

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id !== activeTabId) return t;

        const nextIndex = t.historyIndex + 1;
        const newStack = [...t.historyStack.slice(0, nextIndex), target];
        const isInternalNow = target.startsWith('nano://') || target.startsWith('nova://');

        return {
          ...t,
          url: target,
          title: isInternalNow ? target.replace(/^(nano|nova):\/\//, '') : target,
          isLoading: !isInternalNow,
          blockedTrackersCount: 0,
          blockedTrackersList: [],
          historyIndex: nextIndex,
          historyStack: newStack,
          canGoBack: nextIndex > 0,
          canGoForward: false
        };
      })
    );

    // Save to history ONLY if not in an incognito tab and not in private mode and not internal/warning
    if (!activeTab.isIncognito && !isPrivate && !target.startsWith('nano://') && !target.startsWith('nova://')) {
      addHistoryEntry(target, target, false);
      setHistory(loadHistory());
    }
  }, [activeTabId, settings.cleanUrlTrackingParams, settings.httpsEverywhere, settings.insecureHttpWarning, settings.phishingProtection, settings.malwareProtection, isPrivate, activeTab.isIncognito]);

  // Proceed Unsafe Site Override (when user clicks "Proceed to site (Unsafe)" on warning interstitial)
  const handleProceedUnsafeSite = useCallback((unsafeUrl: string) => {
    let hostname = '';
    try {
      hostname = new URL(unsafeUrl).hostname;
    } catch {
      hostname = unsafeUrl;
    }

    addSecurityEvent({
      type: 'certificate_warning',
      title: `User bypassed security warning for ${hostname}`,
      domain: hostname,
      severity: 'high',
      details: 'User acknowledged risk and proceeded to unverified/insecure host'
    });
    setSecurityLogs(loadSecurityLogs());

    setTabs((prev) =>
      prev.map((t) => {
        if (t.id !== activeTabId) return t;
        const nextIndex = t.historyIndex + 1;
        const newStack = [...t.historyStack.slice(0, nextIndex), unsafeUrl];
        return {
          ...t,
          url: unsafeUrl,
          title: unsafeUrl,
          isLoading: true,
          historyIndex: nextIndex,
          historyStack: newStack,
          canGoBack: true,
          canGoForward: false
        };
      })
    );
  }, [activeTabId]);

  // Upgrade Connection Security from standard HTTP to HTTPS (TLS 1.3)
  const handleUpgradeCurrentConnectionToHttps = useCallback(() => {
    const currentTab = tabs.find((t) => t.id === activeTabId);
    if (!currentTab) return;

    let targetUrl = currentTab.url;
    // If currently on an insecure warning, retrieve original target URL
    if (targetUrl.startsWith('nano://security-warning') || targetUrl.startsWith('nova://security-warning')) {
      try {
        const dummyUrl = targetUrl.replace(/^(nano|nova):\/\//, 'http://dummy/');
        const parsed = new URL(dummyUrl);
        const original = parsed.searchParams.get('url');
        if (original) targetUrl = original;
      } catch {}
    }

    if (targetUrl.startsWith('http://')) {
      const secureUrl = targetUrl.replace(/^http:\/\//i, 'https://');
      let hostname = '';
      try {
        hostname = new URL(secureUrl).hostname;
      } catch {
        hostname = secureUrl;
      }

      addSecurityEvent({
        type: 'https_upgraded',
        title: `Connection security upgraded to HTTPS for ${hostname}`,
        domain: hostname,
        severity: 'low',
        details: 'Enforced TLS 1.3 encryption over standard unencrypted HTTP'
      });
      setSecurityLogs(loadSecurityLogs());

      // Persist strict HTTPS connection security policy
      if (!settings.httpsEverywhere || settings.connectionSecurityMode !== 'strict_https') {
        const updated: BrowserSettings = {
          ...settings,
          httpsEverywhere: true,
          connectionSecurityMode: 'strict_https',
          upgradeHttpToHttps: true
        };
        setSettings(updated);
        saveSettings(updated);
      }

      handleNavigate(secureUrl);
    } else {
      // Re-enforce strict HTTPS connection policy across browser
      const updated: BrowserSettings = {
        ...settings,
        httpsEverywhere: true,
        connectionSecurityMode: 'strict_https',
        upgradeHttpToHttps: true
      };
      setSettings(updated);
      saveSettings(updated);

      addSecurityEvent({
        type: 'https_upgraded',
        title: 'Strict HTTPS connection security policy activated',
        domain: 'browser-policy',
        severity: 'low',
        details: 'Enforced TLS 1.3 encryption policy across all browser navigation'
      });
      setSecurityLogs(loadSecurityLogs());
    }
  }, [activeTabId, tabs, settings, handleNavigate]);

  const handleUpgradeAllTabsToHttps = useCallback(() => {
    let count = 0;
    setTabs((prev) =>
      prev.map((t) => {
        if (t.url.startsWith('http://')) {
          count++;
          const secureUrl = t.url.replace(/^http:\/\//i, 'https://');
          return {
            ...t,
            url: secureUrl,
            title: secureUrl,
            isLoading: true
          };
        }
        return t;
      })
    );

    const updated: BrowserSettings = {
      ...settings,
      httpsEverywhere: true,
      connectionSecurityMode: 'strict_https',
      upgradeHttpToHttps: true
    };
    setSettings(updated);
    saveSettings(updated);

    addSecurityEvent({
      type: 'https_upgraded',
      title: `Upgraded ${count} tab(s) to secure HTTPS`,
      domain: 'browser-session',
      severity: 'low',
      details: 'All unencrypted standard HTTP tabs upgraded to TLS 1.3 encryption'
    });
    setSecurityLogs(loadSecurityLogs());
  }, [settings]);

  const handleGoBack = useCallback(() => {
    setTabs((prev) =>
      prev.map((t) => {
        if (t.id !== activeTabId || t.historyIndex <= 0) return t;
        const newIndex = t.historyIndex - 1;
        const prevUrl = t.historyStack[newIndex];
        const isInternal = prevUrl.startsWith('nano://') || prevUrl.startsWith('nova://');
        return {
          ...t,
          url: prevUrl,
          title: isInternal ? prevUrl.replace(/^(nano|nova):\/\//, '') : prevUrl,
          historyIndex: newIndex,
          canGoBack: newIndex > 0,
          canGoForward: true,
          isLoading: !isInternal
        };
      })
    );
  }, [activeTabId]);

  const handleGoForward = useCallback(() => {
    setTabs((prev) =>
      prev.map((t) => {
        if (t.id !== activeTabId || t.historyIndex >= t.historyStack.length - 1) return t;
        const newIndex = t.historyIndex + 1;
        const nextUrl = t.historyStack[newIndex];
        const isInternal = nextUrl.startsWith('nano://') || nextUrl.startsWith('nova://');
        return {
          ...t,
          url: nextUrl,
          title: isInternal ? nextUrl.replace(/^(nano|nova):\/\//, '') : nextUrl,
          historyIndex: newIndex,
          canGoBack: true,
          canGoForward: newIndex < t.historyStack.length - 1,
          isLoading: !isInternal
        };
      })
    );
  }, [activeTabId]);

  const handleReload = useCallback(() => {
    setTabs((prev) =>
      prev.map((t) => {
        if (t.id !== activeTabId) return t;
        return { ...t, isLoading: true };
      })
    );
    setTimeout(() => {
      setTabs((prev) =>
        prev.map((t) => (t.id === activeTabId ? { ...t, isLoading: false } : t))
      );
    }, 800);
  }, [activeTabId]);

  // Tab Navigated Callback (from proxied web bridge)
  const handleTabNavigated = useCallback(
    (tabId: string, url: string, title?: string, blockedCount?: number, blockedTrackers?: string[]) => {
      setTabs((prev) =>
        prev.map((t) => {
          if (t.id !== tabId) return t;

          const newBlocked = blockedCount ?? t.blockedTrackersCount;
          const newTrackersList = blockedTrackers ?? t.blockedTrackersList;

          // Update global shield metrics
          if (newBlocked > t.blockedTrackersCount) {
            const newlyBlocked = newBlocked - t.blockedTrackersCount;
            setShieldStats((prevStats) => {
              const updated = calculateShieldMetrics(prevStats, newlyBlocked);
              saveShieldStats(updated);
              return updated;
            });
          }

          return {
            ...t,
            url,
            title: title || t.title,
            isLoading: false,
            blockedTrackersCount: newBlocked,
            blockedTrackersList: newTrackersList
          };
        })
      );

      // Record in history if page title arrived — NEVER save for incognito tabs
      setTabs((prev) => {
        const currentTab = prev.find((t) => t.id === tabId);
        if (title && currentTab && !currentTab.isIncognito && !isPrivate && !url.startsWith('nano://') && !url.startsWith('nova://')) {
          addHistoryEntry(title, url, false);
          setHistory(loadHistory());
        }
        return prev;
      });
    },
    [isPrivate]
  );

  // Toggle Shields for Current Site
  const handleToggleSiteShields = useCallback(() => {
    setTabs((prev) =>
      prev.map((t) => {
        if (t.id !== activeTabId) return t;
        return { ...t, shieldsEnabled: !t.shieldsEnabled, isLoading: true };
      })
    );
    setTimeout(() => {
      setTabs((prev) =>
        prev.map((t) => (t.id === activeTabId ? { ...t, isLoading: false } : t))
      );
    }, 600);
  }, [activeTabId]);

  // Bookmark active tab toggle
  const isCurrentBookmarked = bookmarks.some((b) => b.url === activeTab.url);

  const handleToggleBookmark = useCallback(() => {
    if (isCurrentBookmarked) {
      const updated = bookmarks.filter((b) => b.url !== activeTab.url);
      setBookmarks(updated);
      saveBookmarks(updated);
    } else {
      const newBookmark: BookmarkItem = {
        id: 'bm_' + Date.now(),
        title: activeTab.title || activeTab.url,
        url: activeTab.url,
        createdAt: Date.now()
      };
      const updated = [...bookmarks, newBookmark];
      setBookmarks(updated);
      saveBookmarks(updated);
    }
  }, [bookmarks, activeTab.url, activeTab.title, isCurrentBookmarked]);

  // Update Settings
  const handleUpdateSettings = useCallback((newSettings: Partial<BrowserSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      saveSettings(updated);
      return updated;
    });
  }, []);

  // Update Site Permission
  const handleUpdateSitePermission = useCallback(
    (type: 'camera' | 'microphone' | 'location' | 'notifications' | 'popups' | 'clipboard', value: 'ask' | 'allow' | 'block') => {
      let origin = '';
      try {
        origin = new URL(activeTab.url).origin;
      } catch {
        origin = activeTab.url;
      }

      setSitePermissions((prev) => {
        const existing = prev.find((p) => p.origin === origin);
        let updated: SitePermission[];
        if (existing) {
          updated = prev.map((p) => (p.origin === origin ? { ...p, [type]: value } : p));
        } else {
          updated = [
            ...prev,
            {
              origin,
              camera: 'ask',
              microphone: 'ask',
              location: 'ask',
              notifications: 'ask',
              popups: 'ask',
              [type]: value
            }
          ];
        }
        saveSitePermissions(updated);
        return updated;
      });

      addSecurityEvent({
        type: value === 'allow' ? 'permission_granted' : value === 'block' ? 'permission_revoked' : 'permission_requested',
        title: `Permission for ${type} changed to '${value}'`,
        domain: origin,
        severity: 'low'
      });
      setSecurityLogs(loadSecurityLogs());
    },
    [activeTab.url]
  );

  // Revoke Specific Site Permission
  const handleRevokePermission = useCallback(
    (origin: string, type: 'camera' | 'microphone' | 'location' | 'notifications') => {
      setSitePermissions((prev) => {
        const updated = prev.map((p) => {
          if (p.origin === origin) {
            return { ...p, [type]: 'ask' as const };
          }
          return p;
        });
        saveSitePermissions(updated);
        return updated;
      });

      addSecurityEvent({
        type: 'permission_revoked',
        title: `Revoked ${type} access for ${origin}`,
        domain: origin,
        severity: 'low'
      });
      setSecurityLogs(loadSecurityLogs());
    },
    []
  );

  // Clear All Permissions
  const handleClearAllPermissions = useCallback(() => {
    saveSitePermissions([]);
    setSitePermissions([]);
    addSecurityEvent({
      type: 'permission_revoked',
      title: 'Cleared all stored site permissions',
      domain: 'browser-security',
      severity: 'low'
    });
    setSecurityLogs(loadSecurityLogs());
  }, []);

  // Clear Site Data for active tab
  const handleClearCurrentSiteData = useCallback(() => {
    let hostname = '';
    try {
      hostname = new URL(activeTab.url).hostname;
    } catch {
      hostname = activeTab.url;
    }

    performGranularClearData({
      timeRange: 'all',
      history: true,
      downloads: false,
      cookies: true,
      cache: true,
      passwords: false,
      permissions: true
    });

    setHistory(loadHistory());
    setSitePermissions(loadSitePermissions());
    addSecurityEvent({
      type: 'session_purged',
      title: `Purged cookies, cache, and site permissions for ${hostname}`,
      domain: hostname,
      severity: 'low'
    });
    setSecurityLogs(loadSecurityLogs());
  }, [activeTab.url]);

  // Granular Clear Browsing Data
  const handleClearBrowsingData = useCallback((options: GranularClearDataOptions) => {
    performGranularClearData(options);
    setHistory(loadHistory());
    setDownloads(loadDownloads());
    setSitePermissions(loadSitePermissions());
    addSecurityEvent({
      type: 'session_purged',
      title: 'Cleared browsing data',
      domain: 'local-storage',
      severity: 'low',
      details: `Purged: ${Object.entries(options).filter(([k, v]) => v === true).map(([k]) => k).join(', ')}`
    });
    setSecurityLogs(loadSecurityLogs());
  }, []);

  // Keyboard Shortcuts (Windows standard browser shortcuts)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isCtrl = e.ctrlKey || e.metaKey;

      if (isCtrl && !e.shiftKey && e.key.toLowerCase() === 't') {
        e.preventDefault();
        handleNewTab();
      } else if (isCtrl && !e.shiftKey && e.key.toLowerCase() === 'w') {
        e.preventDefault();
        handleCloseTab(activeTabId);
      } else if (isCtrl && e.shiftKey && e.key.toLowerCase() === 't') {
        e.preventDefault();
        handleRestoreClosedTab();
      } else if (isCtrl && e.shiftKey && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        handleNewIncognitoTab();
      } else if (isCtrl && !e.shiftKey && e.key.toLowerCase() === 'h') {
        e.preventDefault();
        handleNavigate('nano://history');
      } else if (isCtrl && !e.shiftKey && e.key.toLowerCase() === 'j') {
        e.preventDefault();
        handleNavigate('nano://downloads');
      } else if (isCtrl && e.shiftKey && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        handleNavigate('nano://bookmarks');
      } else if (isCtrl && !e.shiftKey && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setFindInPageOpen((prev) => !prev);
      } else if (isCtrl && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        handleReload();
      } else if (isCtrl && e.shiftKey && (e.key === 'Delete' || e.key === 'Del' || e.key === 'Backspace')) {
        e.preventDefault();
        setClearDataModalOpen(true);
      } else if (e.key === 'F11') {
        e.preventDefault();
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    activeTabId,
    handleNewTab,
    handleNewIncognitoTab,
    handleCloseTab,
    handleRestoreClosedTab,
    handleNavigate,
    handleReload
  ]);

  const isIncognitoActive = isPrivate || !!activeTab.isIncognito;

  // Active site permission object
  let activeOrigin = '';
  try {
    activeOrigin = new URL(activeTab.url).origin;
  } catch {
    activeOrigin = activeTab.url;
  }
  const currentSitePermission = sitePermissions.find((p) => p.origin === activeOrigin);

  return (
    <div
      className={`h-screen w-screen flex flex-col overflow-hidden bg-neutral-950 font-sans select-none ${
        settings.theme === 'light' ? 'theme-light' : 'theme-dark'
      }`}
    >
      {/* 1. Windows TitleBar */}
      <TitleBar
        isPrivate={isIncognitoActive}
        onTogglePrivate={() => {
          if (activeTab.isIncognito) {
            handleCloseAllIncognitoTabs();
          } else {
            handleNewIncognitoTab();
          }
        }}
        onOpenDesktopGuide={() => setDesktopGuideOpen(true)}
      />

      {/* 2. NANO Multi-Tab Strip */}
      <TabBar
        tabs={tabs}
        activeTabId={activeTabId}
        onSelectTab={setActiveTabId}
        onCloseTab={handleCloseTab}
        onNewTab={handleNewTab}
        onNewIncognitoTab={handleNewIncognitoTab}
        onDuplicateTab={handleDuplicateTab}
        onTogglePinTab={handleTogglePinTab}
        onToggleMuteTab={handleToggleMuteTab}
        onCloseOtherTabs={handleCloseOtherTabs}
        onCloseAllIncognitoTabs={handleCloseAllIncognitoTabs}
        isPrivate={isIncognitoActive}
      />

      {/* 3. Navigation & Omnibox Bar */}
      <NavigationBar
        activeTab={activeTab}
        settings={settings}
        isBookmarked={isCurrentBookmarked}
        onNavigate={handleNavigate}
        onGoBack={handleGoBack}
        onGoForward={handleGoForward}
        onReload={handleReload}
        onGoHome={() => handleNavigate(activeTab.isIncognito ? 'nano://incognito' : 'nano://newtab')}
        onToggleBookmark={handleToggleBookmark}
        onToggleShieldsPopover={() => setShieldsPopoverOpen(!shieldsPopoverOpen)}
        onToggleDownloadsPopover={() => setDownloadsPopoverOpen(!downloadsPopoverOpen)}
        onToggleZoomPopover={() => setZoomPopoverOpen(!zoomPopoverOpen)}
        onOpenSettings={() => handleNavigate('nano://settings')}
        onOpenDesktopGuide={() => setDesktopGuideOpen(true)}
        onNewIncognitoTab={handleNewIncognitoTab}
        onOpenSecurityCenter={() => handleNavigate('nano://security')}
        onOpenPasswordsPage={() => handleNavigate('nano://passwords')}
        onOpenClearDataModal={() => setClearDataModalOpen(true)}
        onToggleSiteSecurityPopover={() => setSiteSecurityPopoverOpen(!siteSecurityPopoverOpen)}
        onUpgradeToHttps={handleUpgradeCurrentConnectionToHttps}
        isPrivate={isIncognitoActive}
        shieldsPopoverOpen={shieldsPopoverOpen}
        siteSecurityPopoverOpen={siteSecurityPopoverOpen}
        activeDownloadsCount={downloads.filter((d) => d.status === 'downloading').length}
      />

      {/* 4. Bookmarks Bar (if enabled in settings) */}
      {settings.showBookmarksBar && (
        <BookmarksBar
          bookmarks={bookmarks}
          folders={folders}
          onNavigate={handleNavigate}
          onOpenBookmarksManager={() => handleNavigate('nano://bookmarks')}
        />
      )}

      {/* 5. Main Web & Internal Pages Renderer */}
      <div className="relative flex-1 w-full overflow-hidden">
        <WebRenderer
          activeTab={activeTab}
          stats={shieldStats}
          speedDials={speedDials}
          settings={settings}
          bookmarks={bookmarks}
          folders={folders}
          history={history}
          downloads={downloads}
          sitePermissions={sitePermissions}
          securityLogs={securityLogs}
          onNavigate={handleNavigate}
          onAddSpeedDial={(shortcut) => {
            const updated = [
              ...speedDials,
              { ...shortcut, id: 'sd_' + Date.now(), color: '#a855f7' }
            ];
            setSpeedDials(updated);
            saveSpeedDials(updated);
          }}
          onRemoveSpeedDial={(id) => {
            const updated = speedDials.filter((d) => d.id !== id);
            setSpeedDials(updated);
            saveSpeedDials(updated);
          }}
          onUpdateSettings={handleUpdateSettings}
          onClearHistory={(range) => {
            clearBrowsingHistory(range);
            setHistory(loadHistory());
          }}
          onDeleteHistoryItem={(id) => {
            const updated = history.filter((h) => h.id !== id);
            setHistory(updated);
            saveHistory(updated);
          }}
          onAddBookmark={(item) => {
            const updated = [
              ...bookmarks,
              { ...item, id: 'bm_' + Date.now(), createdAt: Date.now() }
            ];
            setBookmarks(updated);
            saveBookmarks(updated);
          }}
          onDeleteBookmark={(id) => {
            const updated = bookmarks.filter((b) => b.id !== id);
            setBookmarks(updated);
            saveBookmarks(updated);
          }}
          onAddFolder={(title) => {
            const updated = [...folders, { id: 'f_' + Date.now(), title }];
            setFolders(updated);
            saveFolders(updated);
          }}
          onImportBookmarks={(imported) => {
            const updated = [...bookmarks, ...imported];
            setBookmarks(updated);
            saveBookmarks(updated);
          }}
          onOpenDownload={(item) => {
            alert(`Opening downloaded file: ${item.fileName}\nPath: ${item.path}`);
          }}
          onClearDownloads={() => {
            setDownloads([]);
            saveDownloads([]);
          }}
          onCancelDownload={(id) => {
            const updated = downloads.map((d) =>
              d.id === id ? { ...d, status: 'canceled' as const } : d
            );
            setDownloads(updated);
            saveDownloads(updated);
          }}
          onTabNavigated={handleTabNavigated}
          onOpenDesktopGuide={() => setDesktopGuideOpen(true)}
          onCloseIncognitoTabs={handleCloseAllIncognitoTabs}
          incognitoTabsCount={tabs.filter((t) => t.isIncognito).length}
          onClearSecurityLogs={() => {
            clearSecurityLogs();
            setSecurityLogs([]);
          }}
          onRevokePermission={handleRevokePermission}
          onClearAllPermissions={handleClearAllPermissions}
          onOpenPasswordsPage={() => handleNavigate('nano://passwords')}
          onProceedUnsafeSite={handleProceedUnsafeSite}
        />

        {/* Find In Page (Ctrl+F) */}
        {findInPageOpen && <FindInPage onClose={() => setFindInPageOpen(false)} />}

        {/* Zoom Controls Popover */}
        {zoomPopoverOpen && (
          <ZoomPopover
            zoomLevel={activeTab.zoomLevel}
            onSetZoom={(newZoom) => {
              setTabs((prev) =>
                prev.map((t) => (t.id === activeTabId ? { ...t, zoomLevel: newZoom } : t))
              );
            }}
            onClose={() => setZoomPopoverOpen(false)}
          />
        )}

        {/* Nano Shields Popover */}
        {shieldsPopoverOpen && (
          <NovaShieldPopover
            activeTab={activeTab}
            settings={settings}
            onToggleSiteShields={handleToggleSiteShields}
            onUpdateSettings={handleUpdateSettings}
            onClose={() => setShieldsPopoverOpen(false)}
            onOpenShieldsDashboard={() => handleNavigate('nano://shields')}
            onUpgradeToHttps={handleUpgradeCurrentConnectionToHttps}
          />
        )}

        {/* Site Security & Permissions Popover (Padlock click) */}
        {siteSecurityPopoverOpen && (
          <SiteSecurityPopover
            currentUrl={activeTab.url}
            isShieldsEnabled={activeTab.shieldsEnabled}
            blockedCount={activeTab.blockedTrackersCount}
            sitePermission={currentSitePermission}
            onUpdatePermission={handleUpdateSitePermission}
            onClearSiteData={handleClearCurrentSiteData}
            onOpenSecurityCenter={() => {
              setSiteSecurityPopoverOpen(false);
              handleNavigate('nano://security');
            }}
            onClose={() => setSiteSecurityPopoverOpen(false)}
            onUpgradeToHttps={handleUpgradeCurrentConnectionToHttps}
          />
        )}

        {/* Active Site Permission Prompt Banner */}
        {pendingPermissionRequest && (
          <PermissionPromptBanner
            request={pendingPermissionRequest}
            onAllow={(remember) => {
              if (remember) {
                handleUpdateSitePermission(pendingPermissionRequest.type, 'allow');
              }
              setPendingPermissionRequest(null);
            }}
            onBlock={() => {
              handleUpdateSitePermission(pendingPermissionRequest.type, 'block');
              setPendingPermissionRequest(null);
            }}
          />
        )}

        {/* Downloads Popover */}
        {downloadsPopoverOpen && (
          <DownloadsPopover
            downloads={downloads}
            onOpenDownload={(item) => alert(`Opening: ${item.fileName}`)}
            onOpenDownloadsPage={() => handleNavigate('nano://downloads')}
            onClose={() => setDownloadsPopoverOpen(false)}
          />
        )}
      </div>

      {/* Granular Clear Browsing Data Modal (Ctrl+Shift+Del) */}
      {clearDataModalOpen && (
        <ClearBrowsingDataModal
          onClear={handleClearBrowsingData}
          onClose={() => setClearDataModalOpen(false)}
        />
      )}

      {/* Windows 10 & 11 Desktop Release & Packaging Guide Modal */}
      {desktopGuideOpen && (
        <DesktopExportModal onClose={() => setDesktopGuideOpen(false)} />
      )}
    </div>
  );
}
